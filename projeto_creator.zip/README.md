
  # Horizontal Operations Board Template - v5

  This is a code bundle for Horizontal Operations Board Template - v5. The original project is available at https://www.figma.com/design/llCl3Ntitm0YTirg8kx8sj/Horizontal-Operations-Board-Template---v5.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  