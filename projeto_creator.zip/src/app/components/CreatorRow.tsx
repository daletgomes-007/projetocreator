import { Creator } from '@/app/components/Board';
import { EditableCell } from '@/app/components/EditableCell';
import { StatusBadge } from '@/app/components/StatusBadge';
import { LinkCell } from '@/app/components/LinkCell';
import { CheckboxCell } from '@/app/components/CheckboxCell';

interface CreatorRowProps {
  creator: Creator;
}

export function CreatorRow({ creator }: CreatorRowProps) {
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('pt-BR').format(num);
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(num);
  };

  return (
    <div className="grid grid-cols-[200px_150px_120px_120px_100px_180px_140px_140px_120px_120px_150px_120px_180px_120px_120px_120px] gap-px bg-gray-200 hover:bg-gray-100 transition-colors">
      <EditableCell value={creator.name} />
      <EditableCell value={creator.socialNetwork} />
      <EditableCell value={formatNumber(creator.followers)} align="right" />
      <EditableCell value={formatNumber(creator.reach)} align="right" />
      <EditableCell value={`${creator.engagement.toFixed(1)}%`} align="right" />
      <EditableCell value={creator.scope} />
      <EditableCell value={formatCurrency(creator.creatorValue)} align="right" />
      <EditableCell value={formatCurrency(creator.agencyValue)} align="right" />
      <LinkCell url={creator.contractLink} />
      <LinkCell url={creator.contentLink} />
      <div className="bg-white px-4 py-3 flex items-center">
        <StatusBadge status={creator.approvalStatus} />
      </div>
      <LinkCell url={creator.publicationLink} />
      <EditableCell value={creator.boostCode} />
      <CheckboxCell checked={creator.hasBoosting} />
      <LinkCell url={creator.invoiceLink} />
      <CheckboxCell checked={creator.paymentConfirmed} />
    </div>
  );
}
