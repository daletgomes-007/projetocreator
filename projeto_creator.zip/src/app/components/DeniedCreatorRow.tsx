import { DeniedCreator } from '@/app/components/Board';
import { EditableCell } from '@/app/components/EditableCell';

interface DeniedCreatorRowProps {
  creator: DeniedCreator;
}

export function DeniedCreatorRow({ creator }: DeniedCreatorRowProps) {
  return (
    <div className="grid grid-cols-[250px_250px_1fr] gap-px bg-gray-200 hover:bg-gray-100 transition-colors">
      <EditableCell value={creator.name} />
      <EditableCell value={creator.email} />
      <EditableCell value={creator.observation} />
    </div>
  );
}
