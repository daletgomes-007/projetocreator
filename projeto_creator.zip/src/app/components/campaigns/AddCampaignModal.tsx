import { useState, useEffect } from 'react';
import { X, Calendar, FileText, Users, DollarSign } from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';
import { Campaign } from '@/app/contexts/AppContext';
import { toast } from 'sonner';

interface AddCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  campaignToEdit?: Campaign;
}

export function AddCampaignModal({ isOpen, onClose, campaignToEdit }: AddCampaignModalProps) {
  const { addCampaign, updateCampaign, currentClient } = useApp();
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    budget: '',
    influencerCount: '',
  });

  useEffect(() => {
    if (campaignToEdit) {
      setFormData({
        name: campaignToEdit.name,
        description: campaignToEdit.description || '',
        startDate: campaignToEdit.startDate,
        endDate: campaignToEdit.endDate || '',
        budget: campaignToEdit.budget?.toString() || '',
        influencerCount: campaignToEdit.creators?.toString() || '',
      });
    } else {
      setFormData({
        name: '',
        description: '',
        startDate: '',
        endDate: '',
        budget: '',
        influencerCount: '',
      });
    }
  }, [campaignToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentClient) {
      toast.error('Nenhum cliente selecionado!');
      return;
    }

    const campaignData = {
      name: formData.name,
      clientId: currentClient.id,
      status: 'active' as const, // Mudado de 'draft' para 'active' - campanhas novas já começam aprovadas
      startDate: formData.startDate,
      endDate: formData.endDate,
      budget: parseFloat(formData.budget),
      description: formData.description,
      creators: parseInt(formData.influencerCount),
      client: currentClient.name,
    };

    if (campaignToEdit) {
      updateCampaign(campaignToEdit.id, campaignData);
      toast.success('Campanha atualizada com sucesso!');
    } else {
      addCampaign(campaignData);
      toast.success('Campanha criada com sucesso!');
    }

    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const getDuration = () => {
    if (formData.startDate && formData.endDate) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    }
    return 0;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-8 py-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {campaignToEdit ? 'Editar Campanha' : 'Nova Campanha'}
            </h2>
            <p className="text-sm text-gray-600 mt-1">
              Preencha as informações da campanha
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-500" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {/* Nome da Campanha */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome da Campanha *
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: Campanha de Lançamento"
            />
          </div>

          {/* Resumo do Projeto */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Resumo do Projeto *
              </div>
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
              rows={4}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              placeholder="Descreva os objetivos e estratégia da campanha..."
            />
          </div>

          {/* Duração da Campanha */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Duração da Campanha *
              </div>
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-600 mb-1">Data de Início</label>
                <input
                  type="date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Data de Término</label>
                <input
                  type="date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  required
                  min={formData.startDate}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            {formData.startDate && formData.endDate && (
              <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-900">
                  <span className="font-semibold">Duração:</span> {getDuration()} dias
                </p>
              </div>
            )}
          </div>

          {/* Quantidade de Influenciadores */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Quantidade de Influenciadores *
              </div>
            </label>
            <input
              type="number"
              name="influencerCount"
              value={formData.influencerCount}
              onChange={handleChange}
              required
              min="1"
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: 5"
            />
          </div>

          {/* Orçamento */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Orçamento *
              </div>
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">R$</span>
              <input
                type="number"
                name="budget"
                value={formData.budget}
                onChange={handleChange}
                required
                min="0"
                step="0.01"
                className="w-full pl-12 pr-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0,00"
              />
            </div>
            {formData.budget && (
              <p className="text-sm text-gray-600 mt-2">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(parseFloat(formData.budget))}
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              {campaignToEdit ? 'Salvar Alterações' : 'Criar Campanha'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}