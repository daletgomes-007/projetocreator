import { ChevronDown, Bell, LogOut, Building2, Menu, X } from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';
import { NotificationDropdown } from '@/app/components/notifications/NotificationDropdown';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import { useState } from 'react';

export function Header() {
  const { user, currentClient, setUser, logout, sidebarOpen, setSidebarOpen, setCurrentPage } = useApp();
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  if (!user) return null;

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 md:px-6 sticky top-0 z-50">
      {/* Left Side - Menu Button (Mobile) + Logo */}
      <div className="flex items-center gap-3 md:gap-6">
        {/* Mobile Menu Button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
          aria-label="Toggle menu"
        >
          {sidebarOpen ? (
            <X className="w-5 h-5 text-gray-700" />
          ) : (
            <Menu className="w-5 h-5 text-gray-700" />
          )}
        </button>

        {/* Logo */}
        <div className="flex items-center gap-2 md:gap-3">
          <div className="w-7 h-7 md:w-8 md:h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-xs md:text-sm">CB</span>
          </div>
          <h1 className="text-base md:text-xl font-semibold text-gray-900 hidden sm:block">CreatorBoard</h1>
        </div>

        {/* Client Info - Hidden on small mobile */}
        {currentClient && (
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
            <Building2 className="w-4 h-4 text-blue-600" />
            <span className="text-xs text-blue-600 font-medium">Cliente:</span>
            <span className="text-sm font-semibold text-blue-900">{currentClient.name}</span>
          </div>
        )}
      </div>

      {/* Right Side - Role, Notifications and User Menu */}
      <div className="flex items-center gap-2 md:gap-4">
        {/* Role Badge - Hidden on small mobile */}
        <div className="hidden sm:block px-2 md:px-3 py-1 md:py-1.5 bg-purple-50 text-purple-600 rounded-full text-xs font-medium">
          {user.role === 'admin' ? 'Admin' : 'Cliente'}
        </div>

        {/* Notifications */}
        <NotificationDropdown />

        {/* User Menu */}
        <DropdownMenu.Root open={userMenuOpen} onOpenChange={setUserMenuOpen}>
          <DropdownMenu.Trigger asChild>
            <button className="flex items-center gap-2 md:gap-3 px-2 md:px-3 py-2 hover:bg-gray-100 rounded-lg transition-colors">
              <div className="w-7 h-7 md:w-8 md:h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs md:text-sm font-semibold">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>
              <div className="text-left hidden md:block">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">
                  {user.role === 'admin' ? 'Admin' : 'Cliente'}
                </p>
              </div>
              <ChevronDown className="w-4 h-4 text-gray-500 hidden md:block" />
            </button>
          </DropdownMenu.Trigger>

          <DropdownMenu.Portal>
            <DropdownMenu.Content
              className="min-w-[200px] bg-white rounded-lg shadow-lg border border-gray-200 p-1 z-[100]"
              sideOffset={5}
              align="end"
            >
              {/* Show user info on mobile */}
              <div className="md:hidden px-3 py-2 border-b border-gray-200 mb-1">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">
                  {user.role === 'admin' ? 'Admin' : 'Cliente'}
                </p>
              </div>
              
              <DropdownMenu.Item 
                className="px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded cursor-pointer outline-none"
                onClick={() => {
                  setCurrentPage('settings');
                  setUserMenuOpen(false);
                }}
              >
                Meu perfil
              </DropdownMenu.Item>
              <DropdownMenu.Item 
                className="px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded cursor-pointer outline-none"
                onClick={() => {
                  setCurrentPage('settings');
                  setUserMenuOpen(false);
                }}
              >
                Configurações
              </DropdownMenu.Item>
              <DropdownMenu.Separator className="h-px bg-gray-200 my-1" />
              <DropdownMenu.Item
                className="px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded cursor-pointer outline-none"
                onClick={() => {
                  // Toggle between admin and client for demo
                  setUser({
                    ...user,
                    role: user.role === 'admin' ? 'client' : 'admin',
                    name: user.role === 'admin' ? 'Maria Santos' : 'João Silva',
                    email: user.role === 'admin' ? 'maria@odontocompany.com' : 'joao@agencia.com',
                  });
                  setUserMenuOpen(false);
                }}
              >
                Alternar para {user.role === 'admin' ? 'Cliente' : 'Admin'}
              </DropdownMenu.Item>
              <DropdownMenu.Separator className="h-px bg-gray-200 my-1" />
              <DropdownMenu.Item 
                className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded cursor-pointer outline-none flex items-center gap-2"
                onClick={logout}
              >
                <LogOut className="w-4 h-4" />
                Sair
              </DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Portal>
        </DropdownMenu.Root>
      </div>
    </header>
  );
}