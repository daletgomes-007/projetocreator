import {
  LayoutDashboard,
  Megaphone,
  Users,
  FileText,
  Image,
  DollarSign,
  BarChart3,
  Settings,
  Building2,
} from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'clients', label: 'Clientes', icon: Building2, adminOnly: true },
  { id: 'campaigns', label: 'Campanhas', icon: Megaphone },
  { id: 'creators', label: 'Creators', icon: Users },
  { id: 'contents', label: 'Conteúdos', icon: Image },
  { id: 'contracts', label: 'Contratos', icon: FileText, adminOnly: true },
  { id: 'financial', label: 'Financeiro', icon: DollarSign, adminOnly: true },
  { id: 'insights', label: 'Insights / Relatórios', icon: BarChart3 },
  { id: 'settings', label: 'Configurações', icon: Settings },
];

export function Sidebar() {
  const { currentPage, setCurrentPage, user, sidebarOpen, setSidebarOpen } = useApp();

  const filteredNavItems = navItems.filter(
    (item) => !item.adminOnly || user.role === 'admin'
  );

  const handleNavClick = (itemId: string) => {
    setCurrentPage(itemId);
    // Close sidebar on mobile after navigation
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  return (
    <>
      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-50
          w-64 bg-white border-r border-gray-200 flex flex-col
          transform transition-transform duration-300 ease-in-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          mt-16 lg:mt-0
        `}
      >
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-blue-700' : 'text-gray-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="text-xs text-gray-500 text-center">
            v1.0.0 · CreatorBoard
          </div>
        </div>
      </aside>
    </>
  );
}