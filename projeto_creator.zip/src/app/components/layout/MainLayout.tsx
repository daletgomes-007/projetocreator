import { useApp } from '@/app/contexts/AppContext';
import { LoginPage } from '@/app/pages/LoginPage';
import { DashboardPage } from '@/app/pages/DashboardPage';
import { CampaignsPage } from '@/app/pages/CampaignsPage';
import { CampaignInsightsPage } from '@/app/pages/CampaignInsightsPage';
import { CreatorsPage } from '@/app/pages/CreatorsPage';
import { ContentsPage } from '@/app/pages/ContentsPage';
import { ContractsPage } from '@/app/pages/ContractsPage';
import { FinancialPage } from '@/app/pages/FinancialPage';
import { InsightsPage } from '@/app/pages/InsightsPage';
import { SettingsPage } from '@/app/pages/SettingsPage';
import { ClientsPage } from '@/app/pages/ClientsPage';
import { Sidebar } from '@/app/components/layout/Sidebar';
import { Header } from '@/app/components/layout/Header';

export function MainLayout() {
  const { currentPage, isAuthenticated } = useApp();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage />;
      case 'dashboard':
        return <DashboardPage />;
      case 'clients':
        return <ClientsPage />;
      case 'campaigns':
        return <CampaignsPage />;
      case 'campaign-insights':
        return <CampaignInsightsPage />;
      case 'creators':
        return <CreatorsPage />;
      case 'contents':
        return <ContentsPage />;
      case 'contracts':
        return <ContractsPage />;
      case 'financial':
        return <FinancialPage />;
      case 'insights':
        return <InsightsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="h-screen flex flex-col bg-[#f8f9fa]">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}