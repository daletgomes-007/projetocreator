import { Check } from 'lucide-react';

interface CheckboxCellProps {
  checked: boolean;
}

export function CheckboxCell({ checked }: CheckboxCellProps) {
  return (
    <div className="bg-white px-4 py-3 flex items-center justify-center">
      <div
        className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
          checked
            ? 'bg-blue-600 border-blue-600'
            : 'bg-white border-gray-300 hover:border-gray-400'
        }`}
      >
        {checked && <Check className="w-3.5 h-3.5 text-white" />}
      </div>
    </div>
  );
}
