import { Bell, X, CheckCheck, Trash2 } from 'lucide-react';
import { useNotifications, getNotificationStyle, Notification } from '@/app/contexts/NotificationContext';
import { useApp } from '@/app/contexts/AppContext';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

export function NotificationDropdown() {
  const { notifications, unreadCount, markAsRead, markAllAsRead, clearNotification, clearAllNotifications } = useNotifications();
  const { currentClient, user, setCurrentPage, setSelectedCreatorId } = useApp();

  // Filter notifications based on current context
  const filteredNotifications = currentClient && user?.role === 'client'
    ? notifications.filter(n => n.clientId === currentClient.id)
    : notifications;

  const sortedNotifications = [...filteredNotifications].sort((a, b) => 
    b.timestamp.getTime() - a.timestamp.getTime()
  );

  // Handle notification click - navigate to related page
  const handleNotificationClick = (notification: Notification) => {
    // Mark as read
    if (!notification.read) {
      markAsRead(notification.id);
    }

    // Navigate based on notification type
    switch (notification.type) {
      case 'creator_approved':
      case 'creator_denied':
      case 'creator_submitted':
        setCurrentPage('creators');
        // Set the selected creator ID if available
        if (notification.metadata?.creatorId) {
          setSelectedCreatorId(notification.metadata.creatorId);
        }
        break;
      case 'campaign_created':
        setCurrentPage('campaigns');
        break;
      case 'contract_generated':
        setCurrentPage('contracts');
        break;
      case 'performance_updated':
        setCurrentPage('insights');
        break;
      default:
        setCurrentPage('dashboard');
    }
  };

  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger asChild>
        <button className="p-2 hover:bg-gray-100 rounded-lg relative transition-colors">
          <Bell className="w-5 h-5 text-gray-600" />
          {unreadCount > 0 && (
            <>
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            </>
          )}
        </button>
      </DropdownMenu.Trigger>

      <DropdownMenu.Portal>
        <DropdownMenu.Content
          className="w-[420px] max-h-[600px] bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden"
          sideOffset={8}
          align="end"
        >
          {/* Header */}
          <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900">Notificações</h3>
                <p className="text-xs text-gray-600 mt-0.5">
                  {unreadCount > 0 
                    ? `${unreadCount} não lida${unreadCount > 1 ? 's' : ''}`
                    : 'Todas lidas'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 px-2 py-1 hover:bg-blue-100 rounded transition-colors"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    Marcar todas
                  </button>
                )}
                {sortedNotifications.length > 0 && (
                  <button
                    onClick={clearAllNotifications}
                    className="text-xs text-red-600 hover:text-red-700 font-medium flex items-center gap-1 px-2 py-1 hover:bg-red-100 rounded transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Limpar
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Notifications List */}
          <div className="max-h-[500px] overflow-y-auto">
            {sortedNotifications.length === 0 ? (
              <div className="p-12 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bell className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-sm text-gray-600">Nenhuma notificação</p>
                <p className="text-xs text-gray-500 mt-1">
                  Você está em dia com tudo!
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {sortedNotifications.map((notification) => {
                  const style = getNotificationStyle(notification.type);
                  const timeAgo = formatDistanceToNow(notification.timestamp, {
                    addSuffix: true,
                    locale: ptBR,
                  });

                  return (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-blue-100/50 transition-all group relative cursor-pointer border-l-4 ${
                        !notification.read 
                          ? 'bg-blue-50/50 border-blue-500' 
                          : 'border-transparent hover:border-gray-300'
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                      title="Clique para ir até o item relacionado"
                    >
                      {/* Unread indicator */}
                      {!notification.read && (
                        <div className="absolute left-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-blue-500 rounded-full"></div>
                      )}

                      <div className="flex gap-3 ml-2">
                        {/* Icon */}
                        <div className={`flex-shrink-0 w-10 h-10 ${style.bgColor} ${style.textColor} rounded-lg flex items-center justify-center text-lg font-semibold border ${style.borderColor}`}>
                          {style.icon}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <p className="text-sm font-semibold text-gray-900 mb-0.5">
                                {notification.title}
                              </p>
                              <p className="text-xs text-gray-600 leading-relaxed">
                                {notification.message}
                              </p>
                              <div className="flex items-center gap-2 mt-2">
                                <span className={`text-xs ${style.textColor} font-medium px-2 py-0.5 ${style.bgColor} rounded-full border ${style.borderColor}`}>
                                  {notification.clientName}
                                </span>
                                <span className="text-xs text-gray-500">
                                  {timeAgo}
                                </span>
                              </div>
                            </div>
                            
                            {/* Delete button */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                clearNotification(notification.id);
                                toast.success('Notificação removida com sucesso!');
                              }}
                              className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-red-100 rounded text-red-600"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          {sortedNotifications.length > 0 && (
            <div className="p-3 border-t border-gray-200 bg-gray-50 text-center">
              <p className="text-xs text-gray-600">
                {sortedNotifications.length} notificação{sortedNotifications.length !== 1 ? 'ões' : ''} no total
              </p>
            </div>
          )}
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  );
}