import { useState } from 'react';
import { X, Upload, FileText, Calendar, DollarSign } from 'lucide-react';
import { Invoice, InvoiceType, InvoiceStatus } from '@/app/types/invoice';
import { useInvoices } from '@/app/contexts/InvoiceContext';
import { useApp } from '@/app/contexts/AppContext';
import { toast } from 'sonner';

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice?: Invoice;
}

export function InvoiceModal({ isOpen, onClose, invoice }: InvoiceModalProps) {
  const { addInvoice, updateInvoice } = useInvoices();
  const { currentClient, clients } = useApp();
  
  const isEditing = !!invoice;

  const [formData, setFormData] = useState({
    clientId: invoice?.clientId || currentClient?.id || '',
    type: invoice?.type || 'incoming' as InvoiceType,
    invoiceNumber: invoice?.invoiceNumber || '',
    issueDate: invoice?.issueDate || new Date().toISOString().split('T')[0],
    dueDate: invoice?.dueDate || '',
    paymentDate: invoice?.paymentDate || '',
    amount: invoice?.amount?.toString() || '',
    taxAmount: invoice?.taxAmount?.toString() || '',
    status: invoice?.status || 'pending' as InvoiceStatus,
    description: invoice?.description || '',
    relatedName: invoice?.relatedName || '',
    notes: invoice?.notes || '',
    fileName: invoice?.fileName || '',
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setFormData(prev => ({ ...prev, fileName: file.name }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.clientId || !formData.invoiceNumber || !formData.issueDate || !formData.dueDate || !formData.amount) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    const amount = parseFloat(formData.amount);
    const taxAmount = formData.taxAmount ? parseFloat(formData.taxAmount) : 0;
    const totalAmount = amount + taxAmount;

    const client = clients.find(c => c.id === formData.clientId);

    const invoiceData = {
      clientId: formData.clientId,
      clientName: client?.name || 'Cliente',
      type: formData.type,
      invoiceNumber: formData.invoiceNumber,
      issueDate: formData.issueDate,
      dueDate: formData.dueDate,
      paymentDate: formData.paymentDate || undefined,
      amount,
      taxAmount: taxAmount > 0 ? taxAmount : undefined,
      totalAmount,
      status: formData.status,
      description: formData.description,
      relatedName: formData.relatedName || undefined,
      fileUrl: selectedFile ? '#' : invoice?.fileUrl,
      fileName: formData.fileName || undefined,
      notes: formData.notes || undefined,
    };

    if (isEditing && invoice) {
      updateInvoice(invoice.id, invoiceData);
      toast.success('Nota fiscal atualizada com sucesso!');
    } else {
      addInvoice(invoiceData);
      toast.success('Nota fiscal adicionada com sucesso!');
    }

    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {isEditing ? 'Editar Nota Fiscal' : 'Nova Nota Fiscal'}
              </h2>
              <p className="text-sm text-blue-100 mt-0.5">
                {isEditing ? 'Atualize as informações da nota fiscal' : 'Adicione uma nova nota fiscal ao sistema'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8 overflow-y-auto max-h-[calc(90vh-180px)]">
          <div className="space-y-6">
            {/* Type Selection */}
            <div className="grid grid-cols-2 gap-4">
              <label
                className={`relative flex items-center justify-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                  formData.type === 'incoming'
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <input
                  type="radio"
                  name="type"
                  value="incoming"
                  checked={formData.type === 'incoming'}
                  onChange={handleChange}
                  className="sr-only"
                />
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  formData.type === 'incoming' ? 'bg-green-500' : 'bg-gray-200'
                }`}>
                  <DollarSign className={`w-6 h-6 ${formData.type === 'incoming' ? 'text-white' : 'text-gray-500'}`} />
                </div>
                <div>
                  <p className={`font-semibold ${formData.type === 'incoming' ? 'text-green-700' : 'text-gray-700'}`}>
                    Recebida
                  </p>
                  <p className="text-xs text-gray-500">Do cliente</p>
                </div>
              </label>

              <label
                className={`relative flex items-center justify-center gap-3 p-4 border-2 rounded-xl cursor-pointer transition-all ${
                  formData.type === 'outgoing'
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <input
                  type="radio"
                  name="type"
                  value="outgoing"
                  checked={formData.type === 'outgoing'}
                  onChange={handleChange}
                  className="sr-only"
                />
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  formData.type === 'outgoing' ? 'bg-red-500' : 'bg-gray-200'
                }`}>
                  <DollarSign className={`w-6 h-6 ${formData.type === 'outgoing' ? 'text-white' : 'text-gray-500'}`} />
                </div>
                <div>
                  <p className={`font-semibold ${formData.type === 'outgoing' ? 'text-red-700' : 'text-gray-700'}`}>
                    Emitida
                  </p>
                  <p className="text-xs text-gray-500">Para creator</p>
                </div>
              </label>
            </div>

            {/* Basic Information */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Cliente *
                </label>
                <select
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  required
                >
                  <option value="">Selecione um cliente</option>
                  {clients.map(client => (
                    <option key={client.id} value={client.id}>
                      {client.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Número da NF *
                </label>
                <input
                  type="text"
                  name="invoiceNumber"
                  value={formData.invoiceNumber}
                  onChange={handleChange}
                  placeholder="NF-2025-001"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  required
                />
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Data de Emissão *
                </label>
                <input
                  type="date"
                  name="issueDate"
                  value={formData.issueDate}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Data de Vencimento *
                </label>
                <input
                  type="date"
                  name="dueDate"
                  value={formData.dueDate}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Data de Pagamento
                </label>
                <input
                  type="date"
                  name="paymentDate"
                  value={formData.paymentDate}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Values */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Valor (R$) *
                </label>
                <input
                  type="number"
                  name="amount"
                  value={formData.amount}
                  onChange={handleChange}
                  placeholder="10000.00"
                  step="0.01"
                  min="0"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Impostos (R$)
                </label>
                <input
                  type="number"
                  name="taxAmount"
                  value={formData.taxAmount}
                  onChange={handleChange}
                  placeholder="1000.00"
                  step="0.01"
                  min="0"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Status and Related */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Status
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="pending">Pendente</option>
                  <option value="paid">Pago</option>
                  <option value="overdue">Vencida</option>
                  <option value="cancelled">Cancelada</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Relacionado a
                </label>
                <input
                  type="text"
                  name="relatedName"
                  value={formData.relatedName}
                  onChange={handleChange}
                  placeholder="Nome do creator ou campanha"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Descrição *
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Descrição dos serviços prestados..."
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none"
                required
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Observações
              </label>
              <textarea
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                placeholder="Observações adicionais..."
                rows={2}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none"
              />
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Arquivo da NF (PDF)
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-blue-500 transition-colors">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                />
                <label
                  htmlFor="file-upload"
                  className="flex flex-col items-center gap-2 cursor-pointer"
                >
                  <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                    <Upload className="w-6 h-6 text-blue-600" />
                  </div>
                  <p className="text-sm font-medium text-gray-700">
                    {formData.fileName || 'Clique para fazer upload'}
                  </p>
                  <p className="text-xs text-gray-500">PDF até 10MB</p>
                </label>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all font-medium shadow-lg"
            >
              {isEditing ? 'Atualizar Nota Fiscal' : 'Adicionar Nota Fiscal'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
