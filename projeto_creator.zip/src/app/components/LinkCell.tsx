import { Link as LinkIcon } from 'lucide-react';

interface LinkCellProps {
  url: string;
}

export function LinkCell({ url }: LinkCellProps) {
  if (!url) {
    return (
      <div className="bg-white px-4 py-3 text-sm text-gray-400">
        —
      </div>
    );
  }

  return (
    <div className="bg-white px-4 py-3">
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1.5 text-sm text-blue-600 hover:text-blue-700 hover:underline"
      >
        <LinkIcon className="w-3.5 h-3.5" />
        <span className="truncate">Ver arquivo</span>
      </a>
    </div>
  );
}
