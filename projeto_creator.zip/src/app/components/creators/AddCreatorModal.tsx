import { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import { useCreators } from '@/app/contexts/CreatorsContext';
import { useApp } from '@/app/contexts/AppContext';
import { CreatorStatus } from '@/app/types/creator';
import { toast } from 'sonner';

interface AddCreatorModalProps {
  open: boolean;
  onClose: () => void;
}

export function AddCreatorModal({ open, onClose }: AddCreatorModalProps) {
  const { addCreator } = useCreators();
  const { currentClient, campaigns, currentCampaign } = useApp();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    socialNetwork: 'Instagram' as 'Instagram' | 'TikTok' | 'YouTube' | 'Twitter',
    followers: '',
    averageReach: '',
    engagementRate: '',
    scope: '',
    creatorValue: '',
    clientValue: '',
    internalNotes: '',
    boostStartDate: '',
    boostEndDate: '',
    campaignId: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentClient) {
      toast.error('Nenhum cliente selecionado!');
      return;
    }

    // Busca a primeira campanha ativa do cliente atual
    const activeCampaign = campaigns.find(c => c.clientId === currentClient.id && c.status === 'active');

    addCreator({
      name: formData.name,
      email: formData.email,
      socialNetwork: formData.socialNetwork,
      followers: parseInt(formData.followers),
      averageReach: parseInt(formData.averageReach),
      engagementRate: parseFloat(formData.engagementRate),
      scope: formData.scope,
      creatorValue: parseFloat(formData.creatorValue),
      clientValue: parseFloat(formData.clientValue),
      status: 'in_approval' as CreatorStatus,
      internalNotes: formData.internalNotes,
      contractSigned: false,
      contentDelivered: false,
      clientId: currentClient.id,
      campaignId: formData.campaignId || activeCampaign?.id,
      boostStartDate: formData.boostStartDate || undefined,
      boostEndDate: formData.boostEndDate || undefined,
    });

    toast.success(`Creator adicionado para ${currentClient.name} com sucesso!`);
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      socialNetwork: 'Instagram',
      followers: '',
      averageReach: '',
      engagementRate: '',
      scope: '',
      creatorValue: '',
      clientValue: '',
      internalNotes: '',
      boostStartDate: '',
      boostEndDate: '',
      campaignId: '',
    });
    
    onClose();
  };

  return (
    <Dialog.Root open={open} onOpenChange={onClose}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50 z-50" />
        <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto z-50">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <Dialog.Title className="text-xl font-semibold text-gray-900">
              Adicionar Novo Creator
            </Dialog.Title>
            <Dialog.Close asChild>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </Dialog.Close>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Client Info Banner */}
            {currentClient && (
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900">
                  <span className="font-semibold">Adicionando para:</span> {currentClient.name}
                </p>
                <p className="text-xs text-blue-700 mt-1">
                  ✓ O creator será associado a este cliente<br/>
                  ✓ Status inicial: <span className="font-semibold">Em aprovação</span><br/>
                  ✓ Após aprovação, será automaticamente adicionado à aba de Contratos
                </p>
              </div>
            )}

            {/* Campaign Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Campanha *
              </label>
              <select
                value={formData.campaignId}
                onChange={(e) => setFormData({ ...formData, campaignId: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Selecione uma campanha</option>
                {currentClient && campaigns
                  .filter(c => c.clientId === currentClient.id)
                  .map(campaign => (
                    <option key={campaign.id} value={campaign.id}>
                      {campaign.name} ({campaign.status === 'active' ? 'Ativa' : campaign.status === 'completed' ? 'Concluída' : 'Rascunho'})
                    </option>
                  ))
                }
              </select>
              {currentClient && campaigns.filter(c => c.clientId === currentClient.id).length === 0 && (
                <p className="text-xs text-amber-600 mt-1">
                  ⚠️ Nenhuma campanha criada para este cliente. Crie uma campanha primeiro.
                </p>
              )}
            </div>

            {/* Basic Info */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Informações Básicas</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome do Creator *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Rede Social *
                </label>
                <select
                  value={formData.socialNetwork}
                  onChange={(e) => setFormData({ ...formData, socialNetwork: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="Instagram">Instagram</option>
                  <option value="TikTok">TikTok</option>
                  <option value="YouTube">YouTube</option>
                  <option value="Twitter">Twitter</option>
                </select>
              </div>
            </div>

            {/* Metrics */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Métricas</h3>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Seguidores *
                  </label>
                  <input
                    type="number"
                    value={formData.followers}
                    onChange={(e) => setFormData({ ...formData, followers: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Alcance Médio *
                  </label>
                  <input
                    type="number"
                    value={formData.averageReach}
                    onChange={(e) => setFormData({ ...formData, averageReach: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    % Engajamento *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.engagementRate}
                    onChange={(e) => setFormData({ ...formData, engagementRate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Scope */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Escopo *
              </label>
              <input
                type="text"
                value={formData.scope}
                onChange={(e) => setFormData({ ...formData, scope: e.target.value })}
                placeholder="Ex: 3 posts + 2 stories"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {/* Values */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Valores</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Valor do Creator (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.creatorValue}
                    onChange={(e) => setFormData({ ...formData, creatorValue: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Valor Cobrado do Cliente (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.clientValue}
                    onChange={(e) => setFormData({ ...formData, clientValue: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              {formData.creatorValue && formData.clientValue && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="text-sm text-green-700">
                    <span className="font-semibold">Margem:</span> R$ {(parseFloat(formData.clientValue) - parseFloat(formData.creatorValue)).toFixed(2)} (
                    {(((parseFloat(formData.clientValue) - parseFloat(formData.creatorValue)) / parseFloat(formData.clientValue)) * 100).toFixed(1)}%)
                  </p>
                </div>
              )}
            </div>

            {/* Internal Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Observações Internas
              </label>
              <textarea
                value={formData.internalNotes}
                onChange={(e) => setFormData({ ...formData, internalNotes: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Notas internas sobre o creator..."
              />
            </div>

            {/* Boost Period */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-purple-50 rounded-lg">
                  <Calendar className="w-4 h-4 text-purple-500" />
                </div>
                <h3 className="text-sm font-semibold text-gray-900">Período de Impulsionamento</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Data de Início
                  </label>
                  <input
                    type="date"
                    value={formData.boostStartDate}
                    onChange={(e) => setFormData({ ...formData, boostStartDate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Data de Término
                  </label>
                  <input
                    type="date"
                    value={formData.boostEndDate}
                    onChange={(e) => setFormData({ ...formData, boostEndDate: e.target.value })}
                    min={formData.boostStartDate}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              {formData.boostStartDate && formData.boostEndDate && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                  <p className="text-sm text-purple-700">
                    <span className="font-semibold">Duração:</span> {
                      Math.ceil((new Date(formData.boostEndDate).getTime() - new Date(formData.boostStartDate).getTime()) / (1000 * 60 * 60 * 24))
                    } dias de impulsionamento
                  </p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 px-4 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Adicionar Creator
              </button>
            </div>
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}