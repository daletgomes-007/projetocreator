import {
  Instagram,
  Youtube,
  Twitter,
  CheckCircle2,
  XCircle,
  Clock,
  MessageSquare,
  TrendingUp,
  Users,
  Eye,
  FileText,
  Image as ImageIcon,
  X,
  Mail,
  Phone,
  MapPin,
  Calendar,
  AlertTriangle,
} from 'lucide-react';
import { Creator, CreatorStatus } from '@/app/types/creator';
import { usePermissions } from '@/app/hooks/usePermissions';
import { useCreators } from '@/app/contexts/CreatorsContext';
import { useContracts } from '@/app/contexts/ContractsContext';
import { usePerformance } from '@/app/contexts/PerformanceContext';
import { useNotifications } from '@/app/contexts/NotificationContext';
import { useApp } from '@/app/contexts/AppContext';
import { toast } from 'sonner';
import { useState, forwardRef } from 'react';

interface CreatorCardProps {
  creator: Creator;
  highlighted?: boolean;
}

const socialIcons = {
  Instagram: Instagram,
  TikTok: ImageIcon,
  YouTube: Youtube,
  Twitter: Twitter,
};

const statusConfig: Record<CreatorStatus, { label: string; color: string; bg: string; icon: any }> = {
  in_approval: {
    label: 'Em aprovação',
    color: 'text-yellow-700',
    bg: 'bg-yellow-50 border-yellow-200',
    icon: Clock,
  },
  approved: {
    label: 'Aprovado',
    color: 'text-green-700',
    bg: 'bg-green-50 border-green-200',
    icon: CheckCircle2,
  },
  denied: {
    label: 'Negado',
    color: 'text-red-700',
    bg: 'bg-red-50 border-red-200',
    icon: XCircle,
  },
  negotiating: {
    label: 'Em negociação',
    color: 'text-blue-700',
    bg: 'bg-blue-50 border-blue-200',
    icon: MessageSquare,
  },
  completed: {
    label: 'Finalizado',
    color: 'text-gray-700',
    bg: 'bg-gray-50 border-gray-200',
    icon: CheckCircle2,
  },
};

export const CreatorCard = forwardRef<HTMLDivElement, CreatorCardProps>(
  ({ creator, highlighted }, ref) => {
  const { isAdmin, canViewMargins } = usePermissions();
  const { updateCreator } = useCreators();
  const { addContract, contracts } = useContracts();
  const { addPerformance, getPerformanceByCreator } = usePerformance();
  const { addNotification } = useNotifications();
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const SocialIcon = socialIcons[creator.socialNetwork];
  const status = statusConfig[creator.status];
  const StatusIcon = status.icon;

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  const handleApprove = () => {
    updateCreator(creator.id, { status: 'approved' });
    
    // Adicionar notificação para o admin
    addNotification({
      type: 'creator_approved',
      title: 'Creator Aprovado',
      message: `${creator.name} foi aprovado para a campanha`,
      clientId: creator.clientId,
      clientName: 'Cliente', // Será substituído pelo nome real do cliente
      metadata: {
        creatorName: creator.name,
        creatorId: creator.id,
      },
    });
    
    // Verificar se já existe um contrato para este creator
    const existingContract = contracts.find(c => c.creatorId === creator.id);
    
    if (!existingContract) {
      // Criar automaticamente um contrato pendente
      addContract({
        clientId: creator.clientId,
        creatorId: creator.id,
        creatorName: creator.name,
        creatorEmail: creator.email,
        status: 'pending',
        sentDate: new Date().toISOString().split('T')[0],
        fileUrl: '',
      });
      
      // Notificação de contrato gerado
      addNotification({
        type: 'contract_generated',
        title: 'Contrato Gerado',
        message: `Contrato automático gerado para ${creator.name}`,
        clientId: creator.clientId,
        clientName: 'Cliente',
        metadata: {
          creatorName: creator.name,
          creatorId: creator.id,
        },
      });
    }
    
    // Verificar se já existe um registro de performance para este creator
    const existingPerformance = getPerformanceByCreator(creator.id);
    
    if (!existingPerformance) {
      // Criar automaticamente um registro de performance com status "Aguardando"
      addPerformance({
        creatorId: creator.id,
        clientId: creator.clientId,
        campaignId: creator.campaignId || '',
        creatorName: creator.name,
        instagramHandle: creator.socialNetwork === 'Instagram' ? `@${creator.name.toLowerCase().replace(' ', '')}` : '@creator',
        creatorPhoto: '',
        postUrl: '',
        contentType: 'Reels',
        publicationStatus: 'Aguardando',
        publicationDate: undefined,
        impressions: 0,
        reach: 0,
        likes: 0,
        comments: 0,
        shares: 0,
        saves: 0,
        totalEngagement: 0,
        engagementRate: 0,
        performanceLevel: 'low',
        creatorCost: creator.creatorValue,
        attributedRevenue: 0,
        estimatedROI: 0,
        margin: -creator.creatorValue,
      });
      
      toast.success(`${creator.name} foi aprovado e adicionado à Performance!`);
    } else {
      toast.success(`${creator.name} foi aprovado!`);
    }
  };

  const handleDeny = () => {
    updateCreator(creator.id, { status: 'denied' });
    
    // Adicionar notificação para o admin
    addNotification({
      type: 'creator_denied',
      title: 'Creator Reprovado',
      message: `${creator.name} foi reprovado`,
      clientId: creator.clientId,
      clientName: 'Cliente',
      metadata: {
        creatorName: creator.name,
        creatorId: creator.id,
      },
    });
    
    toast.error(`${creator.name} foi negado.`);
  };

  const handleContinueNegotiation = () => {
    toast.info('Abrindo chat de negociação...');
  };

  const handleViewDetails = () => {
    setShowDetailsModal(true);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return num.toString();
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(num);
  };

  const margin = creator.clientValue - creator.creatorValue;
  const marginPercentage = ((margin / creator.clientValue) * 100).toFixed(1);

  // Calcular dias restantes de impulsionamento
  const getDaysRemaining = (endDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(0, 0, 0, 0);
    const diffTime = end.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  const daysRemaining = creator.boostEndDate ? getDaysRemaining(creator.boostEndDate) : null;
  const showBoostAlert = daysRemaining !== null && daysRemaining >= 0 && daysRemaining <= 2;

  return (
    <div 
      ref={ref}
      className={`bg-white rounded-xl border-2 overflow-hidden hover:shadow-lg transition-all ${ 
        highlighted 
          ? 'border-blue-500 shadow-xl ring-4 ring-blue-200 animate-pulse' 
          : 'border-gray-200'
      }`}
    >
      {/* Header */}
      <div className="p-4 md:p-6 pb-3 md:pb-4">
        <div className="flex items-start gap-3 md:gap-4">
          <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-base md:text-xl">
              {getInitials(creator.name)}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-1 truncate">{creator.name}</h3>
            <div className="flex items-center gap-2 text-xs md:text-sm text-gray-600">
              <SocialIcon className="w-3.5 h-3.5 md:w-4 md:h-4" />
              <span>{creator.socialNetwork}</span>
            </div>
          </div>
          <div className={`inline-flex items-center gap-1 md:gap-1.5 px-2 md:px-3 py-1 md:py-1.5 rounded-full border ${status.bg} ${status.color} text-xs font-medium`}>
            <StatusIcon className="w-3 h-3 md:w-3.5 md:h-3.5" />
            <span className="hidden sm:inline">{status.label}</span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 md:px-6 pb-3 md:pb-4 grid grid-cols-3 gap-3 md:gap-4">
        <div>
          <div className="flex items-center gap-1 md:gap-1.5 text-gray-500 mb-1">
            <Users className="w-3 h-3 md:w-3.5 md:h-3.5" />
            <span className="text-xs">Seguidores</span>
          </div>
          <p className="text-xs md:text-sm font-semibold text-gray-900">{formatNumber(creator.followers)}</p>
        </div>
        <div>
          <div className="flex items-center gap-1 md:gap-1.5 text-gray-500 mb-1">
            <Eye className="w-3 h-3 md:w-3.5 md:h-3.5" />
            <span className="text-xs">Alcance</span>
          </div>
          <p className="text-xs md:text-sm font-semibold text-gray-900">{formatNumber(creator.averageReach)}</p>
        </div>
        <div>
          <div className="flex items-center gap-1 md:gap-1.5 text-gray-500 mb-1">
            <TrendingUp className="w-3 h-3 md:w-3.5 md:h-3.5" />
            <span className="text-xs">Eng.</span>
          </div>
          <p className="text-xs md:text-sm font-semibold text-gray-900">{creator.engagementRate.toFixed(1)}%</p>
        </div>
      </div>

      {/* Scope */}
      <div className="px-4 md:px-6 pb-3 md:pb-4">
        <div className="bg-gray-50 rounded-lg p-2 md:p-3">
          <p className="text-xs text-gray-500 mb-1">Escopo</p>
          <p className="text-xs md:text-sm text-gray-900 font-medium line-clamp-2">{creator.scope}</p>
        </div>
      </div>

      {/* Values */}
      <div className="px-4 md:px-6 pb-3 md:pb-4 space-y-2 md:space-y-3">
        {canViewMargins && (
          <div className="flex items-center justify-between text-xs md:text-sm">
            <span className="text-gray-600">Valor creator:</span>
            <span className="font-medium text-gray-900">{formatCurrency(creator.creatorValue)}</span>
          </div>
        )}
        <div className="flex items-center justify-between text-xs md:text-sm">
          <span className="text-gray-600">Valor da campanha:</span>
          <span className="font-semibold text-gray-900">{formatCurrency(creator.clientValue)}</span>
        </div>
        {canViewMargins && (
          <div className="flex items-center justify-between text-xs md:text-sm pt-2 border-t border-gray-200">
            <span className="text-gray-600">Margem:</span>
            <span className="font-semibold text-green-600">
              {formatCurrency(margin)} ({marginPercentage}%)
            </span>
          </div>
        )}
      </div>

      {/* Internal Notes (Admin Only) */}
      {isAdmin && creator.internalNotes && (
        <div className="px-4 md:px-6 pb-3 md:pb-4">
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-2 md:p-3">
            <p className="text-xs text-purple-700 font-medium mb-1">Observações internas</p>
            <p className="text-xs text-purple-900 line-clamp-2">{creator.internalNotes}</p>
          </div>
        </div>
      )}

      {/* Status Indicators */}
      <div className="px-4 md:px-6 pb-3 md:pb-4 flex flex-wrap gap-2 md:gap-3">
        <div className={`flex items-center gap-1 md:gap-1.5 text-xs ${creator.contractSigned ? 'text-green-600' : 'text-gray-400'}`}>
          <FileText className="w-3 h-3 md:w-3.5 md:h-3.5" />
          <span>Contrato {creator.contractSigned ? 'assinado' : 'pendente'}</span>
        </div>
        <div className={`flex items-center gap-1 md:gap-1.5 text-xs ${creator.contentDelivered ? 'text-green-600' : 'text-gray-400'}`}>
          <ImageIcon className="w-3 h-3 md:w-3.5 md:h-3.5" />
          <span>Conteúdo {creator.contentDelivered ? 'entregue' : 'pendente'}</span>
        </div>
      </div>

      {/* Actions */}
      <div className="px-4 md:px-6 pb-4 md:pb-6">
        {!isAdmin && creator.status === 'in_approval' ? (
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={handleApprove}
                className="py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Aprovar
              </button>
              <button 
                onClick={handleDeny}
                className="py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
              >
                <XCircle className="w-4 h-4" />
                Reprovar
              </button>
            </div>
            <button 
              onClick={handleViewDetails}
              className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
            >
              <Eye className="w-4 h-4" />
              Ver detalhes
            </button>
          </div>
        ) : (
          <button 
            onClick={handleViewDetails}
            className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
          >
            <Eye className="w-4 h-4" />
            Ver detalhes
          </button>
        )}
      </div>

      {/* Details Modal */}
      {showDetailsModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-2 md:p-4">
          <div className="bg-white rounded-xl md:rounded-2xl max-w-3xl w-full max-h-[95vh] md:max-h-[90vh] overflow-y-auto shadow-2xl">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white border-b border-gray-200 px-4 md:px-8 py-4 md:py-6 flex items-center justify-between">
              <div className="flex items-center gap-3 md:gap-4">
                <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-lg md:text-2xl">
                    {getInitials(creator.name)}
                  </span>
                </div>
                <div>
                  <h2 className="text-lg md:text-2xl font-bold text-gray-900">{creator.name}</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <SocialIcon className="w-3.5 h-3.5 md:w-4 md:h-4 text-gray-600" />
                    <span className="text-xs md:text-sm text-gray-600">{creator.socialNetwork}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 md:w-6 md:h-6 text-gray-500" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-4 md:p-8 space-y-4 md:space-y-6">
              {/* Boost Alert - Show when 2 days or less remaining */}
              {showBoostAlert && (
                <div className="bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-300 rounded-xl p-4 md:p-5 animate-pulse">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-500 rounded-lg">
                      <AlertTriangle className="w-5 h-5 md:w-6 md:h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-base md:text-lg font-bold text-orange-900">
                        ⚠️ Alerta de Impulsionamento
                      </p>
                      <p className="text-xs md:text-sm text-orange-800 mt-1">
                        {daysRemaining === 0 ? 'O período de impulsionamento termina HOJE!' : 
                         daysRemaining === 1 ? 'Falta 1 dia para o fim do impulsionamento!' :
                         `Faltam ${daysRemaining} dias para o fim do impulsionamento!`}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Status Badge */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between gap-3">
                <div className={`inline-flex items-center gap-2 px-3 md:px-4 py-1.5 md:py-2 rounded-full border ${status.bg} ${status.color} text-sm font-medium`}>
                  <StatusIcon className="w-3.5 h-3.5 md:w-4 md:h-4" />
                  {status.label}
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className={`flex items-center gap-2 text-xs md:text-sm ${creator.contractSigned ? 'text-green-600' : 'text-gray-400'}`}>
                    <FileText className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    <span>Contrato {creator.contractSigned ? 'assinado' : 'pendente'}</span>
                  </div>
                  <div className={`flex items-center gap-2 text-xs md:text-sm ${creator.contentDelivered ? 'text-green-600' : 'text-gray-400'}`}>
                    <ImageIcon className="w-3.5 h-3.5 md:w-4 md:h-4" />
                    <span>Conteúdo {creator.contentDelivered ? 'entregue' : 'pendente'}</span>
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div className="bg-gray-50 rounded-xl p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3 md:mb-4">Informações de Contato</h3>
                <div className="space-y-2 md:space-y-3">
                  <div className="flex items-center gap-2 md:gap-3">
                    <Mail className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
                    <span className="text-sm md:text-base text-gray-900 break-all">{creator.email}</span>
                  </div>
                  <div className="flex items-center gap-2 md:gap-3">
                    <Phone className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
                    <span className="text-sm md:text-base text-gray-900">{creator.phone || '(11) 98765-4321'}</span>
                  </div>
                  <div className="flex items-center gap-2 md:gap-3">
                    <MapPin className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
                    <span className="text-sm md:text-base text-gray-900">{creator.location || 'São Paulo, SP'}</span>
                  </div>
                </div>
              </div>

              {/* Stats Grid */}
              <div>
                <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3 md:mb-4">Métricas</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4">
                  <div className="bg-blue-50 rounded-xl p-4 md:p-5 border border-blue-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="w-4 h-4 md:w-5 md:h-5 text-blue-600" />
                      <span className="text-xs md:text-sm text-blue-700 font-medium">Seguidores</span>
                    </div>
                    <p className="text-xl md:text-2xl font-bold text-blue-900">{formatNumber(creator.followers)}</p>
                  </div>
                  <div className="bg-purple-50 rounded-xl p-4 md:p-5 border border-purple-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Eye className="w-4 h-4 md:w-5 md:h-5 text-purple-600" />
                      <span className="text-xs md:text-sm text-purple-700 font-medium">Alcance Médio</span>
                    </div>
                    <p className="text-xl md:text-2xl font-bold text-purple-900">{formatNumber(creator.averageReach)}</p>
                  </div>
                  <div className="bg-green-50 rounded-xl p-4 md:p-5 border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-green-600" />
                      <span className="text-xs md:text-sm text-green-700 font-medium">Engajamento</span>
                    </div>
                    <p className="text-xl md:text-2xl font-bold text-green-900">{creator.engagementRate.toFixed(1)}%</p>
                  </div>
                </div>
              </div>

              {/* Scope */}
              <div>
                <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3">Escopo do Trabalho</h3>
                <div className="bg-gray-50 rounded-xl p-4 md:p-5 border border-gray-200">
                  <p className="text-sm md:text-base text-gray-900">{creator.scope}</p>
                </div>
              </div>

              {/* Financial Info */}
              <div>
                <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3">Informações Financeiras</h3>
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4 md:p-6 border-2 border-green-200">
                  <div className="space-y-3 md:space-y-4">
                    {canViewMargins && (
                      <div className="flex items-center justify-between pb-3 border-b border-green-200">
                        <span className="text-sm md:text-base text-gray-700 font-medium">Valor Creator:</span>
                        <span className="text-lg md:text-xl font-bold text-gray-900">{formatCurrency(creator.creatorValue)}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between pb-3 border-b border-green-200">
                      <span className="text-sm md:text-base text-gray-700 font-medium">Valor da Campanha:</span>
                      <span className="text-lg md:text-xl font-bold text-gray-900">{formatCurrency(creator.clientValue)}</span>
                    </div>
                    {canViewMargins && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm md:text-base text-green-700 font-medium">Margem:</span>
                        <div className="text-right">
                          <p className="text-xl md:text-2xl font-bold text-green-600">{formatCurrency(margin)}</p>
                          <p className="text-xs md:text-sm text-green-600">({marginPercentage}%)</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Boost Period */}
              {(creator.boostStartDate || creator.boostEndDate) && (
                <div>
                  <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3">Período de Impulsionamento</h3>
                  <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 md:p-6 border-2 border-purple-200">
                    <div className="space-y-3 md:space-y-4">
                      {creator.boostStartDate && (
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-purple-100 rounded-lg">
                            <Calendar className="w-4 h-4 md:w-5 md:h-5 text-purple-600" />
                          </div>
                          <div>
                            <p className="text-xs text-purple-700 font-medium">Data de Início</p>
                            <p className="text-base md:text-lg font-bold text-purple-900">{formatDate(creator.boostStartDate)}</p>
                          </div>
                        </div>
                      )}
                      {creator.boostEndDate && (
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-pink-100 rounded-lg">
                            <Calendar className="w-4 h-4 md:w-5 md:h-5 text-pink-600" />
                          </div>
                          <div>
                            <p className="text-xs text-pink-700 font-medium">Data de Término</p>
                            <p className="text-base md:text-lg font-bold text-pink-900">{formatDate(creator.boostEndDate)}</p>
                          </div>
                        </div>
                      )}
                      {creator.boostStartDate && creator.boostEndDate && (
                        <div className="pt-3 border-t border-purple-200">
                          <div className="flex items-center justify-between">
                            <span className="text-sm md:text-base text-purple-700 font-medium">Duração Total:</span>
                            <span className="text-lg md:text-xl font-bold text-purple-900">
                              {Math.ceil((new Date(creator.boostEndDate).getTime() - new Date(creator.boostStartDate).getTime()) / (1000 * 60 * 60 * 24))} dias
                            </span>
                          </div>
                          {daysRemaining !== null && daysRemaining >= 0 && (
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-sm md:text-base text-purple-700 font-medium">Dias Restantes:</span>
                              <span className={`text-lg md:text-xl font-bold ${daysRemaining <= 2 ? 'text-orange-600' : 'text-purple-900'}`}>
                                {daysRemaining} {daysRemaining === 1 ? 'dia' : 'dias'}
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Internal Notes */}
              {isAdmin && creator.internalNotes && (
                <div>
                  <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3">Observações Internas</h3>
                  <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 md:p-5">
                    <p className="text-sm md:text-base text-purple-900">{creator.internalNotes}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-4 md:px-8 py-4 md:py-6">
              {!isAdmin && creator.status === 'in_approval' ? (
                <div className="space-y-2 md:space-y-3">
                  <div className="grid grid-cols-2 gap-2 md:gap-3">
                    <button
                      onClick={() => {
                        handleApprove();
                        setShowDetailsModal(false);
                      }}
                      className="py-2.5 md:py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="hidden sm:inline">Aprovar Creator</span>
                      <span className="sm:hidden">Aprovar</span>
                    </button>
                    <button
                      onClick={() => {
                        handleDeny();
                        setShowDetailsModal(false);
                      }}
                      className="py-2.5 md:py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
                    >
                      <XCircle className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="hidden sm:inline">Reprovar Creator</span>
                      <span className="sm:hidden">Reprovar</span>
                    </button>
                  </div>
                  <button
                    onClick={() => setShowDetailsModal(false)}
                    className="w-full py-2.5 md:py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium"
                  >
                    Fechar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="w-full py-2.5 md:py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  Fechar
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

CreatorCard.displayName = 'CreatorCard';