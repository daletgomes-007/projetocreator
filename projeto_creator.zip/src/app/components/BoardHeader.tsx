import { useState } from 'react';
import { Edit2, Check } from 'lucide-react';

interface BoardHeaderProps {
  clientName: string;
  campaignName: string;
  onClientNameChange: (name: string) => void;
  onCampaignNameChange: (name: string) => void;
}

export function BoardHeader({
  clientName,
  campaignName,
  onClientNameChange,
  onCampaignNameChange,
}: BoardHeaderProps) {
  const [editingClient, setEditingClient] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(false);
  const [tempClient, setTempClient] = useState(clientName);
  const [tempCampaign, setTempCampaign] = useState(campaignName);

  const handleClientSave = () => {
    onClientNameChange(tempClient);
    setEditingClient(false);
  };

  const handleCampaignSave = () => {
    onCampaignNameChange(tempCampaign);
    setEditingCampaign(false);
  };

  return (
    <div className="bg-white border-b border-gray-200 px-6 py-6 sticky top-0 z-10">
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500">Cliente:</span>
          {editingClient ? (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={tempClient}
                onChange={(e) => setTempClient(e.target.value)}
                className="text-2xl font-semibold text-gray-900 border-b-2 border-blue-500 outline-none bg-transparent px-1"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleClientSave();
                  if (e.key === 'Escape') {
                    setTempClient(clientName);
                    setEditingClient(false);
                  }
                }}
              />
              <button
                onClick={handleClientSave}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <Check className="w-4 h-4 text-green-600" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 group">
              <h1 className="text-2xl font-semibold text-gray-900">{clientName}</h1>
              <button
                onClick={() => setEditingClient(true)}
                className="p-1 opacity-0 group-hover:opacity-100 hover:bg-gray-100 rounded transition-opacity"
              >
                <Edit2 className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500">Campanha:</span>
          {editingCampaign ? (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={tempCampaign}
                onChange={(e) => setTempCampaign(e.target.value)}
                className="text-xl font-medium text-gray-700 border-b-2 border-blue-500 outline-none bg-transparent px-1"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCampaignSave();
                  if (e.key === 'Escape') {
                    setTempCampaign(campaignName);
                    setEditingCampaign(false);
                  }
                }}
              />
              <button
                onClick={handleCampaignSave}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <Check className="w-4 h-4 text-green-600" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 group">
              <h2 className="text-xl font-medium text-gray-700">{campaignName}</h2>
              <button
                onClick={() => setEditingCampaign(true)}
                className="p-1 opacity-0 group-hover:opacity-100 hover:bg-gray-100 rounded transition-opacity"
              >
                <Edit2 className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
