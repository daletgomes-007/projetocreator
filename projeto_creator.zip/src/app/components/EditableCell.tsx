interface EditableCellProps {
  value: string;
  align?: 'left' | 'right' | 'center';
}

export function EditableCell({ value, align = 'left' }: EditableCellProps) {
  const alignClass = {
    left: 'text-left',
    right: 'text-right',
    center: 'text-center',
  }[align];

  return (
    <div className={`bg-white px-4 py-3 text-sm text-gray-700 ${alignClass} truncate`}>
      {value || '—'}
    </div>
  );
}
