import { ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { Creator, DeniedCreator } from '@/app/components/Board';
import { CreatorRow } from '@/app/components/CreatorRow';
import { DeniedCreatorRow } from '@/app/components/DeniedCreatorRow';

interface CreatorGroupProps {
  title: string;
  color: string;
  creators?: Creator[];
  deniedCreators?: DeniedCreator[];
  type: 'approval' | 'approved' | 'denied';
}

export function CreatorGroup({ title, color, creators, deniedCreators, type }: CreatorGroupProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  const count = creators?.length || deniedCreators?.length || 0;

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      {/* Group Header */}
      <div
        className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-50 transition-colors"
        style={{ borderLeft: `4px solid ${color}` }}
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        <button className="p-0.5">
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4 text-gray-600" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-600" />
          )}
        </button>
        <h3 className="font-semibold text-gray-900">{title}</h3>
        <span className="text-sm text-gray-500">({count})</span>
      </div>

      {/* Table */}
      {!isCollapsed && (
        <div className="overflow-x-auto">
          {type === 'denied' ? (
            <DeniedCreatorsTable deniedCreators={deniedCreators || []} />
          ) : (
            <CreatorsTable creators={creators || []} />
          )}
        </div>
      )}
    </div>
  );
}

function CreatorsTable({ creators }: { creators: Creator[] }) {
  return (
    <div className="min-w-max">
      {/* Header Row */}
      <div className="grid grid-cols-[200px_150px_120px_120px_100px_180px_140px_140px_120px_120px_150px_120px_180px_120px_120px_120px] gap-px bg-gray-200 border-t border-gray-200">
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Nome do creator</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Rede social</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Seguidores</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Alcance</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">% Eng.</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Escopo</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Valor creator</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Valor agência</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Contrato</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Conteúdo</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Aprovação</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Publicação</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Cód. impulsionamento</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Impulsionamento</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">NF creator</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Conf. pagamento</div>
      </div>

      {/* Data Rows */}
      {creators.length === 0 ? (
        <div className="px-4 py-8 text-center text-gray-400 text-sm">
          Nenhum creator neste grupo
        </div>
      ) : (
        creators.map((creator) => (
          <CreatorRow key={creator.id} creator={creator} />
        ))
      )}
    </div>
  );
}

function DeniedCreatorsTable({ deniedCreators }: { deniedCreators: DeniedCreator[] }) {
  return (
    <div className="min-w-max">
      {/* Header Row */}
      <div className="grid grid-cols-[250px_250px_1fr] gap-px bg-gray-200 border-t border-gray-200">
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Nome</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Email</div>
        <div className="bg-[#f6f7fb] px-4 py-3 text-xs font-semibold text-gray-600">Observação</div>
      </div>

      {/* Data Rows */}
      {deniedCreators.length === 0 ? (
        <div className="px-4 py-8 text-center text-gray-400 text-sm">
          Nenhum creator negado
        </div>
      ) : (
        deniedCreators.map((creator) => (
          <DeniedCreatorRow key={creator.id} creator={creator} />
        ))
      )}
    </div>
  );
}
