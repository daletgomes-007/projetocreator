import { useState } from 'react';
import { Edit2 } from 'lucide-react';
import { BoardHeader } from '@/app/components/BoardHeader';
import { CreatorGroup } from '@/app/components/CreatorGroup';

export type ApprovalStatus = 'approved' | 'in_approval' | 'adjustment';

export interface Creator {
  id: string;
  name: string;
  socialNetwork: string;
  followers: number;
  reach: number;
  engagement: number;
  scope: string;
  creatorValue: number;
  agencyValue: number;
  contractLink: string;
  contentLink: string;
  approvalStatus: ApprovalStatus;
  publicationLink: string;
  boostCode: string;
  hasBoosting: boolean;
  invoiceLink: string;
  paymentConfirmed: boolean;
}

export interface DeniedCreator {
  id: string;
  name: string;
  email: string;
  observation: string;
}

export function Board() {
  const [clientName, setClientName] = useState('OdontoCompany');
  const [campaignName, setCampaignName] = useState('Campanha 2026');
  
  const [creatorsForApproval, setCreatorsForApproval] = useState<Creator[]>([
    {
      id: '1',
      name: 'Ana Paula Silva',
      socialNetwork: 'Instagram',
      followers: 125000,
      reach: 98000,
      engagement: 4.2,
      scope: '3 posts + 2 stories',
      creatorValue: 8000,
      agencyValue: 10000,
      contractLink: 'https://example.com/contract1.pdf',
      contentLink: '',
      approvalStatus: 'in_approval',
      publicationLink: '',
      boostCode: '',
      hasBoosting: false,
      invoiceLink: '',
      paymentConfirmed: false,
    },
    {
      id: '2',
      name: 'Carlos Mendes',
      socialNetwork: 'TikTok',
      followers: 450000,
      reach: 320000,
      engagement: 6.8,
      scope: '5 vídeos',
      creatorValue: 15000,
      agencyValue: 18500,
      contractLink: 'https://example.com/contract2.pdf',
      contentLink: 'https://example.com/content2.zip',
      approvalStatus: 'adjustment',
      publicationLink: '',
      boostCode: '',
      hasBoosting: false,
      invoiceLink: '',
      paymentConfirmed: false,
    },
  ]);
  
  const [approvedCreators, setApprovedCreators] = useState<Creator[]>([
    {
      id: '3',
      name: 'Mariana Costa',
      socialNetwork: 'Instagram',
      followers: 280000,
      reach: 215000,
      engagement: 5.4,
      scope: '2 posts + 3 reels',
      creatorValue: 12000,
      agencyValue: 15000,
      contractLink: 'https://example.com/contract3.pdf',
      contentLink: 'https://example.com/content3.zip',
      approvalStatus: 'approved',
      publicationLink: 'https://instagram.com/p/example',
      boostCode: 'BOOST2026A',
      hasBoosting: true,
      invoiceLink: 'https://example.com/invoice3.pdf',
      paymentConfirmed: true,
    },
  ]);
  
  const [deniedCreators, setDeniedCreators] = useState<DeniedCreator[]>([
    {
      id: '4',
      name: 'Roberto Alves',
      email: 'roberto.alves@email.com',
      observation: 'Público não alinhado com a campanha. Engajamento abaixo do esperado.',
    },
  ]);

  return (
    <div className="h-full overflow-auto">
      <BoardHeader
        clientName={clientName}
        campaignName={campaignName}
        onClientNameChange={setClientName}
        onCampaignNameChange={setCampaignName}
      />
      
      <div className="p-6 space-y-4">
        <CreatorGroup
          title="Creators para aprovação"
          color="#00c875"
          creators={creatorsForApproval}
          type="approval"
        />
        
        <CreatorGroup
          title="Creators aprovados"
          color="#00ca72"
          creators={approvedCreators}
          type="approved"
        />
        
        <CreatorGroup
          title="Creators negados"
          color="#e2445c"
          deniedCreators={deniedCreators}
          type="denied"
        />
      </div>
    </div>
  );
}