// Dados mockados centralizados e separados por cliente

export interface Content {
  id: string;
  clientId: string;
  creatorName: string;
  type: 'post' | 'story' | 'reel' | 'video';
  status: 'submitted' | 'approved' | 'rejected';
  submittedDate: string;
  thumbnail: string;
  feedback?: string;
  postUrl?: string;
}

export interface Contract {
  id: string;
  clientId: string;
  creatorId: string;
  creatorName: string;
  creatorEmail: string;
  status: 'sent' | 'signed' | 'pending';
  sentDate: string;
  signedDate?: string;
  fileUrl: string;
}

export interface FinancialRecord {
  id: string;
  clientId: string;
  creatorName: string;
  type: 'payment' | 'invoice';
  amount: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
  paidDate?: string;
  campaign: string;
}

// ==================== CONTEÚDOS ====================

export const mockContents: Content[] = [
  // OdontoCompany (clientId: '1')
  {
    id: 'cont-odonto-1',
    clientId: '1',
    creatorName: 'Mariana Costa',
    type: 'post',
    status: 'approved',
    submittedDate: '2026-01-25',
    thumbnail: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-odonto-2',
    clientId: '1',
    creatorName: 'Mariana Costa',
    type: 'reel',
    status: 'approved',
    submittedDate: '2026-01-26',
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-odonto-3',
    clientId: '1',
    creatorName: 'Rafael Santos',
    type: 'video',
    status: 'submitted',
    submittedDate: '2026-01-28',
    thumbnail: 'https://images.unsplash.com/photo-1598214886806-c87b84b7078b?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-odonto-4',
    clientId: '1',
    creatorName: 'Ana Paula Silva',
    type: 'story',
    status: 'rejected',
    submittedDate: '2026-01-27',
    thumbnail: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&h=400&fit=crop',
    feedback: 'Não está alinhado com a identidade visual da campanha',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },

  // SamsClub (clientId: '2')
  {
    id: 'cont-sams-1',
    clientId: '2',
    creatorName: 'Carla Souza',
    type: 'post',
    status: 'approved',
    submittedDate: '2026-01-23',
    thumbnail: 'https://images.unsplash.com/photo-1534452203293-494d7ddbf7e0?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-sams-2',
    clientId: '2',
    creatorName: 'Pedro Lima',
    type: 'reel',
    status: 'submitted',
    submittedDate: '2026-01-27',
    thumbnail: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-sams-3',
    clientId: '2',
    creatorName: 'Carla Souza',
    type: 'story',
    status: 'approved',
    submittedDate: '2026-01-24',
    thumbnail: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },

  // Positivo (clientId: '3')
  {
    id: 'cont-positivo-1',
    clientId: '3',
    creatorName: 'Felipe Castanhari',
    type: 'video',
    status: 'approved',
    submittedDate: '2026-01-22',
    thumbnail: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-positivo-2',
    clientId: '3',
    creatorName: 'Alanzoka',
    type: 'reel',
    status: 'approved',
    submittedDate: '2026-01-24',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
  {
    id: 'cont-positivo-3',
    clientId: '3',
    creatorName: 'Bianca Andrade',
    type: 'post',
    status: 'submitted',
    submittedDate: '2026-01-29',
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=400&fit=crop',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
  },
];

// ==================== CONTRATOS ====================

export const mockContracts: Contract[] = [
  // OdontoCompany (clientId: '1')
  {
    id: 'contract-odonto-1',
    clientId: '1',
    creatorId: '3',
    creatorName: 'Mariana Costa',
    creatorEmail: 'mariana.costa@email.com',
    status: 'signed',
    sentDate: '2026-01-20',
    signedDate: '2026-01-22',
    fileUrl: 'https://example.com/contract1.pdf',
  },
  {
    id: 'contract-odonto-2',
    clientId: '1',
    creatorId: '4',
    creatorName: 'Rafael Santos',
    creatorEmail: 'rafael.santos@email.com',
    status: 'sent',
    sentDate: '2026-01-21',
    fileUrl: 'https://example.com/contract2.pdf',
  },
  {
    id: 'contract-odonto-3',
    clientId: '1',
    creatorId: '5',
    creatorName: 'Ana Paula Silva',
    creatorEmail: 'ana.paula@email.com',
    status: 'pending',
    sentDate: '2026-01-23',
    fileUrl: '',
  },

  // SamsClub (clientId: '2')
  {
    id: 'contract-sams-1',
    clientId: '2',
    creatorId: '6',
    creatorName: 'Carla Souza',
    creatorEmail: 'carla.souza@email.com',
    status: 'signed',
    sentDate: '2026-01-18',
    signedDate: '2026-01-20',
    fileUrl: 'https://example.com/contract-sams1.pdf',
  },
  {
    id: 'contract-sams-2',
    clientId: '2',
    creatorId: '7',
    creatorName: 'Pedro Lima',
    creatorEmail: 'pedro.lima@email.com',
    status: 'pending',
    sentDate: '2026-01-22',
    fileUrl: '',
  },

  // Positivo (clientId: '3')
  {
    id: 'contract-positivo-1',
    clientId: '3',
    creatorId: '8',
    creatorName: 'Felipe Castanhari',
    creatorEmail: 'felipe@email.com',
    status: 'signed',
    sentDate: '2026-01-15',
    signedDate: '2026-01-17',
    fileUrl: 'https://example.com/contract-positivo1.pdf',
  },
  {
    id: 'contract-positivo-2',
    clientId: '3',
    creatorId: '9',
    creatorName: 'Alanzoka',
    creatorEmail: 'alan@email.com',
    status: 'signed',
    sentDate: '2026-01-16',
    signedDate: '2026-01-18',
    fileUrl: 'https://example.com/contract-positivo2.pdf',
  },
  {
    id: 'contract-positivo-3',
    clientId: '3',
    creatorId: '10',
    creatorName: 'Bianca Andrade',
    creatorEmail: 'bianca@email.com',
    status: 'sent',
    sentDate: '2026-01-25',
    fileUrl: 'https://example.com/contract-positivo3.pdf',
  },
];

// ==================== FINANCEIRO ====================

export const mockFinancialRecords: FinancialRecord[] = [
  // OdontoCompany (clientId: '1')
  {
    id: 'fin-odonto-1',
    clientId: '1',
    creatorName: 'Mariana Costa',
    type: 'payment',
    amount: 8000,
    status: 'paid',
    dueDate: '2026-01-30',
    paidDate: '2026-01-28',
    campaign: 'Campanha Verão Sorriso 2026',
  },
  {
    id: 'fin-odonto-2',
    clientId: '1',
    creatorName: 'Rafael Santos',
    type: 'payment',
    amount: 5500,
    status: 'pending',
    dueDate: '2026-02-05',
    campaign: 'Campanha Verão Sorriso 2026',
  },
  {
    id: 'fin-odonto-3',
    clientId: '1',
    creatorName: 'Ana Paula Silva',
    type: 'payment',
    amount: 7200,
    status: 'overdue',
    dueDate: '2026-01-25',
    campaign: 'Aparelhos Invisíveis',
  },

  // SamsClub (clientId: '2')
  {
    id: 'fin-sams-1',
    clientId: '2',
    creatorName: 'Carla Souza',
    type: 'payment',
    amount: 12000,
    status: 'paid',
    dueDate: '2026-01-28',
    paidDate: '2026-01-27',
    campaign: 'Black Friday 2026',
  },
  {
    id: 'fin-sams-2',
    clientId: '2',
    creatorName: 'Pedro Lima',
    type: 'payment',
    amount: 9500,
    status: 'pending',
    dueDate: '2026-02-10',
    campaign: 'Black Friday 2026',
  },

  // Positivo (clientId: '3')
  {
    id: 'fin-positivo-1',
    clientId: '3',
    creatorName: 'Felipe Castanhari',
    type: 'payment',
    amount: 25000,
    status: 'paid',
    dueDate: '2026-01-20',
    paidDate: '2026-01-19',
    campaign: 'Volta às Aulas 2026',
  },
  {
    id: 'fin-positivo-2',
    clientId: '3',
    creatorName: 'Alanzoka',
    type: 'payment',
    amount: 18000,
    status: 'paid',
    dueDate: '2026-01-22',
    paidDate: '2026-01-21',
    campaign: 'Volta às Aulas 2026',
  },
  {
    id: 'fin-positivo-3',
    clientId: '3',
    creatorName: 'Bianca Andrade',
    type: 'payment',
    amount: 14000,
    status: 'pending',
    dueDate: '2026-02-15',
    campaign: 'Profissionais Home Office',
  },
];
