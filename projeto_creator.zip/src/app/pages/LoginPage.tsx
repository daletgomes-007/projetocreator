import { useState } from 'react';
import { LogIn } from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';

export function LoginPage() {
  const { clients = [], clientUsers = [], setUser, setCurrentClient, setCurrentPage } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Detecta o tipo de usuário baseado no email
    const isAdmin = email.includes('@agencia.com') || email.toLowerCase().includes('admin');
    
    if (isAdmin) {
      // Login como Admin
      setUser({
        id: '1',
        name: 'João Silva',
        email: email,
        role: 'admin',
      });
      setCurrentClient(clients[0]);
    } else {
      // Login como Cliente - identifica qual cliente pelo email
      const clientUser = clientUsers.find(cu => cu.email === email);
      
      if (clientUser) {
        // Encontra o cliente correspondente
        const client = clients.find(c => c.name === clientUser.company);
        
        setUser({
          id: clientUser.id,
          name: clientUser.name,
          email: clientUser.email,
          role: 'client',
          clientId: client?.id,
        });
        
        if (client) {
          setCurrentClient(client);
        }
      } else {
        // Cliente genérico se não encontrado
        setUser({
          id: '999',
          name: email.split('@')[0],
          email: email,
          role: 'client',
          clientId: '1',
        });
        setCurrentClient(clients[0]);
      }
    }
    
    setCurrentPage('dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Logo and Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-2xl">CB</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">CreatorBoard</h1>
          </div>
          <p className="text-gray-600">Gestão de Creators para Campanhas Publicitárias</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Acessar Plataforma
          </h2>

          <form onSubmit={handleLogin} className="space-y-5">
            {/* Email Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {/* Password Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Senha
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {/* Login Button */}
            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <LogIn className="w-5 h-5" />
              Entrar
            </button>
          </form>

          {/* Forgot Password */}
          <div className="mt-6 text-center">
            <button className="text-sm text-blue-600 hover:text-blue-700">
              Esqueci minha senha
            </button>
          </div>

          {/* Access Info */}
          <div className="mt-6 p-4 rounded-lg border bg-blue-50 border-blue-200">
            <p className="text-xs font-medium mb-2 text-blue-900">
              Contas de Demonstração:
            </p>
            <ul className="space-y-2 text-xs text-blue-800">
              <li className="flex flex-col gap-0.5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-blue-600"></div>
                  <strong>Agência (Admin):</strong>
                </div>
                <span className="ml-3 text-blue-700">joao@agencia.com</span>
              </li>
              <li className="flex flex-col gap-0.5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-blue-600"></div>
                  <strong>OdontoCompany:</strong>
                </div>
                <span className="ml-3 text-blue-700">maria@odontocompany.com</span>
              </li>
              <li className="flex flex-col gap-0.5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-blue-600"></div>
                  <strong>SamsClub:</strong>
                </div>
                <span className="ml-3 text-blue-700">carlos@samsclub.com</span>
              </li>
              <li className="flex flex-col gap-0.5">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-blue-600"></div>
                  <strong>Positivo:</strong>
                </div>
                <span className="ml-3 text-blue-700">ana@positivotecnologia.com.br</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Demo Info */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500">
            💡 <strong>Demo:</strong> Use qualquer senha para entrar. O sistema identifica automaticamente seu perfil pelo email.
          </p>
        </div>
      </div>
    </div>
  );
}