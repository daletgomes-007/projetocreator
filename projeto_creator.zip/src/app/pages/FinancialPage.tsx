import { DollarSign, TrendingUp, TrendingDown, Wallet, BarChart3, Activity, FileText, Plus, Download, Trash2, Edit2, Filter, Search } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { mockCreators } from '@/app/types/creator';
import { usePermissions } from '@/app/hooks/usePermissions';
import { useApp } from '@/app/contexts/AppContext';
import { useInvoices } from '@/app/contexts/InvoiceContext';
import { InvoiceModal } from '@/app/components/invoices/InvoiceModal';
import { useState } from 'react';
import { Invoice } from '@/app/types/invoice';
import { toast } from 'sonner';

export function FinancialPage() {
  const { canViewFinancials } = usePermissions();
  const { currentClient } = useApp();
  const { invoices, deleteInvoice } = useInvoices();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | undefined>(undefined);

  if (!canViewFinancials) {
    return (
      <div className="p-6">
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <p className="text-gray-500">Você não tem permissão para acessar esta página.</p>
        </div>
      </div>
    );
  }

  // Filter creators by current client
  const filteredCreators = currentClient 
    ? mockCreators.filter(c => c.clientId === currentClient.id)
    : mockCreators;

  // Calculate financials
  const totalClientValue = filteredCreators.reduce((sum, c) => sum + c.clientValue, 0);
  const totalCreatorCost = filteredCreators.reduce((sum, c) => sum + c.creatorValue, 0);
  const totalMargin = totalClientValue - totalCreatorCost;
  const marginPercentage = ((totalMargin / totalClientValue) * 100).toFixed(1);

  const paidCreators = filteredCreators.filter((c) => c.status === 'completed').reduce((sum, c) => sum + c.creatorValue, 0);
  const pendingPayments = totalCreatorCost - paidCreators;

  // Chart data
  const creatorFinancials = filteredCreators.map((c) => ({
    name: c.name,
    clientValue: c.clientValue,
    creatorCost: c.creatorValue,
    margin: c.clientValue - c.creatorValue,
  }));

  const monthlyData = [
    { month: 'Jan', revenue: 145000, cost: 110000, margin: 35000 },
    { month: 'Fev', revenue: 178000, cost: 135000, margin: 43000 },
    { month: 'Mar', revenue: 210000, cost: 160000, margin: 50000 },
  ];

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(num);
  };

  // Handle Invoice Actions
  const handleAddInvoice = (invoice: Invoice) => {
    toast.success('Fatura adicionada com sucesso!');
  };

  const handleUpdateInvoice = (invoice: Invoice) => {
    toast.success('Fatura atualizada com sucesso!');
  };

  const handleDeleteInvoice = (invoiceId: string) => {
    deleteInvoice(invoiceId);
    toast.success('Fatura excluída com sucesso!');
  };

  const handleOpenModal = (invoice: Invoice) => {
    setEditingInvoice(invoice);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingInvoice(undefined);
    setIsModalOpen(false);
  };

  return (
    <div className="p-3 md:p-6 space-y-4 md:space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Financeiro</h1>
        <p className="text-sm text-gray-600 mt-1">Visão financeira da campanha</p>
      </div>

      {/* Financial Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-50 rounded-xl">
              <DollarSign className="w-6 h-6 text-blue-500" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Receita da Agência</p>
          <p className="text-3xl font-semibold text-gray-900">{formatCurrency(totalClientValue)}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-red-50 rounded-xl">
              <TrendingDown className="w-6 h-6 text-red-500" />
            </div>
          </div>
          <p className="text-sm text-gray-600 mb-1">Custo Total (Creators)</p>
          <p className="text-3xl font-semibold text-gray-900">{formatCurrency(totalCreatorCost)}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-50 rounded-xl">
              <Wallet className="w-6 h-6 text-green-500" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Margem Total</p>
          <p className="text-3xl font-semibold text-green-600">{formatCurrency(totalMargin)}</p>
          <p className="text-sm text-gray-500 mt-2">{marginPercentage}% de margem</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-yellow-50 rounded-xl">
              <DollarSign className="w-6 h-6 text-yellow-500" />
            </div>
          </div>
          <p className="text-sm text-gray-600 mb-1">Pagamentos Pendentes</p>
          <p className="text-3xl font-semibold text-yellow-600">{formatCurrency(pendingPayments)}</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Creator Financials - Enhanced */}
        <div className="bg-gradient-to-br from-white to-gray-50 rounded-2xl border-2 border-gray-200 p-8 shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Financeiro por Creator</h2>
              <p className="text-sm text-gray-500 mt-1">Comparativo de valores e margens</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-md">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
          </div>
          
          <ResponsiveContainer width="100%" height={350}>
            <BarChart 
              data={creatorFinancials}
              margin={{ top: 20, right: 20, left: 0, bottom: 80 }}
            >
              <defs>
                <linearGradient id="colorClientValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={1}/>
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0.8}/>
                </linearGradient>
                <linearGradient id="colorCreatorCost" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={1}/>
                  <stop offset="95%" stopColor="#dc2626" stopOpacity={0.8}/>
                </linearGradient>
                <linearGradient id="colorMargin" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={1}/>
                  <stop offset="95%" stopColor="#059669" stopOpacity={0.8}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
              <XAxis 
                dataKey="name" 
                angle={-45} 
                textAnchor="end" 
                height={100}
                interval={0}
                tick={{ fill: '#6b7280', fontSize: 12, fontWeight: 500 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 12 }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip 
                formatter={(value) => formatCurrency(Number(value))}
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '12px',
                  padding: '12px 16px',
                  boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                }}
                labelStyle={{ fontWeight: 600, color: '#111827', marginBottom: '8px' }}
              />
              <Legend 
                verticalAlign="top" 
                height={36}
                iconType="circle"
                iconSize={10}
                wrapperStyle={{
                  paddingBottom: '20px',
                  fontSize: '13px',
                  fontWeight: '500'
                }}
              />
              <Bar 
                dataKey="clientValue" 
                fill="url(#colorClientValue)" 
                name="Valor Cliente"
                radius={[8, 8, 0, 0]}
                maxBarSize={60}
              />
              <Bar 
                dataKey="creatorCost" 
                fill="url(#colorCreatorCost)" 
                name="Custo Creator"
                radius={[8, 8, 0, 0]}
                maxBarSize={60}
              />
              <Bar 
                dataKey="margin" 
                fill="url(#colorMargin)" 
                name="Margem"
                radius={[8, 8, 0, 0]}
                maxBarSize={60}
              />
            </BarChart>
          </ResponsiveContainer>
          
          {/* Legend Summary */}
          <div className="flex items-center justify-around mt-6 pt-6 border-t border-gray-200">
            <div className="text-center">
              <div className="w-3 h-3 rounded-full bg-blue-500 mx-auto mb-2"></div>
              <p className="text-xs text-gray-500">Valor Cliente</p>
              <p className="text-sm font-bold text-gray-900">{formatCurrency(totalClientValue)}</p>
            </div>
            <div className="text-center">
              <div className="w-3 h-3 rounded-full bg-red-500 mx-auto mb-2"></div>
              <p className="text-xs text-gray-500">Custo Creator</p>
              <p className="text-sm font-bold text-gray-900">{formatCurrency(totalCreatorCost)}</p>
            </div>
            <div className="text-center">
              <div className="w-3 h-3 rounded-full bg-green-500 mx-auto mb-2"></div>
              <p className="text-xs text-gray-500">Margem</p>
              <p className="text-sm font-bold text-green-600">{formatCurrency(totalMargin)}</p>
            </div>
          </div>
        </div>

        {/* Monthly Trend - Enhanced */}
        <div className="bg-gradient-to-br from-white to-gray-50 rounded-2xl border-2 border-gray-200 p-8 shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Evolução Mensal</h2>
              <p className="text-sm text-gray-500 mt-1">Tendências financeiras ao longo do tempo</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-md">
              <Activity className="w-6 h-6 text-white" />
            </div>
          </div>
          
          <ResponsiveContainer width="100%" height={350}>
            <LineChart 
              data={monthlyData}
              margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
            >
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0.9}/>
                </linearGradient>
                <linearGradient id="colorCost" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#dc2626" stopOpacity={0.9}/>
                </linearGradient>
                <linearGradient id="colorMarginLine" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#059669" stopOpacity={0.9}/>
                </linearGradient>
                
                {/* Area gradients for fill */}
                <linearGradient id="areaRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.05}/>
                </linearGradient>
                <linearGradient id="areaCost" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0.05}/>
                </linearGradient>
                <linearGradient id="areaMargin" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
              <XAxis 
                dataKey="month" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 13, fontWeight: 500 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 12 }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip 
                formatter={(value) => formatCurrency(Number(value))}
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '12px',
                  padding: '12px 16px',
                  boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                }}
                labelStyle={{ fontWeight: 600, color: '#111827', marginBottom: '8px' }}
              />
              <Legend 
                verticalAlign="top" 
                height={36}
                iconType="circle"
                iconSize={10}
                wrapperStyle={{
                  paddingBottom: '20px',
                  fontSize: '13px',
                  fontWeight: '500'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="url(#colorRevenue)" 
                strokeWidth={3} 
                name="Receita"
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 5, stroke: '#fff' }}
                activeDot={{ r: 7, stroke: '#fff', strokeWidth: 2 }}
                fill="url(#areaRevenue)"
              />
              <Line 
                type="monotone" 
                dataKey="cost" 
                stroke="url(#colorCost)" 
                strokeWidth={3} 
                name="Custo"
                dot={{ fill: '#ef4444', strokeWidth: 2, r: 5, stroke: '#fff' }}
                activeDot={{ r: 7, stroke: '#fff', strokeWidth: 2 }}
                fill="url(#areaCost)"
              />
              <Line 
                type="monotone" 
                dataKey="margin" 
                stroke="url(#colorMarginLine)" 
                strokeWidth={3} 
                name="Margem"
                dot={{ fill: '#10b981', strokeWidth: 2, r: 5, stroke: '#fff' }}
                activeDot={{ r: 7, stroke: '#fff', strokeWidth: 2 }}
                fill="url(#areaMargin)"
              />
            </LineChart>
          </ResponsiveContainer>
          
          {/* Trend Indicators */}
          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-gray-200">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                <p className="text-xs text-gray-500">Receita</p>
              </div>
              <p className="text-lg font-bold text-blue-600">+44.8%</p>
              <p className="text-xs text-gray-500">vs mês anterior</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <div className="w-2 h-2 rounded-full bg-red-500"></div>
                <p className="text-xs text-gray-500">Custo</p>
              </div>
              <p className="text-lg font-bold text-red-600">+45.5%</p>
              <p className="text-xs text-gray-500">vs mês anterior</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <p className="text-xs text-gray-500">Margem</p>
              </div>
              <p className="text-lg font-bold text-green-600">+42.9%</p>
              <p className="text-xs text-gray-500">vs mês anterior</p>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Status */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Status de Pagamentos</h2>
        
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Creator</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Valor Creator</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Valor Cliente</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Margem</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredCreators.map((creator) => {
                const margin = creator.clientValue - creator.creatorValue;
                const marginPercent = ((margin / creator.clientValue) * 100).toFixed(1);

                return (
                  <tr key={creator.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{creator.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{formatCurrency(creator.creatorValue)}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{formatCurrency(creator.clientValue)}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-green-600">
                      {formatCurrency(margin)} ({marginPercent}%)
                    </td>
                    <td className="px-6 py-4">
                      {creator.status === 'completed' ? (
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200">
                          Pago
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-50 text-yellow-700 border border-yellow-200">
                          Pendente
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {/* Mobile Cards */}
        <div className="md:hidden space-y-3">
          {filteredCreators.map((creator) => {
            const margin = creator.clientValue - creator.creatorValue;
            const marginPercent = ((margin / creator.clientValue) * 100).toFixed(1);

            return (
              <div key={creator.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-gray-900 text-sm">{creator.name}</h3>
                  {creator.status === 'completed' ? (
                    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200">
                      Pago
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-yellow-50 text-yellow-700 border border-yellow-200">
                      Pendente
                    </span>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-600">Valor Creator:</span>
                    <span className="font-medium text-gray-900">{formatCurrency(creator.creatorValue)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-600">Valor Cliente:</span>
                    <span className="font-medium text-gray-900">{formatCurrency(creator.clientValue)}</span>
                  </div>
                  <div className="flex justify-between text-xs pt-2 border-t border-gray-200">
                    <span className="text-gray-600">Margem:</span>
                    <span className="font-semibold text-green-600">
                      {formatCurrency(margin)} ({marginPercent}%)
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Invoices Section */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Faturas</h2>
          <button
            className="inline-flex items-center px-3 py-2 bg-blue-500 text-white text-sm font-medium rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            onClick={() => setIsModalOpen(true)}
          >
            <Plus className="w-4 h-4 mr-1" />
            <span className="hidden sm:inline">Adicionar Fatura</span>
            <span className="sm:hidden">Adicionar</span>
          </button>
        </div>
        
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">ID</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Cliente</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Valor</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Status</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {invoices.map((invoice) => (
                <tr key={invoice.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{invoice.id}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{invoice.clientName}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{formatCurrency(invoice.amount)}</td>
                  <td className="px-6 py-4">
                    {invoice.status === 'paid' ? (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200">
                        Pago
                      </span>
                    ) : invoice.status === 'overdue' ? (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-50 text-red-700 border border-red-200">
                        Vencida
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-50 text-yellow-700 border border-yellow-200">
                        Pendente
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      className="inline-flex items-center px-3 py-2 bg-blue-500 text-white text-sm font-medium rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                      onClick={() => handleOpenModal(invoice)}
                    >
                      <Edit2 className="w-4 h-4 mr-1" />
                      Editar
                    </button>
                    <button
                      className="inline-flex items-center px-3 py-2 bg-red-500 text-white text-sm font-medium rounded hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 ml-2"
                      onClick={() => handleDeleteInvoice(invoice.id)}
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Mobile Cards */}
        <div className="md:hidden space-y-3">
          {invoices.map((invoice) => (
            <div key={invoice.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900 text-sm">{invoice.clientName}</h3>
                  <p className="text-xs text-gray-500 mt-0.5">ID: {invoice.id}</p>
                </div>
                {invoice.status === 'paid' ? (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200">
                    Pago
                  </span>
                ) : invoice.status === 'overdue' ? (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-red-50 text-red-700 border border-red-200">
                    Vencida
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-yellow-50 text-yellow-700 border border-yellow-200">
                    Pendente
                  </span>
                )}
              </div>
              <div className="mb-3">
                <p className="text-xs text-gray-600 mb-1">Valor</p>
                <p className="text-base font-semibold text-gray-900">{formatCurrency(invoice.amount)}</p>
              </div>
              <div className="flex gap-2">
                <button
                  className="flex-1 inline-flex items-center justify-center px-3 py-2 bg-blue-500 text-white text-xs font-medium rounded hover:bg-blue-600"
                  onClick={() => handleOpenModal(invoice)}
                >
                  <Edit2 className="w-3.5 h-3.5 mr-1" />
                  Editar
                </button>
                <button
                  className="flex-1 inline-flex items-center justify-center px-3 py-2 bg-red-500 text-white text-xs font-medium rounded hover:bg-red-600"
                  onClick={() => handleDeleteInvoice(invoice.id)}
                >
                  <Trash2 className="w-3.5 h-3.5 mr-1" />
                  Excluir
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Invoice Modal */}
      <InvoiceModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        invoice={editingInvoice}
        onSave={editingInvoice ? handleUpdateInvoice : handleAddInvoice}
      />
    </div>
  );
}