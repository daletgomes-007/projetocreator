import { useState, useEffect, useRef } from 'react';
import { Filter, Search, Plus } from 'lucide-react';
import { CreatorStatus } from '@/app/types/creator';
import { CreatorCard } from '@/app/components/creators/CreatorCard';
import { AddCreatorModal } from '@/app/components/creators/AddCreatorModal';
import { usePermissions } from '@/app/hooks/usePermissions';
import { useCreators } from '@/app/contexts/CreatorsContext';
import { useApp } from '@/app/contexts/AppContext';

export function CreatorsPage() {
  const { creators: allCreators } = useCreators();
  const { currentClient, campaigns, currentCampaign, setCurrentCampaign, selectedCreatorId, setSelectedCreatorId } = useApp();
  const [filter, setFilter] = useState<CreatorStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [highlightedCreatorId, setHighlightedCreatorId] = useState<string | null>(null);
  const { isAdmin } = usePermissions();
  const creatorRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // Handle selected creator from notification
  useEffect(() => {
    if (selectedCreatorId) {
      // Scroll to the creator
      const creatorElement = creatorRefs.current[selectedCreatorId];
      if (creatorElement) {
        // Small delay to ensure rendering is complete
        setTimeout(() => {
          creatorElement.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'center' 
          });
          
          // Highlight the creator
          setHighlightedCreatorId(selectedCreatorId);
          
          // Remove highlight after 3 seconds
          setTimeout(() => {
            setHighlightedCreatorId(null);
          }, 3000);
        }, 100);
      }

      // Clear the selected creator ID after handling
      setTimeout(() => {
        setSelectedCreatorId(null);
      }, 100);
    }
  }, [selectedCreatorId, setSelectedCreatorId]);

  // Get campaigns for current client
  const clientCampaigns = currentClient 
    ? campaigns.filter(c => c.clientId === currentClient.id)
    : [];

  // Filter creators by current client AND current campaign
  const clientCreators = currentClient 
    ? allCreators.filter(c => {
        const matchesClient = c.clientId === currentClient.id;
        const matchesCampaign = !currentCampaign || c.campaignId === currentCampaign.id;
        return matchesClient && matchesCampaign;
      })
    : allCreators;

  const filteredCreators = clientCreators.filter((creator) => {
    const matchesFilter = filter === 'all' || creator.status === filter;
    const matchesSearch =
      creator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      creator.socialNetwork.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const statusCounts = {
    all: clientCreators.length,
    in_approval: clientCreators.filter((c) => c.status === 'in_approval').length,
    approved: clientCreators.filter((c) => c.status === 'approved').length,
    negotiating: clientCreators.filter((c) => c.status === 'negotiating').length,
    denied: clientCreators.filter((c) => c.status === 'denied').length,
    completed: clientCreators.filter((c) => c.status === 'completed').length,
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Creators</h1>
          <p className="text-xs md:text-sm text-gray-600 mt-1">
            Gerencie e aprove creators para sua campanha
          </p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Adicionar Creator</span>
            <span className="sm:hidden">Adicionar</span>
          </button>
        )}
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-col gap-4">
          {/* Campaign Filter */}
          {clientCampaigns.length > 0 && (
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-2">
                Filtrar por Campanha
              </label>
              <select
                value={currentCampaign?.id || 'all'}
                onChange={(e) => {
                  const campaignId = e.target.value;
                  if (campaignId === 'all') {
                    setCurrentCampaign(null);
                  } else {
                    const campaign = campaigns.find(c => c.id === campaignId);
                    setCurrentCampaign(campaign || null);
                  }
                }}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Todas as Campanhas</option>
                {clientCampaigns.map(campaign => (
                  <option key={campaign.id} value={campaign.id}>
                    {campaign.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="w-4 h-4 md:w-5 md:h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar creators..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 md:pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Status Filters */}
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 md:w-5 md:h-5 text-gray-500" />
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as CreatorStatus | 'all')}
                className="flex-1 sm:flex-initial px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Todos ({statusCounts.all})</option>
                <option value="in_approval">Em aprovação ({statusCounts.in_approval})</option>
                <option value="approved">Aprovados ({statusCounts.approved})</option>
                <option value="negotiating">Negociando ({statusCounts.negotiating})</option>
                <option value="denied">Negados ({statusCounts.denied})</option>
                <option value="completed">Finalizados ({statusCounts.completed})</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Creators Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {filteredCreators.map((creator) => (
          <CreatorCard key={creator.id} creator={creator} ref={(el) => creatorRefs.current[creator.id] = el} highlighted={highlightedCreatorId === creator.id} />
        ))}
      </div>

      {filteredCreators.length === 0 && (
        <div className="text-center py-12">
          <p className="text-sm text-gray-500">Nenhum creator encontrado</p>
        </div>
      )}

      <AddCreatorModal open={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} />
    </div>
  );
}