import { useState, useMemo, useRef } from 'react';
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Minus,
  Filter,
  ArrowUpDown,
  Eye,
  Users,
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Instagram,
  ExternalLink,
  DollarSign,
  Target,
  AlertCircle,
  Award,
  Info,
  Edit,
  X,
  Upload,
  FileSpreadsheet,
  Download,
} from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';
import { usePermissions } from '@/app/hooks/usePermissions';
import { usePerformance } from '@/app/contexts/PerformanceContext';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import {
  CreatorPerformance,
  getCampaignAverages,
  ContentType,
  PublicationStatus,
  PerformanceLevel,
} from '@/app/types/performance';

type SortBy = 'impressions' | 'reach' | 'engagementRate' | 'estimatedROI';
type SortOrder = 'asc' | 'desc';

const contentTypeColors = {
  Feed: 'bg-blue-100 text-blue-700 border-blue-200',
  Reels: 'bg-purple-100 text-purple-700 border-purple-200',
  Story: 'bg-pink-100 text-pink-700 border-pink-200',
};

const statusColors = {
  Publicado: 'bg-green-100 text-green-700 border-green-200',
  Aguardando: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  'Ajuste solicitado': 'bg-orange-100 text-orange-700 border-orange-200',
};

export function CampaignInsightsPage() {
  const { setCurrentPage, currentClient, campaigns: allCampaigns, currentCampaign } = useApp();
  const { isAdmin } = usePermissions();
  const { performances: allPerformances, updatePerformance, addPerformance } = usePerformance();
  
  // Filter performances by current client AND current campaign
  const performances = currentClient && currentCampaign
    ? allPerformances.filter(p => p.clientId === currentClient.id && p.campaignId === currentCampaign.id)
    : currentClient
    ? allPerformances.filter(p => p.clientId === currentClient.id)
    : allPerformances;

  const campaignName = currentCampaign?.name || 'Campanha';

  // Filtros
  const [filterContentType, setFilterContentType] = useState<ContentType | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<PublicationStatus | 'all'>('all');
  const [filterPerformance, setFilterPerformance] = useState<PerformanceLevel | 'all'>('all');

  // Ordenação
  const [sortBy, setSortBy] = useState<SortBy>('impressions');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  // Modal de edição
  const [editingPerformance, setEditingPerformance] = useState<CreatorPerformance | null>(null);
  const [editForm, setEditForm] = useState<Partial<CreatorPerformance>>({});

  const campaignAverages = getCampaignAverages(performances);

  const filteredAndSorted = useMemo(() => {
    let filtered = [...performances];

    // Aplicar filtros
    if (filterContentType !== 'all') {
      filtered = filtered.filter((p) => p.contentType === filterContentType);
    }
    if (filterStatus !== 'all') {
      filtered = filtered.filter((p) => p.publicationStatus === filterStatus);
    }
    if (filterPerformance !== 'all') {
      filtered = filtered.filter((p) => p.performanceLevel === filterPerformance);
    }

    // Aplicar ordenação
    filtered.sort((a, b) => {
      const multiplier = sortOrder === 'asc' ? 1 : -1;
      return (a[sortBy] - b[sortBy]) * multiplier;
    });

    return filtered;
  }, [performances, filterContentType, filterStatus, filterPerformance, sortBy, sortOrder]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(num);
  };

  const getPerformanceBadge = (performance: CreatorPerformance) => {
    if (!campaignAverages || performance.publicationStatus !== 'Publicado') return null;

    if (performance.engagementRate >= campaignAverages.engagementRate * 1.5) {
      return {
        label: 'Top performer',
        icon: Award,
        className: 'bg-green-100 text-green-700 border-green-300',
      };
    }

    if (performance.engagementRate < campaignAverages.engagementRate * 0.5) {
      return {
        label: 'Atenção: baixo engajamento',
        icon: AlertCircle,
        className: 'bg-red-100 text-red-700 border-red-300',
      };
    }

    return null;
  };

  const getPerformanceIndicator = (performance: CreatorPerformance) => {
    if (!campaignAverages || performance.publicationStatus !== 'Publicado') return null;

    const diff = performance.engagementRate - campaignAverages.engagementRate;
    const diffPercent = ((diff / campaignAverages.engagementRate) * 100).toFixed(1);

    if (Math.abs(diff) < campaignAverages.engagementRate * 0.1) {
      return {
        label: 'Dentro da média',
        icon: Minus,
        color: 'text-gray-600',
        diff: diffPercent,
      };
    }

    if (diff > 0) {
      return {
        label: 'Acima da média',
        icon: TrendingUp,
        color: 'text-green-600',
        diff: `+${diffPercent}`,
      };
    }

    return {
      label: 'Abaixo da média',
      icon: TrendingDown,
      color: 'text-red-600',
      diff: diffPercent,
    };
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();
  };

  const toggleSort = (field: SortBy) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const handleEditClick = (performance: CreatorPerformance) => {
    setEditingPerformance(performance);
    setEditForm(performance);
  };

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleEditSave = () => {
    if (!editingPerformance) return;

    // Convert string values to numbers where needed
    const updates: Partial<CreatorPerformance> = {
      ...editForm,
      impressions: editForm.impressions ? Number(editForm.impressions) : editingPerformance.impressions,
      reach: editForm.reach ? Number(editForm.reach) : editingPerformance.reach,
      likes: editForm.likes ? Number(editForm.likes) : editingPerformance.likes,
      comments: editForm.comments ? Number(editForm.comments) : editingPerformance.comments,
      shares: editForm.shares ? Number(editForm.shares) : editingPerformance.shares,
      saves: editForm.saves ? Number(editForm.saves) : editingPerformance.saves,
      totalEngagement: editForm.totalEngagement ? Number(editForm.totalEngagement) : editingPerformance.totalEngagement,
      engagementRate: editForm.engagementRate ? Number(editForm.engagementRate) : editingPerformance.engagementRate,
      creatorCost: editForm.creatorCost ? Number(editForm.creatorCost) : editingPerformance.creatorCost,
      attributedRevenue: editForm.attributedRevenue ? Number(editForm.attributedRevenue) : editingPerformance.attributedRevenue,
      estimatedROI: editForm.estimatedROI ? Number(editForm.estimatedROI) : editingPerformance.estimatedROI,
      margin: editForm.margin ? Number(editForm.margin) : editingPerformance.margin,
    };

    updatePerformance(editingPerformance.id, updates);
    toast.success('Performance atualizada com sucesso!');
    setEditingPerformance(null);
    setEditForm({});
  };

  const handleEditCancel = () => {
    setEditingPerformance(null);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        let updatedCount = 0;
        let createdCount = 0;

        jsonData.forEach((row: any) => {
          // Buscar performance existente pelo ID ou nome do creator
          const existingPerformance = performances.find(
            p => p.id === row.id || p.creatorName === row.creatorName || p.instagramHandle === row.instagramHandle
          );

          if (existingPerformance) {
            // Atualizar performance existente
            const updates: Partial<CreatorPerformance> = {
              impressions: row.impressions ? Number(row.impressions) : existingPerformance.impressions,
              reach: row.reach ? Number(row.reach) : existingPerformance.reach,
              likes: row.likes ? Number(row.likes) : existingPerformance.likes,
              comments: row.comments ? Number(row.comments) : existingPerformance.comments,
              shares: row.shares ? Number(row.shares) : existingPerformance.shares,
              saves: row.saves ? Number(row.saves) : existingPerformance.saves,
              totalEngagement: row.totalEngagement ? Number(row.totalEngagement) : existingPerformance.totalEngagement,
              engagementRate: row.engagementRate ? Number(row.engagementRate) : existingPerformance.engagementRate,
              creatorCost: row.creatorCost ? Number(row.creatorCost) : existingPerformance.creatorCost,
              attributedRevenue: row.attributedRevenue ? Number(row.attributedRevenue) : existingPerformance.attributedRevenue,
              estimatedROI: row.estimatedROI ? Number(row.estimatedROI) : existingPerformance.estimatedROI,
              margin: row.margin ? Number(row.margin) : existingPerformance.margin,
              publicationDate: row.publicationDate || existingPerformance.publicationDate,
              contentType: row.contentType || existingPerformance.contentType,
              publicationStatus: row.publicationStatus || existingPerformance.publicationStatus,
            };

            updatePerformance(existingPerformance.id, updates);
            updatedCount++;
          } else if (row.creatorName && row.instagramHandle) {
            // Criar novo influenciador se tiver pelo menos nome e instagram
            const engagementRate = row.engagementRate 
              ? Number(row.engagementRate) 
              : row.totalEngagement && row.reach 
                ? parseFloat(((Number(row.totalEngagement) / Number(row.reach)) * 100).toFixed(2))
                : 0;

            const performanceLevel: PerformanceLevel = 
              engagementRate >= 10 ? 'high' : engagementRate >= 5 ? 'medium' : 'low';

            const newPerformance: Omit<CreatorPerformance, 'id'> = {
              creatorId: `creator-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              clientId: currentClient?.id || '',
              campaignId: currentCampaign?.id || '',
              creatorName: row.creatorName,
              instagramHandle: row.instagramHandle,
              creatorPhoto: row.creatorPhoto || '',
              postUrl: row.postUrl || 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
              contentType: (row.contentType as ContentType) || 'Feed',
              publicationStatus: (row.publicationStatus as PublicationStatus) || 'Aguardando',
              publicationDate: row.publicationDate || undefined,
              impressions: row.impressions ? Number(row.impressions) : 0,
              reach: row.reach ? Number(row.reach) : 0,
              likes: row.likes ? Number(row.likes) : 0,
              comments: row.comments ? Number(row.comments) : 0,
              shares: row.shares ? Number(row.shares) : 0,
              saves: row.saves ? Number(row.saves) : 0,
              totalEngagement: row.totalEngagement ? Number(row.totalEngagement) : 0,
              engagementRate,
              performanceLevel,
              creatorCost: row.creatorCost ? Number(row.creatorCost) : 0,
              attributedRevenue: row.attributedRevenue ? Number(row.attributedRevenue) : 0,
              estimatedROI: row.estimatedROI ? Number(row.estimatedROI) : 0,
              margin: row.margin ? Number(row.margin) : 0,
            };

            addPerformance(newPerformance);
            createdCount++;
          }
        });

        if (createdCount > 0 && updatedCount > 0) {
          toast.success(`${createdCount} influenciador(es) criado(s) e ${updatedCount} atualizado(s)!`);
        } else if (createdCount > 0) {
          toast.success(`${createdCount} influenciador(es) criado(s) com sucesso!`);
        } else if (updatedCount > 0) {
          toast.success(`${updatedCount} influenciador(es) atualizado(s) com sucesso!`);
        } else {
          toast.warning('Nenhum influenciador foi criado ou atualizado. Verifique os dados da planilha.');
        }
        
        // Limpar o input file para permitir upload do mesmo arquivo novamente
        e.target.value = '';
      } catch (error) {
        console.error('Erro ao processar planilha:', error);
        toast.error('Erro ao processar planilha. Verifique o formato do arquivo.');
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDownload = () => {
    const worksheet = XLSX.utils.json_to_sheet(filteredAndSorted);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Performance');
    XLSX.writeFile(workbook, 'performance.xlsx');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setCurrentPage('campaigns')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">{campaignName}</h1>
            <p className="text-sm text-gray-600 mt-1">Performance por Creator</p>
          </div>
        </div>
      </div>

      {/* Campaign Stats */}
      {campaignAverages && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-200 rounded-lg">
                <Eye className="w-5 h-5 text-blue-700" />
              </div>
              <p className="text-sm font-medium text-blue-900">Média Impressões</p>
            </div>
            <p className="text-3xl font-bold text-blue-900">{formatNumber(campaignAverages.impressions)}</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border border-purple-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-purple-200 rounded-lg">
                <Users className="w-5 h-5 text-purple-700" />
              </div>
              <p className="text-sm font-medium text-purple-900">Média Alcance</p>
            </div>
            <p className="text-3xl font-bold text-purple-900">{formatNumber(campaignAverages.reach)}</p>
          </div>

          <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl border border-pink-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-pink-200 rounded-lg">
                <Heart className="w-5 h-5 text-pink-700" />
              </div>
              <p className="text-sm font-medium text-pink-900">Média Engajamento</p>
            </div>
            <p className="text-3xl font-bold text-pink-900">{formatNumber(campaignAverages.engagement)}</p>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-green-200 rounded-lg">
                <Target className="w-5 h-5 text-green-700" />
              </div>
              <p className="text-sm font-medium text-green-900">Taxa Eng. Média</p>
            </div>
            <p className="text-3xl font-bold text-green-900">{campaignAverages.engagementRate}%</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <Filter className="w-5 h-5 text-gray-600" />
            <h3 className="text-sm font-semibold text-gray-900">Filtros e Ordenação</h3>
          </div>
          
          {/* Upload and Download Buttons (Admin Only) */}
          {isAdmin && (
            <div className="flex items-center gap-2 md:gap-3">
              <label className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-xs md:text-sm font-medium cursor-pointer">
                <Upload className="w-3.5 md:w-4 h-3.5 md:h-4" />
                <span className="hidden sm:inline">Importar Planilha</span>
                <span className="sm:hidden">Importar</span>
                <input
                  type="file"
                  accept=".xlsx, .xls, .csv"
                  onChange={handleUpload}
                  className="hidden"
                />
              </label>
              <button
                onClick={handleDownload}
                className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-xs md:text-sm font-medium"
              >
                <Download className="w-3.5 md:w-4 h-3.5 md:h-4" />
                <span className="hidden sm:inline">Exportar Dados</span>
                <span className="sm:hidden">Exportar</span>
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">Tipo de Conteúdo</label>
            <select
              value={filterContentType}
              onChange={(e) => setFilterContentType(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todos</option>
              <option value="Feed">Feed</option>
              <option value="Reels">Reels</option>
              <option value="Story">Story</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todos</option>
              <option value="Publicado">Publicado</option>
              <option value="Aguardando">Aguardando</option>
              <option value="Ajuste solicitado">Ajuste solicitado</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">Performance</label>
            <select
              value={filterPerformance}
              onChange={(e) => setFilterPerformance(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todas</option>
              <option value="high">Alta</option>
              <option value="medium">Média</option>
              <option value="low">Baixa</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-700 mb-2">Ordenar por</label>
            <div className="flex gap-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortBy)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="impressions">Impressões</option>
                <option value="reach">Alcance</option>
                <option value="engagementRate">Taxa Eng.</option>
                <option value="estimatedROI">ROI</option>
              </select>
              <button
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                <ArrowUpDown className="w-4 h-4 text-gray-700" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Cards */}
      <div className="space-y-4">
        {filteredAndSorted.map((performance) => {
          const badge = getPerformanceBadge(performance);
          const indicator = getPerformanceIndicator(performance);
          const BadgeIcon = badge?.icon;
          const IndicatorIcon = indicator?.icon;

          return (
            <div
              key={performance.id}
              className="bg-white rounded-xl border border-gray-200 hover:shadow-lg transition-shadow overflow-hidden"
            >
              <div className="p-6">
                {/* Creator Header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-xl">
                        {getInitials(performance.creatorName)}
                      </span>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{performance.creatorName}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Instagram className="w-4 h-4 text-pink-500" />
                        <span className="text-sm text-gray-600">{performance.instagramHandle}</span>
                        <a
                          href="https://www.instagram.com/p/DLh0Jk5Nbqf/"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-700 transition-colors"
                          title="Ver publicação"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEditClick(performance)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg transition-colors text-xs font-medium"
                      title="Editar performance"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      Editar
                    </button>
                    <span className={`px-3 py-1.5 rounded-lg border text-xs font-medium ${contentTypeColors[performance.contentType]}`}>
                      {performance.contentType}
                    </span>
                    <span className={`px-3 py-1.5 rounded-lg border text-xs font-medium ${statusColors[performance.publicationStatus]}`}>
                      {performance.publicationStatus}
                    </span>
                  </div>
                </div>

                {/* Badges */}
                {(badge || indicator) && (
                  <div className="flex items-center gap-3 mb-6">
                    {badge && BadgeIcon && (
                      <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium ${badge.className}`}>
                        <BadgeIcon className="w-3.5 h-3.5" />
                        {badge.label}
                      </div>
                    )}
                    {indicator && IndicatorIcon && (
                      <div className="inline-flex items-center gap-1.5 text-xs font-medium">
                        <IndicatorIcon className={`w-4 h-4 ${indicator.color}`} />
                        <span className={indicator.color}>{indicator.label}</span>
                        <span className={`${indicator.color} font-semibold`}>({indicator.diff}%)</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
                  <div className="group relative">
                    <div className="flex items-center gap-2 mb-1">
                      <Eye className="w-4 h-4 text-blue-600" />
                      <p className="text-xs text-gray-600">Impressões</p>
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <Info className="w-3 h-3 text-gray-400" />
                      </div>
                    </div>
                    <p className="text-xl font-bold text-gray-900">{formatNumber(performance.impressions)}</p>
                  </div>

                  <div className="group relative">
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="w-4 h-4 text-purple-600" />
                      <p className="text-xs text-gray-600">Alcance</p>
                    </div>
                    <p className="text-xl font-bold text-gray-900">{formatNumber(performance.reach)}</p>
                  </div>

                  <div className="group relative">
                    <div className="flex items-center gap-2 mb-1">
                      <Heart className="w-4 h-4 text-pink-600" />
                      <p className="text-xs text-gray-600">Curtidas</p>
                    </div>
                    <p className="text-xl font-bold text-gray-900">{formatNumber(performance.likes)}</p>
                  </div>

                  <div className="group relative">
                    <div className="flex items-center gap-2 mb-1">
                      <MessageCircle className="w-4 h-4 text-green-600" />
                      <p className="text-xs text-gray-600">Comentários</p>
                    </div>
                    <p className="text-xl font-bold text-gray-900">{formatNumber(performance.comments)}</p>
                  </div>

                  <div className="group relative">
                    <div className="flex items-center gap-2 mb-1">
                      <Share2 className="w-4 h-4 text-blue-600" />
                      <p className="text-xs text-gray-600">Compartilh.</p>
                    </div>
                    <p className="text-xl font-bold text-gray-900">{formatNumber(performance.shares)}</p>
                  </div>

                  <div className="group relative">
                    <div className="flex items-center gap-2 mb-1">
                      <Bookmark className="w-4 h-4 text-yellow-600" />
                      <p className="text-xs text-gray-600">Salvamentos</p>
                    </div>
                    <p className="text-xl font-bold text-gray-900">{formatNumber(performance.saves)}</p>
                  </div>
                </div>

                {/* Engagement */}
                <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg p-4 mb-6">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Engajamento Total</p>
                      <p className="text-2xl font-bold text-gray-900">{formatNumber(performance.totalEngagement)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Taxa de Engajamento</p>
                      <p className="text-2xl font-bold text-pink-600">{performance.engagementRate}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Data de Publicação</p>
                      <p className="text-sm font-medium text-gray-900">
                        {performance.publicationDate
                          ? new Date(performance.publicationDate).toLocaleDateString('pt-BR')
                          : '—'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Financial (Admin Only) */}
                {isAdmin && (
                  <div className="border-t border-gray-200 pt-4">
                    <div className="flex items-center gap-2 mb-3">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      <p className="text-xs font-semibold text-gray-700">Resumo Financeiro</p>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Custo Creator</p>
                        <p className="text-sm font-bold text-gray-900">{formatCurrency(performance.creatorCost)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Receita Atribuída</p>
                        <p className="text-sm font-bold text-green-600">{formatCurrency(performance.attributedRevenue)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 mb-1">ROI Estimado</p>
                        <p className={`text-sm font-bold ${performance.estimatedROI >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {performance.estimatedROI}%
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Margem</p>
                        <p className={`text-sm font-bold ${performance.margin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(performance.margin)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Info Footer */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-blue-900">
          Os dados de performance são consolidados a partir do link da publicação no Instagram.
        </p>
      </div>

      {/* Empty State */}
      {filteredAndSorted.length === 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">Nenhum creator encontrado com os filtros aplicados</p>
          <p className="text-sm text-gray-400 mt-1">Tente ajustar os filtros de busca</p>
        </div>
      )}

      {/* Edit Modal */}
      {editingPerformance && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 shadow-2xl my-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Editar Performance - {editingPerformance.creatorName}</h3>
              <button
                onClick={handleEditCancel}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handleEditSave(); }} className="space-y-6">
              {/* Creator Info */}
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <h4 className="text-sm font-semibold text-blue-900 mb-4">Informações do Creator</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Nome</label>
                    <input
                      type="text"
                      name="creatorName"
                      value={editForm.creatorName || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Instagram Handle</label>
                    <input
                      type="text"
                      name="instagramHandle"
                      value={editForm.instagramHandle || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Performance Metrics */}
              <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
                <h4 className="text-sm font-semibold text-purple-900 mb-4">Métricas de Performance</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Impressões</label>
                    <input
                      type="number"
                      name="impressions"
                      value={editForm.impressions || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Alcance</label>
                    <input
                      type="number"
                      name="reach"
                      value={editForm.reach || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Curtidas</label>
                    <input
                      type="number"
                      name="likes"
                      value={editForm.likes || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Comentários</label>
                    <input
                      type="number"
                      name="comments"
                      value={editForm.comments || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Compartilhamentos</label>
                    <input
                      type="number"
                      name="shares"
                      value={editForm.shares || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Salvamentos</label>
                    <input
                      type="number"
                      name="saves"
                      value={editForm.saves || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Engagement & Date */}
              <div className="bg-pink-50 rounded-lg p-4 border border-pink-200">
                <h4 className="text-sm font-semibold text-pink-900 mb-4">Engajamento</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Engajamento Total</label>
                    <input
                      type="number"
                      name="totalEngagement"
                      value={editForm.totalEngagement || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Taxa de Engajamento (%)</label>
                    <input
                      type="number"
                      step="0.01"
                      name="engagementRate"
                      value={editForm.engagementRate || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Data de Publicação</label>
                    <input
                      type="date"
                      name="publicationDate"
                      value={editForm.publicationDate || ''}
                      onChange={handleEditChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Financial Info (Admin Only) */}
              {isAdmin && (
                <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                  <h4 className="text-sm font-semibold text-green-900 mb-4">Informações Financeiras</h4>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Custo Creator (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        name="creatorCost"
                        value={editForm.creatorCost || ''}
                        onChange={handleEditChange}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Receita Atribuída (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        name="attributedRevenue"
                        value={editForm.attributedRevenue || ''}
                        onChange={handleEditChange}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">ROI Estimado (%)</label>
                      <input
                        type="number"
                        step="1"
                        name="estimatedROI"
                        value={editForm.estimatedROI || ''}
                        onChange={handleEditChange}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Margem (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        name="margin"
                        value={editForm.margin || ''}
                        onChange={handleEditChange}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Status */}
              <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
                <h4 className="text-sm font-semibold text-yellow-900 mb-4">Status e Tipo</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Conteúdo</label>
                    <select
                      name="contentType"
                      value={editForm.contentType || ''}
                      onChange={(e) => setEditForm({ ...editForm, contentType: e.target.value as ContentType })}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Feed">Feed</option>
                      <option value="Reels">Reels</option>
                      <option value="Story">Story</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Status de Publicação</label>
                    <select
                      name="publicationStatus"
                      value={editForm.publicationStatus || ''}
                      onChange={(e) => setEditForm({ ...editForm, publicationStatus: e.target.value as PublicationStatus })}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Publicado">Publicado</option>
                      <option value="Aguardando">Aguardando</option>
                      <option value="Ajuste solicitado">Ajuste solicitado</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={handleEditCancel}
                  className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}