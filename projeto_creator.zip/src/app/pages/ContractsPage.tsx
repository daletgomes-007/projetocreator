import { FileText, Download, CheckCircle, Clock, AlertCircle, Copy, Upload, X, File } from 'lucide-react';
import { useRef } from 'react';
import { useContracts } from '@/app/contexts/ContractsContext';
import { useApp } from '@/app/contexts/AppContext';
import { toast } from 'sonner';

const statusConfig = {
  sent: {
    label: 'Enviado',
    color: 'text-blue-700',
    bg: 'bg-blue-50 border-blue-200',
    icon: Clock,
  },
  signed: {
    label: 'Assinado',
    color: 'text-green-700',
    bg: 'bg-green-50 border-green-200',
    icon: CheckCircle,
  },
  pending: {
    label: 'Pendente',
    color: 'text-yellow-700',
    bg: 'bg-yellow-50 border-yellow-200',
    icon: AlertCircle,
  },
};

export function ContractsPage() {
  const { contracts: allContracts, updateContract, uploadContractFile } = useContracts();
  const { currentClient } = useApp();
  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  // Filter contracts by current client
  const contracts = currentClient 
    ? allContracts.filter(c => c.clientId === currentClient.id)
    : allContracts;

  const handleDownload = (contractId: string) => {
    const contract = contracts.find(c => c.id === contractId);
    if (contract?.fileUrl) {
      // Criar um link temporário para download
      const link = document.createElement('a');
      link.href = contract.fileUrl;
      link.download = `Contrato_${contract.creatorName.replace(/\s+/g, '_')}.pdf`;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success(`Baixando contrato de ${contract.creatorName}...`);
    } else {
      toast.error('Arquivo não encontrado');
    }
  };

  const handleCopyEmail = (email: string) => {
    // Método alternativo que funciona em todos os navegadores
    const textArea = document.createElement('textarea');
    textArea.value = email;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      document.execCommand('copy');
      toast.success('Email copiado para a área de transferência!');
    } catch (err) {
      toast.error('Erro ao copiar email');
    }
    
    document.body.removeChild(textArea);
  };

  const handleStatusChange = (contractId: string, newStatus: 'sent' | 'signed' | 'pending') => {
    const updates: any = { status: newStatus };
    
    if (newStatus === 'signed' && !contracts.find(c => c.id === contractId)?.signedDate) {
      updates.signedDate = new Date().toISOString().split('T')[0];
    }
    
    updateContract(contractId, updates);
    toast.success('Status do contrato atualizado!');
  };

  const handleFileUpload = async (contractId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast.error('Por favor, envie apenas arquivos PDF');
      return;
    }

    toast.loading('Fazendo upload do contrato...', { id: 'upload' });
    
    try {
      await uploadContractFile(contractId, file);
      toast.success('Contrato enviado com sucesso!', { id: 'upload' });
    } catch (error) {
      toast.error('Erro ao enviar contrato', { id: 'upload' });
    }
  };

  const handleRemoveFile = (contractId: string) => {
    updateContract(contractId, { fileUrl: '', status: 'pending' });
    toast.success('Contrato removido');
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  return (
    <div className="p-3 md:p-6 space-y-4 md:space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Contratos</h1>
        <p className="text-sm text-gray-600 mt-1">Gerencie contratos de creators</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <p className="text-sm text-gray-600 mb-1">Total de Contratos</p>
          <p className="text-2xl md:text-3xl font-semibold text-gray-900">{contracts.length}</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <p className="text-sm text-gray-600 mb-1">Assinados</p>
          <p className="text-2xl md:text-3xl font-semibold text-green-600">
            {contracts.filter((c) => c.status === 'signed').length}
          </p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <p className="text-sm text-gray-600 mb-1">Pendentes</p>
          <p className="text-2xl md:text-3xl font-semibold text-yellow-600">
            {contracts.filter((c) => c.status === 'pending' || c.status === 'sent').length}
          </p>
        </div>
      </div>

      {/* Contracts List */}
      <div className="space-y-4">
        {contracts.map((contract) => {
          const status = statusConfig[contract.status];
          const StatusIcon = status.icon;

          return (
            <div key={contract.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-4 md:p-6">
                <div className="flex flex-col gap-4 mb-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 md:p-3 bg-blue-50 rounded-xl flex-shrink-0">
                      <FileText className="w-5 h-5 md:w-6 md:h-6 text-blue-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base md:text-lg font-semibold text-gray-900">{contract.creatorName}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs md:text-sm text-gray-600 truncate">{contract.creatorEmail}</span>
                        <button
                          onClick={() => handleCopyEmail(contract.creatorEmail)}
                          className="p-1 hover:bg-gray-200 rounded transition-colors flex-shrink-0"
                          title="Copiar email"
                        >
                          <Copy className="w-3 h-3 md:w-3.5 md:h-3.5 text-gray-500" />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1.5">Status do Contrato</p>
                    <select
                      value={contract.status}
                      onChange={(e) => handleStatusChange(contract.id, e.target.value as any)}
                      className={`w-full md:w-auto px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500 ${status.bg} ${status.color}`}
                    >
                      <option value="pending">Pendente</option>
                      <option value="sent">Enviado</option>
                      <option value="signed">Assinado</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 md:gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Data de Envio</p>
                    <p className="text-xs md:text-sm font-medium text-gray-900">
                      {contract.sentDate ? formatDate(contract.sentDate) : '—'}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Data de Assinatura</p>
                    <p className="text-xs md:text-sm font-medium text-gray-900">
                      {contract.signedDate ? formatDate(contract.signedDate) : '—'}
                    </p>
                  </div>
                </div>

                {/* Upload Area */}
                <div className="border-t border-gray-200 pt-4">
                  <p className="text-sm font-medium text-gray-700 mb-3">Documento do Contrato</p>
                  
                  {contract.fileUrl ? (
                    // File uploaded - show file info
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 p-3 md:p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-100 rounded-lg flex-shrink-0">
                          <File className="w-4 h-4 md:w-5 md:h-5 text-green-600" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs md:text-sm font-medium text-green-900">Contrato enviado</p>
                          <p className="text-xs text-green-700 mt-0.5 truncate">
                            {contract.fileUrl.split('/').pop()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleDownload(contract.id)}
                          className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-xs md:text-sm font-medium"
                        >
                          <Download className="w-4 h-4" />
                          Baixar PDF
                        </button>
                        <button
                          onClick={() => handleRemoveFile(contract.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors flex-shrink-0"
                          title="Remover arquivo"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    // No file - show upload area
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 md:p-6 text-center hover:border-blue-400 hover:bg-blue-50 transition-colors">
                      <input
                        ref={(el) => (fileInputRefs.current[contract.id] = el)}
                        type="file"
                        accept=".pdf"
                        onChange={(e) => handleFileUpload(contract.id, e)}
                        className="hidden"
                      />
                      <Upload className="w-6 h-6 md:w-8 md:h-8 text-gray-400 mx-auto mb-2 md:mb-3" />
                      <p className="text-xs md:text-sm font-medium text-gray-700 mb-1">
                        Nenhum contrato enviado
                      </p>
                      <p className="text-xs text-gray-500 mb-3 md:mb-4">
                        Faça upload do contrato assinado em PDF
                      </p>
                      <button
                        onClick={() => fileInputRefs.current[contract.id]?.click()}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-xs md:text-sm font-medium"
                      >
                        <Upload className="w-4 h-4" />
                        Selecionar arquivo PDF
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {contracts.length === 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">Nenhum contrato pendente</p>
          <p className="text-sm text-gray-400 mt-1">
            Aprove creators para gerar contratos automaticamente
          </p>
        </div>
      )}
    </div>
  );
}