import { TrendingUp, Users, DollarSign, CheckCircle, AlertCircle, Clock, Instagram, Youtube, PlaySquare } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { usePermissions } from '@/app/hooks/usePermissions';
import { useCreators } from '@/app/contexts/CreatorsContext';
import { useApp } from '@/app/contexts/AppContext';

export function DashboardPage() {
  const { canViewMargins } = usePermissions();
  const { creators: allCreators } = useCreators();
  const { currentClient, user } = useApp();

  // Filter creators by current client
  const mockCreators = currentClient 
    ? allCreators.filter(c => c.clientId === currentClient.id)
    : allCreators;

  // Calculate stats
  const totalCreators = mockCreators.length;
  const approvedCreators = mockCreators.filter((c) => c.status === 'approved' || c.status === 'completed').length;
  const pendingCreators = mockCreators.filter((c) => c.status === 'in_approval').length;
  const totalReach = mockCreators.reduce((sum, c) => sum + c.averageReach, 0);
  const totalClientValue = mockCreators.reduce((sum, c) => sum + c.clientValue, 0);
  const totalCreatorCost = mockCreators.reduce((sum, c) => sum + c.creatorValue, 0);
  const totalMargin = totalClientValue - totalCreatorCost;

  // Chart data
  const statusData = [
    { name: 'Em aprovação', value: mockCreators.filter((c) => c.status === 'in_approval').length, color: '#fbbf24' },
    { name: 'Aprovados', value: mockCreators.filter((c) => c.status === 'approved').length, color: '#10b981' },
    { name: 'Negociando', value: mockCreators.filter((c) => c.status === 'negotiating').length, color: '#3b82f6' },
    { name: 'Finalizados', value: mockCreators.filter((c) => c.status === 'completed').length, color: '#6b7280' },
  ];

  const networkData = [
    { name: 'Instagram', creators: mockCreators.filter((c) => c.socialNetwork === 'Instagram').length },
    { name: 'TikTok', creators: mockCreators.filter((c) => c.socialNetwork === 'TikTok').length },
    { name: 'YouTube', creators: mockCreators.filter((c) => c.socialNetwork === 'YouTube').length },
  ];

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(num);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return num.toString();
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Dashboard</h1>
        <p className="text-xs md:text-sm text-gray-600 mt-1">Visão geral da campanha</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <div className="flex items-center justify-between mb-3 md:mb-4">
            <div className="p-2 md:p-3 bg-blue-50 rounded-xl">
              <Users className="w-4 h-4 md:w-6 md:h-6 text-blue-500" />
            </div>
          </div>
          <p className="text-xs md:text-sm text-gray-600 mb-1">Total de Creators</p>
          <p className="text-2xl md:text-3xl font-semibold text-gray-900">{totalCreators}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <div className="flex items-center justify-between mb-3 md:mb-4">
            <div className="p-2 md:p-3 bg-green-50 rounded-xl">
              <CheckCircle className="w-4 h-4 md:w-6 md:h-6 text-green-500" />
            </div>
          </div>
          <p className="text-xs md:text-sm text-gray-600 mb-1">Aprovados</p>
          <p className="text-2xl md:text-3xl font-semibold text-gray-900">{approvedCreators}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <div className="flex items-center justify-between mb-3 md:mb-4">
            <div className="p-2 md:p-3 bg-yellow-50 rounded-xl">
              <Clock className="w-4 h-4 md:w-6 md:h-6 text-yellow-500" />
            </div>
          </div>
          <p className="text-xs md:text-sm text-gray-600 mb-1">Pendentes</p>
          <p className="text-2xl md:text-3xl font-semibold text-gray-900">{pendingCreators}</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
          <div className="flex items-center justify-between mb-3 md:mb-4">
            <div className="p-2 md:p-3 bg-purple-50 rounded-xl">
              <TrendingUp className="w-4 h-4 md:w-6 md:h-6 text-purple-500" />
            </div>
          </div>
          <p className="text-xs md:text-sm text-gray-600 mb-1">Alcance Total</p>
          <p className="text-2xl md:text-3xl font-semibold text-gray-900">{formatNumber(totalReach)}</p>
        </div>
      </div>

      {/* Financial Stats (Admin Only) */}
      {canViewMargins && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
            <div className="flex items-center justify-between mb-3 md:mb-4">
              <div className="p-2 md:p-3 bg-blue-50 rounded-xl">
                <DollarSign className="w-4 h-4 md:w-6 md:h-6 text-blue-500" />
              </div>
              <TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-green-500" />
            </div>
            <p className="text-xs md:text-sm text-gray-600 mb-1">Valor Total Cliente</p>
            <p className="text-xl md:text-3xl font-semibold text-gray-900">{formatCurrency(totalClientValue)}</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
            <div className="flex items-center justify-between mb-3 md:mb-4">
              <div className="p-2 md:p-3 bg-red-50 rounded-xl">
                <DollarSign className="w-4 h-4 md:w-6 md:h-6 text-red-500" />
              </div>
            </div>
            <p className="text-xs md:text-sm text-gray-600 mb-1">Custo Total Creators</p>
            <p className="text-xl md:text-3xl font-semibold text-gray-900">{formatCurrency(totalCreatorCost)}</p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
            <div className="flex items-center justify-between mb-3 md:mb-4">
              <div className="p-2 md:p-3 bg-green-50 rounded-xl">
                <TrendingUp className="w-4 h-4 md:w-6 md:h-6 text-green-500" />
              </div>
              <TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-green-500" />
            </div>
            <p className="text-xs md:text-sm text-gray-600 mb-1">Margem Total</p>
            <p className="text-xl md:text-3xl font-semibold text-green-600">{formatCurrency(totalMargin)}</p>
          </div>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Status Distribution - Enhanced */}
        <div className="bg-gradient-to-br from-white to-gray-50 rounded-2xl border-2 border-gray-200 p-4 md:p-8 shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4 md:mb-6">
            <div>
              <h2 className="text-base md:text-xl font-bold text-gray-900">Status dos Creators</h2>
              <p className="text-xs md:text-sm text-gray-500 mt-1">Distribuição por estágio</p>
            </div>
            <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-md">
              <Users className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
          </div>
          
          <div className="relative">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <defs>
                  <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
                    <feDropShadow dx="0" dy="4" stdDeviation="8" floodOpacity="0.15" />
                  </filter>
                </defs>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="45%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  filter="url(#shadow)"
                >
                  {statusData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color}
                      stroke="white"
                      strokeWidth={3}
                    />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '12px 16px',
                    boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                  }}
                />
                <Legend 
                  verticalAlign="bottom" 
                  height={36}
                  iconType="circle"
                  iconSize={8}
                  wrapperStyle={{
                    paddingTop: '20px',
                    fontSize: '11px',
                    fontWeight: '500'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            
            {/* Center Label */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none" style={{ marginTop: '-18px' }}>
              <p className="text-2xl md:text-3xl font-bold text-gray-900">{totalCreators}</p>
              <p className="text-xs text-gray-500 mt-1">Total</p>
            </div>
          </div>
          
          {/* Stats below chart */}
          <div className="grid grid-cols-2 gap-2 md:gap-3 mt-4 md:mt-6 pt-4 md:pt-6 border-t border-gray-200">
            {statusData.filter(s => s.value > 0).map((stat, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-2 h-2 md:w-3 md:h-3 rounded-full" style={{ backgroundColor: stat.color }}></div>
                <span className="text-xs md:text-sm text-gray-700">{stat.name}: <span className="font-semibold">{stat.value}</span></span>
              </div>
            ))}
          </div>
        </div>

        {/* Network Distribution - Enhanced */}
        <div className="bg-gradient-to-br from-white to-gray-50 rounded-2xl border-2 border-gray-200 p-4 md:p-8 shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4 md:mb-6">
            <div>
              <h2 className="text-base md:text-xl font-bold text-gray-900">Creators por Rede Social</h2>
              <p className="text-xs md:text-sm text-gray-500 mt-1">Distribuição de plataformas</p>
            </div>
            <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-md">
              <Instagram className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
          </div>
          
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={networkData} margin={{ top: 20, right: 10, left: -20, bottom: 20 }}>
              <defs>
                <linearGradient id="colorInstagram" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#E1306C" stopOpacity={1}/>
                  <stop offset="95%" stopColor="#FD1D1D" stopOpacity={0.8}/>
                </linearGradient>
                <linearGradient id="colorTikTok" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00f2ea" stopOpacity={1}/>
                  <stop offset="95%" stopColor="#ff0050" stopOpacity={0.8}/>
                </linearGradient>
                <linearGradient id="colorYouTube" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FF0000" stopOpacity={1}/>
                  <stop offset="95%" stopColor="#CC0000" stopOpacity={0.8}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 11, fontWeight: 500 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 10 }}
                allowDecimals={false}
              />
              <Tooltip 
                cursor={{ fill: 'rgba(59, 130, 246, 0.05)' }}
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '12px',
                  padding: '12px 16px',
                  boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                }}
                labelStyle={{ fontWeight: 600, color: '#111827', marginBottom: '4px' }}
              />
              <Bar 
                dataKey="creators" 
                fill="url(#colorInstagram)"
                radius={[12, 12, 0, 0]}
                maxBarSize={60}
              >
                {networkData.map((entry, index) => {
                  let fillColor = "url(#colorInstagram)";
                  if (entry.name === "TikTok") fillColor = "url(#colorTikTok)";
                  if (entry.name === "YouTube") fillColor = "url(#colorYouTube)";
                  return <Cell key={`cell-${index}`} fill={fillColor} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          
          {/* Social Icons Row */}
          <div className="flex items-center justify-around mt-4 md:mt-6 pt-4 md:pt-6 border-t border-gray-200">
            {networkData.map((network, index) => {
              const icons = {
                'Instagram': <Instagram className="w-4 h-4 md:w-5 md:h-5" />,
                'TikTok': <PlaySquare className="w-4 h-4 md:w-5 md:h-5" />,
                'YouTube': <Youtube className="w-4 h-4 md:w-5 md:h-5" />
              };
              const colors = {
                'Instagram': 'from-pink-500 to-purple-500',
                'TikTok': 'from-cyan-400 to-pink-500',
                'YouTube': 'from-red-500 to-red-600'
              };
              return (
                <div key={index} className="flex flex-col items-center gap-1 md:gap-2">
                  <div className={`w-8 h-8 md:w-10 md:h-10 bg-gradient-to-br ${colors[network.name as keyof typeof colors]} rounded-lg flex items-center justify-center shadow-md text-white`}>
                    {icons[network.name as keyof typeof icons]}
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-gray-500">{network.name}</p>
                    <p className="text-base md:text-lg font-bold text-gray-900">{network.creators}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 md:p-6">
        <h2 className="text-base md:text-lg font-semibold text-gray-900 mb-4">Atividades Recentes</h2>
        <div className="space-y-4">
          <div className="flex items-start gap-3 md:gap-4 pb-4 border-b border-gray-100">
            <div className="p-2 bg-green-50 rounded-xl">
              <CheckCircle className="w-4 h-4 text-green-500" />
            </div>
            <div className="flex-1">
              <p className="text-xs md:text-sm font-medium text-gray-900">Mariana Costa aprovada</p>
              <p className="text-xs text-gray-500 mt-1">Há 2 horas</p>
            </div>
          </div>
          <div className="flex items-start gap-3 md:gap-4 pb-4 border-b border-gray-100">
            <div className="p-2 bg-green-50 rounded-xl">
              <CheckCircle className="w-4 h-4 text-green-500" />
            </div>
            <div className="flex-1">
              <p className="text-xs md:text-sm font-medium text-gray-900">Rafael Santos aprovado</p>
              <p className="text-xs text-gray-500 mt-1">Há 5 horas</p>
            </div>
          </div>
          <div className="flex items-start gap-3 md:gap-4 pb-4 border-b border-gray-100">
            <div className="p-2 bg-blue-50 rounded-xl">
              <AlertCircle className="w-4 h-4 text-blue-500" />
            </div>
            <div className="flex-1">
              <p className="text-xs md:text-sm font-medium text-gray-900">Carlos Mendes em negociação</p>
              <p className="text-xs text-gray-500 mt-1">Há 1 dia</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}