import { useState } from 'react';
import { Building2, Plus, X, TrendingUp, DollarSign, Megaphone, Eye, Edit2 } from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';
import { toast } from 'sonner';

export function ClientsPage() {
  const { clients, addClient, updateClient, removeClient, setCurrentClient, setCurrentPage } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingClient, setEditingClient] = useState<any>(null);
  const [newClient, setNewClient] = useState({
    name: '',
    description: '',
    industry: '',
    totalSpent: '',
  });
  const [editClient, setEditClient] = useState({
    name: '',
    description: '',
    industry: '',
    totalSpent: '',
  });

  const handleAddClient = (e: React.FormEvent) => {
    e.preventDefault();
    addClient({
      name: newClient.name,
      description: newClient.description,
      industry: newClient.industry,
      totalSpent: newClient.totalSpent ? parseFloat(newClient.totalSpent) : 0,
    });
    setNewClient({ name: '', description: '', industry: '', totalSpent: '' });
    setShowAddModal(false);
  };

  const handleEditClient = (e: React.FormEvent) => {
    e.preventDefault();
    updateClient(editingClient.id, {
      name: editClient.name,
      description: editClient.description,
      industry: editClient.industry,
      totalSpent: editClient.totalSpent ? parseFloat(editClient.totalSpent) : 0,
    });
    toast.success('Cliente atualizado com sucesso!');
    setEditClient({ name: '', description: '', industry: '', totalSpent: '' });
    setEditingClient(null);
    setShowEditModal(false);
  };

  const handleViewClient = (client: any) => {
    setCurrentClient(client);
    setCurrentPage('dashboard');
  };

  const industries = [
    'Saúde',
    'Varejo',
    'Tecnologia',
    'Educação',
    'Alimentação',
    'Moda',
    'Financeiro',
    'Outros',
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Clientes</h1>
          <p className="text-sm text-gray-600 mt-1">Gerencie todos os seus clientes e acesse suas dashboards</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium shadow-sm"
        >
          <Plus className="w-5 h-5" />
          Novo Cliente
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-700 font-medium">Total de Clientes</p>
              <p className="text-3xl font-bold text-blue-900 mt-1">{clients.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
              <Building2 className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-700 font-medium">Campanhas Ativas</p>
              <p className="text-3xl font-bold text-green-900 mt-1">
                {clients.reduce((sum, c) => sum + (c.activeCampaigns || 0), 0)}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
              <Megaphone className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-700 font-medium">Receita Total</p>
              <p className="text-3xl font-bold text-purple-900 mt-1">
                R$ {(clients.reduce((sum, c) => sum + (c.totalSpent || 0), 0) / 1000).toFixed(0)}k
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {clients.map((client) => (
          <div
            key={client.id}
            className="bg-white rounded-xl border-2 border-gray-200 hover:border-blue-400 transition-all hover:shadow-lg group"
          >
            <div className="p-6">
              {/* Client Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-md">
                    <span className="text-white font-bold text-xl">
                      {client.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">{client.name}</h3>
                    <span className="inline-block px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                      {client.industry}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setEditingClient(client);
                    setEditClient({
                      name: client.name,
                      description: client.description,
                      industry: client.industry,
                      totalSpent: client.totalSpent.toString(),
                    });
                    setShowEditModal(true);
                  }}
                  className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Edit2 className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-600 mb-4 line-clamp-2">{client.description}</p>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-blue-50 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Megaphone className="w-4 h-4 text-blue-600" />
                    <span className="text-xs text-blue-700 font-medium">Campanhas</span>
                  </div>
                  <p className="text-xl font-bold text-blue-900">{client.activeCampaigns}</p>
                </div>
                <div className="bg-green-50 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-green-700 font-medium">Investido</span>
                  </div>
                  <p className="text-xl font-bold text-green-900">
                    R$ {((client.totalSpent || 0) / 1000).toFixed(0)}k
                  </p>
                </div>
              </div>

              {/* Actions */}
              <button
                onClick={() => handleViewClient(client)}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium group-hover:shadow-md"
              >
                <Eye className="w-4 h-4" />
                Ver Dashboard
              </button>
            </div>

            {/* Footer */}
            <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 rounded-b-xl flex items-center justify-between">
              <span className="text-xs text-gray-500">
                Desde {new Date(client.createdAt).toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' })}
              </span>
              <button
                onClick={() => removeClient(client.id)}
                className="text-xs text-red-600 hover:text-red-700 font-medium"
              >
                Remover
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {clients.length === 0 && (
        <div className="bg-white rounded-xl border-2 border-dashed border-gray-300 p-12 text-center">
          <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum cliente cadastrado</h3>
          <p className="text-sm text-gray-600 mb-6">Comece adicionando seu primeiro cliente</p>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            <Plus className="w-5 h-5" />
            Adicionar Cliente
          </button>
        </div>
      )}

      {/* Add Client Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Adicionar Novo Cliente</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleAddClient} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome do Cliente
                </label>
                <input
                  type="text"
                  value={newClient.name}
                  onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
                  placeholder="Ex: Magazine Luiza"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Descrição
                </label>
                <textarea
                  value={newClient.description}
                  onChange={(e) => setNewClient({ ...newClient, description: e.target.value })}
                  placeholder="Breve descrição do cliente..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Segmento
                </label>
                <select
                  value={newClient.industry}
                  onChange={(e) => setNewClient({ ...newClient, industry: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Selecione um segmento</option>
                  {industries.map((industry) => (
                    <option key={industry} value={industry}>
                      {industry}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Investimento Inicial (R$)
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">R$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={newClient.totalSpent}
                    onChange={(e) => setNewClient({ ...newClient, totalSpent: e.target.value })}
                    placeholder="0,00"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Valor do investimento inicial ou orçamento do cliente
                </p>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Adicionar
                </button>
              </div>
            </form>

            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-800">
                💡 <strong>Dica:</strong> Depois de criar o cliente, você pode acessar a dashboard específica dele clicando em "Ver Dashboard".
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Edit Client Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Editar Cliente</h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleEditClient} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome do Cliente
                </label>
                <input
                  type="text"
                  value={editClient.name}
                  onChange={(e) => setEditClient({ ...editClient, name: e.target.value })}
                  placeholder="Ex: Magazine Luiza"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Descrição
                </label>
                <textarea
                  value={editClient.description}
                  onChange={(e) => setEditClient({ ...editClient, description: e.target.value })}
                  placeholder="Breve descrição do cliente..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Segmento
                </label>
                <select
                  value={editClient.industry}
                  onChange={(e) => setEditClient({ ...editClient, industry: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Selecione um segmento</option>
                  {industries.map((industry) => (
                    <option key={industry} value={industry}>
                      {industry}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Investimento Inicial (R$)
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">R$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={editClient.totalSpent}
                    onChange={(e) => setEditClient({ ...editClient, totalSpent: e.target.value })}
                    placeholder="0,00"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Valor do investimento inicial ou orçamento do cliente
                </p>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Salvar
                </button>
              </div>
            </form>

            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-800">
                💡 <strong>Dica:</strong> Depois de criar o cliente, você pode acessar a dashboard específica dele clicando em "Ver Dashboard".
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}