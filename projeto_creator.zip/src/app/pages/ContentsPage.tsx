import { Image as ImageIcon, CheckCircle, XCircle, Clock, Eye, Upload, Video, FileText, Trash2, Download, Plus, Link as LinkIcon, Play, MessageSquare, Send } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { useApp } from '@/app/contexts/AppContext';
import { mockContents } from '@/app/data/mockData';
import type { Content } from '@/app/data/mockData';

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  uploadedAt: string;
  creatorName: string;
  campaignId: string;
  isGoogleDrive?: boolean;
  status: 'pending' | 'approved' | 'rejected' | 'awaiting_approval' | 'revision';
  feedback?: string;
  comment?: string;
  commentAuthor?: string;
  commentSentAt?: string;
  contentType: 'video' | 'script';
}

interface ContentComment {
  text: string;
  author: string;
  sentAt: string;
  isAdmin: boolean;
  requestAdjustment?: boolean;
}

interface SystemEvent {
  type: 'upload' | 'approved' | 'rejected' | 'adjustment_requested' | 'admin_replied';
  timestamp: string;
}

interface CommentThread {
  comments: ContentComment[];
  events: SystemEvent[];
}

const statusConfig = {
  submitted: {
    label: 'Enviado',
    color: 'text-blue-700',
    bg: 'bg-blue-50 border-blue-200',
    icon: Clock,
  },
  approved: {
    label: 'Aprovado',
    color: 'text-green-700',
    bg: 'bg-green-50 border-green-200',
    icon: CheckCircle,
  },
  rejected: {
    label: 'Reprovado',
    color: 'text-red-700',
    bg: 'bg-red-50 border-red-200',
    icon: XCircle,
  },
};

const typeLabels = {
  post: 'Post',
  story: 'Story',
  reel: 'Reel',
  video: 'Vídeo',
};

export function ContentsPage() {
  const [allContents, setAllContents] = useState<Content[]>(mockContents);
  const { currentClient, currentCampaign, user } = useApp();
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadCreatorName, setUploadCreatorName] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [uploadMethod, setUploadMethod] = useState<'file' | 'link'>('link');
  const [googleDriveLink, setGoogleDriveLink] = useState('');
  const [selectedContentType, setSelectedContentType] = useState<'video' | 'script'>('video');
  const [commentThreads, setCommentThreads] = useState<Record<string, CommentThread>>({});
  const [tempCommentInputs, setTempCommentInputs] = useState<Record<string, string>>({});
  const [requestAdjustment, setRequestAdjustment] = useState<Record<string, boolean>>({});
  const [showFullHistory, setShowFullHistory] = useState<Record<string, boolean>>({});

  const isAdmin = user?.role === 'admin';

  // Filter contents by current client
  const contents = currentClient 
    ? allContents.filter(c => c.clientId === currentClient.id)
    : allContents;

  // Filter uploaded files - mostrar todos se não houver campanha, ou filtrar pela campanha atual
  const filteredFiles = currentCampaign
    ? uploadedFiles.filter(f => f.campaignId === currentCampaign.id)
    : uploadedFiles;

  const handleApprove = (id: string) => {
    setAllContents(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'approved' as const } : c
    ));
    toast.success('Conteúdo aprovado com sucesso!');
  };

  const handleReject = (id: string) => {
    setAllContents(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'rejected' as const, feedback: 'Não está alinhado com o briefing da campanha' } : c
    ));
    toast.error('Conteúdo reprovado.');
  };

  const handleSendFileComment = (id: string) => {
    const text = tempCommentInputs[id]?.trim();
    if (!text) {
      toast.error('Digite um comentário antes de enviar');
      return;
    }

    const hasAdjustmentRequest = requestAdjustment[id] || false;
    
    const newComment: ContentComment = {
      text,
      author: user?.name || (isAdmin ? 'Admin' : 'Cliente'),
      sentAt: new Date().toISOString(),
      isAdmin,
      requestAdjustment: !isAdmin && hasAdjustmentRequest,
    };

    // Adicionar comentário à thread
    setCommentThreads(prev => {
      const existing = prev[id] || { comments: [], events: [] };
      return {
        ...prev,
        [id]: {
          comments: [...existing.comments, newComment],
          events: existing.events,
        },
      };
    });

    // Se cliente solicitar ajuste, mudar status para 'revision'
    if (!isAdmin && hasAdjustmentRequest) {
      setUploadedFiles(prev => prev.map(f => 
        f.id === id ? { ...f, status: 'revision' as const } : f
      ));
      addSystemEvent(id, 'adjustment_requested');
      toast.info('Solicitação de ajuste enviada!');
    } else {
      toast.success('Comentário enviado com sucesso!');
    }

    // Limpar campo de input
    setTempCommentInputs(prev => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });

    // Limpar checkbox de ajuste
    setRequestAdjustment(prev => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };

  const addSystemEvent = (fileId: string, eventType: SystemEvent['type']) => {
    setCommentThreads(prev => {
      const existing = prev[fileId] || { comments: [], events: [] };
      return {
        ...prev,
        [fileId]: {
          ...existing,
          events: [...existing.events, { type: eventType, timestamp: new Date().toISOString() }],
        },
      };
    });
  };

  const getEventMessage = (event: SystemEvent) => {
    switch (event.type) {
      case 'upload':
        return 'Conteúdo enviado pelo creator';
      case 'approved':
        return 'Conteúdo aprovado';
      case 'rejected':
        return 'Conteúdo reprovado';
      case 'adjustment_requested':
        return 'Cliente solicitou ajustes';
      case 'admin_replied':
        return 'Administrador respondeu';
      default:
        return '';
    }
  };

  const formatDateTime = (date: string) => {
    const d = new Date(date);
    return d.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('video/')) return Video;
    if (type.startsWith('image/')) return ImageIcon;
    return FileText;
  };

  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    if (!uploadCreatorName.trim()) {
      toast.error('Por favor, informe o nome do creator');
      return;
    }
    if (!currentCampaign) {
      toast.error('Selecione uma campanha primeiro');
      return;
    }

    const newFiles: UploadedFile[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      // Criar URL temporária para o arquivo
      const url = URL.createObjectURL(file);
      
      const uploadedFile: UploadedFile = {
        id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name: file.name,
        size: file.size,
        type: file.type,
        url,
        uploadedAt: new Date().toISOString(),
        creatorName: uploadCreatorName,
        campaignId: currentCampaign.id,
        status: 'pending',
        contentType: selectedContentType,
      };
      
      newFiles.push(uploadedFile);
    }

    setUploadedFiles(prev => [...prev, ...newFiles]);
    toast.success(`${newFiles.length} arquivo(s) enviado(s) com sucesso!`);
    setShowUploadModal(false);
    setUploadCreatorName('');
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleDeleteFile = (id: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== id));
    toast.success('Arquivo removido com sucesso!');
  };

  const handleDownloadFile = (file: UploadedFile) => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Download iniciado!');
  };

  const convertGoogleDriveLink = (url: string): string | null => {
    // Extrair ID do arquivo do Google Drive
    const patterns = [
      /\/file\/d\/([^\/]+)\//,  // Pattern padrão: /file/d/ID/
      /id=([^&]+)/,              // Pattern alternativo: ?id=ID
      /\/d\/([^\/]+)/            // Pattern curto: /d/ID
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        // Retornar URL de preview/embed do Google Drive
        return `https://drive.google.com/file/d/${match[1]}/preview`;
      }
    }

    return null;
  };

  const handleGoogleDriveLink = () => {
    if (!uploadCreatorName.trim()) {
      toast.error('Por favor, informe o nome do creator');
      return;
    }
    if (!googleDriveLink.trim()) {
      toast.error('Por favor, informe o link do Google Drive');
      return;
    }
    if (!currentCampaign) {
      toast.error('Selecione uma campanha primeiro');
      return;
    }

    const embedUrl = convertGoogleDriveLink(googleDriveLink);
    if (!embedUrl) {
      toast.error('Link do Google Drive inválido. Verifique o formato.');
      return;
    }

    const uploadedFile: UploadedFile = {
      id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: selectedContentType === 'video' ? 'Vídeo do Google Drive' : 'Roteiro do Google Drive',
      size: 0,
      type: 'video/google-drive',
      url: embedUrl,
      uploadedAt: new Date().toISOString(),
      creatorName: uploadCreatorName,
      campaignId: currentCampaign.id,
      isGoogleDrive: true,
      status: 'pending',
      contentType: selectedContentType,
    };

    setUploadedFiles(prev => [...prev, uploadedFile]);
    toast.success('Link do Google Drive adicionado com sucesso!');
    setShowUploadModal(false);
    setUploadCreatorName('');
    setGoogleDriveLink('');
    setIsDragging(false);
  };

  const handleApproveFile = (id: string) => {
    const currentFile = uploadedFiles.find(f => f.id === id);
    
    // Se admin está enviando para aprovação (do status pending ou revision)
    if (isAdmin && (currentFile?.status === 'pending' || currentFile?.status === 'revision')) {
      setUploadedFiles(prev => prev.map(f => 
        f.id === id ? { ...f, status: 'awaiting_approval' as const } : f
      ));
      addSystemEvent(id, 'admin_replied');
      toast.success('Material enviado para aprovação do cliente!');
    } else {
      // Cliente aprovando
      setUploadedFiles(prev => prev.map(f => 
        f.id === id ? { ...f, status: 'approved' as const } : f
      ));
      addSystemEvent(id, 'approved');
      toast.success('Material aprovado com sucesso!');
    }
  };

  const handleRejectFile = (id: string) => {
    setUploadedFiles(prev => prev.map(f => 
      f.id === id ? { ...f, status: 'rejected' as const, feedback: 'Material não está de acordo com o briefing da campanha' } : f
    ));
    toast.error('Material reprovado.');
  };

  const handleCommentChange = (id: string, comment: ContentComment) => {
    setUploadedFiles(prev => prev.map(f => 
      f.id === id ? { ...f, comment } : f
    ));
  };

  const getStatusConfig = (status: 'pending' | 'approved' | 'rejected' | 'awaiting_approval' | 'revision') => {
    switch (status) {
      case 'pending':
        return {
          label: 'Aguardando Aprovação',
          color: 'text-blue-700',
          bg: 'bg-blue-50 border-blue-200',
          icon: Clock,
        };
      case 'approved':
        return {
          label: 'Aprovado',
          color: 'text-green-700',
          bg: 'bg-green-50 border-green-200',
          icon: CheckCircle,
        };
      case 'rejected':
        return {
          label: 'Reprovado',
          color: 'text-red-700',
          bg: 'bg-red-50 border-red-200',
          icon: XCircle,
        };
      case 'awaiting_approval':
        return {
          label: 'Aguardando Aprovação',
          color: 'text-blue-700',
          bg: 'bg-blue-50 border-blue-200',
          icon: Clock,
        };
      case 'revision':
        return {
          label: 'Revisão Solicitada',
          color: 'text-orange-700',
          bg: 'bg-orange-50 border-orange-200',
          icon: XCircle,
        };
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Conteúdos</h1>
          <p className="text-sm text-gray-600 mt-1">Aprove e gerencie conteúdos dos creators</p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Adicionar Material
          </button>
        )}
      </div>

      {/* Materials Grid */}
      {filteredFiles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFiles.map((file) => {
            const FileIcon = getFileIcon(file.type);
            const isVideo = file.type.startsWith('video/');
            const isImage = file.type.startsWith('image/');
            const isGoogleDrive = file.isGoogleDrive;
            const statusInfo = getStatusConfig(file.status);
            const StatusIcon = statusInfo.icon;

            return (
              <div key={file.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all group">
                {/* Clickable Preview Area */}
                <div
                  onClick={() => {
                    if (isGoogleDrive) {
                      window.open(file.url.replace('/preview', '/view'), '_blank');
                    }
                  }}
                  className={`relative h-48 bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 ${isGoogleDrive ? 'cursor-pointer' : ''}`}
                >
                  {/* Content Preview */}
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-white">
                    <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-5 mb-3 group-hover:scale-110 transition-transform">
                      {isGoogleDrive ? (
                        <Play className="w-10 h-10" />
                      ) : file.contentType === 'video' ? (
                        <Video className="w-10 h-10" />
                      ) : (
                        <FileText className="w-10 h-10" />
                      )}
                    </div>
                    <p className="font-semibold text-center mb-1">{file.name}</p>
                    <p className="text-sm text-blue-100 text-center">{file.creatorName}</p>
                  </div>

                  {/* Badges - Top Row */}
                  <div className="absolute top-3 left-3 right-3 flex items-start justify-between gap-2">
                    {/* Left Badges */}
                    <div className="flex items-center gap-2">
                      {/* Content Type Badge */}
                      {file.contentType === 'video' ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-500 text-white shadow-sm">
                          <Video className="w-3 h-3" />
                          Vídeo
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-orange-500 text-white shadow-sm">
                          <FileText className="w-3 h-3" />
                          Roteiro
                        </span>
                      )}

                      {/* Google Drive Badge */}
                      {isGoogleDrive && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-white text-blue-600 shadow-sm">
                          <LinkIcon className="w-3 h-3" />
                          Google Drive
                        </span>
                      )}
                    </div>

                    {/* Status Badge - Right */}
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium shadow-sm ${statusInfo.bg} ${statusInfo.color}`}>
                      <StatusIcon className="w-3 h-3" />
                      {statusInfo.label}
                    </span>
                  </div>
                </div>

                {/* File Info */}
                <div className="p-4 space-y-3">
                  <div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      {!isGoogleDrive && file.size > 0 && (
                        <>
                          <span>{formatFileSize(file.size)}</span>
                          <span>•</span>
                        </>
                      )}
                      <span>Enviado em {formatDate(file.uploadedAt)}</span>
                    </div>
                  </div>

                  {/* Comments Thread Section */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg overflow-hidden">
                    {/* Thread History with Scroll */}
                    <div className="p-3 space-y-2">
                      {/* Check if there are comments or events */}
                      {commentThreads[file.id] && (commentThreads[file.id].comments.length > 0 || commentThreads[file.id].events.length > 0) ? (
                        <>
                          {/* Show history button if more than 2 comments */}
                          {commentThreads[file.id]?.comments.length > 2 && !showFullHistory[file.id] && (
                            <button
                              onClick={() => setShowFullHistory({ ...showFullHistory, [file.id]: true })}
                              className="w-full text-xs text-blue-600 hover:text-blue-700 font-medium py-1.5 bg-blue-100 rounded-lg hover:bg-blue-200 transition-colors"
                            >
                              Ver histórico completo ({commentThreads[file.id].comments.length - 2} mensagens anteriores)
                            </button>
                          )}

                          {/* System Events - only show in full history */}
                          {showFullHistory[file.id] && commentThreads[file.id]?.events.map((event, idx) => (
                            <div key={`event-${idx}`} className="text-xs text-gray-500 italic py-1">
                              {getEventMessage(event)}
                            </div>
                          ))}

                          {/* Comments - show last 2 or all if expanded */}
                          {(() => {
                            const allComments = commentThreads[file.id]?.comments || [];
                            const commentsToShow = showFullHistory[file.id] 
                              ? allComments 
                              : allComments.slice(-2);

                            return commentsToShow.map((comment, idx) => {
                              const originalIdx = showFullHistory[file.id] ? idx : allComments.length - 2 + idx;
                              return (
                                <div
                                  key={`comment-${originalIdx}`}
                                  className={`p-2.5 rounded-lg ${
                                    comment.isAdmin 
                                      ? 'bg-white border border-gray-200' 
                                      : 'bg-blue-100 border border-blue-300'
                                  } ${
                                    comment.requestAdjustment 
                                      ? 'border-l-4 border-l-orange-500' 
                                      : ''
                                  }`}
                                >
                                  <div className="flex items-start justify-between gap-2 mb-1">
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-xs font-semibold text-gray-900">
                                        {comment.author}
                                      </span>
                                      <span className={`text-xs px-1.5 py-0.5 rounded ${
                                        comment.isAdmin 
                                          ? 'bg-gray-200 text-gray-600' 
                                          : 'bg-blue-200 text-blue-700'
                                      }`}>
                                        {comment.isAdmin ? 'Admin' : 'Cliente'}
                                      </span>
                                    </div>
                                    <span className="text-xs text-gray-500 whitespace-nowrap">
                                      {formatDateTime(comment.sentAt)}
                                    </span>
                                  </div>
                                  <p className="text-xs text-gray-800">{comment.text}</p>
                                  {comment.requestAdjustment && (
                                    <p className="text-xs text-orange-600 mt-1 italic">
                                      Este comentário indica que o conteúdo precisa de ajustes
                                    </p>
                                  )}
                                </div>
                              );
                            });
                          })()}

                          {/* Collapse button if history is shown */}
                          {commentThreads[file.id]?.comments.length > 2 && showFullHistory[file.id] && (
                            <button
                              onClick={() => setShowFullHistory({ ...showFullHistory, [file.id]: false })}
                              className="w-full text-xs text-blue-600 hover:text-blue-700 font-medium py-1.5 bg-blue-100 rounded-lg hover:bg-blue-200 transition-colors"
                            >
                              Ocultar histórico
                            </button>
                          )}
                        </>
                      ) : (
                        <p className="text-xs text-gray-500 italic text-center py-2">
                          Nenhum comentário ainda
                        </p>
                      )}
                    </div>

                    {/* New Comment Input */}
                    <div className="border-t border-blue-200 bg-white p-3 space-y-2">
                      <textarea
                        value={tempCommentInputs[file.id] || ''}
                        onChange={(e) => setTempCommentInputs({ ...tempCommentInputs, [file.id]: e.target.value })}
                        placeholder={isAdmin ? 'Responder comentário' : 'Adicionar comentário ou solicitar ajuste'}
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none placeholder:text-gray-400"
                        rows={2}
                      />
                      
                      <div className="flex items-center justify-between">
                        {!isAdmin && (
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={requestAdjustment[file.id] || false}
                              onChange={(e) => setRequestAdjustment({ ...requestAdjustment, [file.id]: e.target.checked })}
                              className="w-4 h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                            />
                            <span className="text-xs text-gray-700 font-medium">Solicitar ajuste</span>
                          </label>
                        )}
                        {isAdmin && <div />}
                        <button
                          onClick={() => handleSendFileComment(file.id)}
                          className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-xs font-medium"
                        >
                          <Send className="w-3.5 h-3.5" />
                          Enviar
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    {/* Primary Actions (View/Download + Delete) */}
                    <div className="flex gap-2">
                      {!isGoogleDrive ? (
                        <button
                          onClick={() => handleDownloadFile(file)}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-xs font-medium"
                        >
                          <Download className="w-3.5 h-3.5" />
                          Baixar
                        </button>
                      ) : (
                        <button
                          onClick={() => window.open(file.url.replace('/preview', '/view'), '_blank')}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-xs font-medium"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Abrir
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteFile(file.id)}
                        className="flex items-center justify-center gap-1.5 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-xs font-medium"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Approval Actions - Different for Admin vs Client */}
                    {(file.status === 'pending' || file.status === 'revision' || file.status === 'awaiting_approval') && (
                      <>
                        {isAdmin ? (
                          // Admin: Single button to send for approval (only on pending or revision)
                          (file.status === 'pending' || file.status === 'revision') && (
                            <button
                              onClick={() => handleApproveFile(file.id)}
                              className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                            >
                              <Send className="w-4 h-4" />
                              Enviar para Aprovação
                            </button>
                          )
                        ) : (
                          // Client: Two buttons (Approve and Reject) - only on awaiting_approval
                          file.status === 'awaiting_approval' && (
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleApproveFile(file.id)}
                                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                              >
                                <CheckCircle className="w-4 h-4" />
                                Aprovar
                              </button>
                              <button
                                onClick={() => handleRejectFile(file.id)}
                                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                              >
                                <XCircle className="w-4 h-4" />
                                Reprovar
                              </button>
                            </div>
                          )
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
          <p className="text-sm text-gray-500">Nenhum material enviado ainda.</p>
        </div>
      )}

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Adicionar Material</h3>
              <button
                onClick={() => {
                  setShowUploadModal(false);
                  setUploadCreatorName('');
                  setIsDragging(false);
                }}
                className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <XCircle className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Creator Name Input */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome do Influenciador *
                </label>
                <input
                  type="text"
                  value={uploadCreatorName}
                  onChange={(e) => setUploadCreatorName(e.target.value)}
                  placeholder="Ex: @maria.silva"
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Content Type Selector */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de Conteúdo *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedContentType('video')}
                    className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all ${
                      selectedContentType === 'video'
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Video className="w-5 h-5" />
                    <span className="font-medium">Vídeo</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedContentType('script')}
                    className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all ${
                      selectedContentType === 'script'
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <FileText className="w-5 h-5" />
                    <span className="font-medium">Roteiro</span>
                  </button>
                </div>
              </div>

              {/* Upload Method */}
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setUploadMethod('file')}
                  className={`flex-1 px-4 py-2.5 ${
                    uploadMethod === 'file'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700'
                  } rounded-lg hover:bg-blue-700 transition-colors font-medium`}
                >
                  Upload de Arquivo
                </button>
                <button
                  onClick={() => setUploadMethod('link')}
                  className={`flex-1 px-4 py-2.5 ${
                    uploadMethod === 'link'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700'
                  } rounded-lg hover:bg-blue-700 transition-colors font-medium`}
                >
                  Link do Google Drive
                </button>
              </div>

              {/* Upload Area */}
              {uploadMethod === 'file' && (
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    isDragging
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 bg-gray-50 hover:border-gray-400'
                  }`}
                >
                  <input
                    type="file"
                    id="file-upload"
                    multiple
                    accept="video/*,image/*"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-700 font-medium mb-1">
                      Arraste arquivos aqui ou clique para selecionar
                    </p>
                    <p className="text-sm text-gray-500">
                      Suporta vídeos, imagens e outros formatos
                    </p>
                    <p className="text-xs text-gray-400 mt-2">
                      Formatos recomendados: MP4, MOV, JPG, PNG
                    </p>
                  </label>
                </div>
              )}

              {/* Google Drive Link */}
              {uploadMethod === 'link' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Link do Google Drive *
                  </label>
                  <input
                    type="text"
                    value={googleDriveLink}
                    onChange={(e) => setGoogleDriveLink(e.target.value)}
                    placeholder="Ex: https://drive.google.com/file/d/..."
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}

              {/* Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex gap-3">
                  <Video className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-900">
                    <p className="font-medium mb-1">Dica para vídeos</p>
                    <p className="text-blue-800">
                      Para melhor qualidade, envie vídeos em até 1080p. Arquivos muito grandes podem demorar mais para carregar.
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                {uploadMethod === 'link' && (
                  <button
                    type="button"
                    onClick={handleGoogleDriveLink}
                    className="flex-1 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                  >
                    Adicionar Link
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setShowUploadModal(false);
                    setUploadCreatorName('');
                    setIsDragging(false);
                  }}
                  className="flex-1 px-4 py-2.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}