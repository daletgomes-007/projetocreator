import { BarChart3, TrendingUp, Users, Eye, Target, DollarSign, Award, AlertCircle, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { useApp } from '@/app/contexts/AppContext';
import { useCreators } from '@/app/contexts/CreatorsContext';
import { usePerformance } from '@/app/contexts/PerformanceContext';
import { usePermissions } from '@/app/hooks/usePermissions';
import { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

export function InsightsPage() {
  const { currentClient, campaigns } = useApp();
  const { creators } = useCreators();
  const { performances } = usePerformance();
  const { isAdmin, canViewMargins } = usePermissions();

  // Filter data by current client
  const clientCampaigns = currentClient 
    ? campaigns.filter(c => c.clientId === currentClient.id)
    : campaigns;
  
  const clientCreators = currentClient
    ? creators.filter(c => c.clientId === currentClient.id)
    : creators;

  const clientPerformances = currentClient
    ? performances.filter(p => p.clientId === currentClient.id)
    : performances;

  // Calculate consolidated metrics
  const metrics = useMemo(() => {
    const totalImpressions = clientPerformances.reduce((sum, p) => sum + p.impressions, 0);
    const totalReach = clientPerformances.reduce((sum, p) => sum + p.reach, 0);
    const totalEngagement = clientPerformances.reduce((sum, p) => sum + p.totalEngagement, 0);
    const totalRevenue = clientPerformances.reduce((sum, p) => sum + p.attributedRevenue, 0);
    const totalCost = clientCreators.reduce((sum, c) => sum + (c.status === 'approved' || c.status === 'completed' ? c.creatorValue : 0), 0);
    const totalClientValue = clientCreators.reduce((sum, c) => sum + (c.status === 'approved' || c.status === 'completed' ? c.clientValue : 0), 0);
    const margin = totalClientValue - totalCost;
    
    const avgEngagementRate = clientPerformances.length > 0
      ? clientPerformances.reduce((sum, p) => sum + p.engagementRate, 0) / clientPerformances.length
      : 0;

    const roi = totalCost > 0 ? (totalRevenue / totalCost) : 0;

    // Count creators by status
    const creatorsInApproval = clientCreators.filter(c => c.status === 'in_approval').length;
    const creatorsApproved = clientCreators.filter(c => c.status === 'approved').length;
    const creatorsCompleted = clientCreators.filter(c => c.status === 'completed').length;
    const creatorsDenied = clientCreators.filter(c => c.status === 'denied').length;

    // Content performance
    const postsPublished = clientPerformances.filter(p => p.publicationStatus === 'Publicado').length;
    const postsScheduled = clientPerformances.filter(p => p.publicationStatus === 'Agendado').length;
    const postsPending = clientPerformances.filter(p => p.publicationStatus === 'Aguardando').length;

    return {
      totalImpressions,
      totalReach,
      totalEngagement,
      avgEngagementRate,
      totalRevenue,
      totalCost,
      totalClientValue,
      margin,
      roi,
      creatorsInApproval,
      creatorsApproved,
      creatorsCompleted,
      creatorsDenied,
      totalCreators: clientCreators.length,
      activeCampaigns: clientCampaigns.filter(c => c.status === 'active').length,
      totalCampaigns: clientCampaigns.length,
      postsPublished,
      postsScheduled,
      postsPending,
      totalPosts: clientPerformances.length,
    };
  }, [clientCreators, clientPerformances, clientCampaigns]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(num);
  };

  // Prepare chart data
  const creatorsStatusData = [
    { name: 'Em Aprovação', value: metrics.creatorsInApproval, color: '#f59e0b' },
    { name: 'Aprovados', value: metrics.creatorsApproved, color: '#10b981' },
    { name: 'Finalizados', value: metrics.creatorsCompleted, color: '#6b7280' },
    { name: 'Negados', value: metrics.creatorsDenied, color: '#ef4444' },
  ];

  const contentStatusData = [
    { name: 'Publicado', value: metrics.postsPublished, color: '#10b981' },
    { name: 'Agendado', value: metrics.postsScheduled, color: '#3b82f6' },
    { name: 'Aguardando', value: metrics.postsPending, color: '#f59e0b' },
  ];

  // Top performers by engagement
  const topPerformers = clientPerformances
    .filter(p => p.publicationStatus === 'Publicado')
    .sort((a, b) => b.totalEngagement - a.totalEngagement)
    .slice(0, 5)
    .map(p => ({
      name: p.creatorName,
      engajamento: p.totalEngagement,
      alcance: p.reach,
      taxa: p.engagementRate,
    }));

  // Campaign performance data
  const campaignData = clientCampaigns.map(campaign => {
    const campaignPerfs = clientPerformances.filter(p => p.campaignId === campaign.id);
    const campaignCreators = clientCreators.filter(c => c.campaignId === campaign.id);
    return {
      name: campaign.name.length > 15 ? campaign.name.substring(0, 15) + '...' : campaign.name,
      impressoes: campaignPerfs.reduce((sum, p) => sum + p.impressions, 0),
      alcance: campaignPerfs.reduce((sum, p) => sum + p.reach, 0),
      engajamento: campaignPerfs.reduce((sum, p) => sum + p.totalEngagement, 0),
      creators: campaignCreators.length,
    };
  });

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Insights / Relatórios</h1>
        <p className="text-sm text-gray-600 mt-1">
          {currentClient ? `Análise de desempenho - ${currentClient.name}` : 'Análise geral de desempenho'}
        </p>
      </div>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-blue-50 rounded-xl">
              <Eye className="w-5 h-5 text-blue-500" />
            </div>
            <p className="text-sm text-gray-600">Impressões</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">{formatNumber(metrics.totalImpressions)}</p>
          <p className="text-xs text-gray-500 mt-2">{metrics.postsPublished} posts publicados</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-purple-50 rounded-xl">
              <Users className="w-5 h-5 text-purple-500" />
            </div>
            <p className="text-sm text-gray-600">Alcance</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">{formatNumber(metrics.totalReach)}</p>
          <p className="text-xs text-gray-500 mt-2">{metrics.totalCreators} creators no total</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-green-50 rounded-xl">
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-sm text-gray-600">Engajamento</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">{formatNumber(metrics.totalEngagement)}</p>
          <p className="text-xs text-gray-500 mt-2">{metrics.avgEngagementRate.toFixed(2)}% taxa média</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-orange-50 rounded-xl">
              <BarChart3 className="w-5 h-5 text-orange-500" />
            </div>
            <p className="text-sm text-gray-600">ROI</p>
          </div>
          <p className="text-3xl font-semibold text-gray-900">{metrics.roi.toFixed(1)}x</p>
          <p className="text-xs text-gray-500 mt-2">{formatCurrency(metrics.totalRevenue)} receita</p>
        </div>
      </div>

      {/* Campaign and Creator Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Campaign Summary */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border-2 border-blue-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Target className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Campanhas</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Ativas:</span>
              <span className="text-xl font-bold text-blue-600">{metrics.activeCampaigns}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Total:</span>
              <span className="text-lg font-semibold text-gray-900">{metrics.totalCampaigns}</span>
            </div>
            <div className="pt-3 border-t border-blue-200">
              <p className="text-xs text-gray-600">
                {metrics.activeCampaigns > 0 
                  ? `${metrics.activeCampaigns} campanha${metrics.activeCampaigns > 1 ? 's' : ''} em andamento` 
                  : 'Nenhuma campanha ativa no momento'}
              </p>
            </div>
          </div>
        </div>

        {/* Creators Summary */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-purple-600 rounded-lg">
              <Award className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Creators</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Aprovados:</span>
              <span className="text-xl font-bold text-green-600">{metrics.creatorsApproved}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Aguardando:</span>
              <span className="text-lg font-semibold text-orange-600">{metrics.creatorsInApproval}</span>
            </div>
            <div className="pt-3 border-t border-purple-200">
              <p className="text-xs text-gray-600">
                {metrics.totalCreators} creator{metrics.totalCreators !== 1 ? 's' : ''} cadastrado{metrics.totalCreators !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
        </div>

        {/* Content Summary */}
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border-2 border-green-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-green-600 rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Conteúdos</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Publicados:</span>
              <span className="text-xl font-bold text-green-600">{metrics.postsPublished}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Pendentes:</span>
              <span className="text-lg font-semibold text-orange-600">{metrics.postsPending}</span>
            </div>
            <div className="pt-3 border-t border-green-200">
              <p className="text-xs text-gray-600">
                {metrics.postsScheduled} agendado{metrics.postsScheduled !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Financial Analysis (Admin Only) */}
      {canViewMargins && (
        <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-xl border-2 border-green-300 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-green-600 rounded-xl">
              <DollarSign className="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Análise Financeira</h3>
              <p className="text-sm text-gray-600">Visão administrativa completa</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-5 border-2 border-green-200">
              <p className="text-sm text-gray-600 mb-2">Custo Total (Creator)</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(metrics.totalCost)}</p>
              <div className="flex items-center gap-1 mt-2">
                <TrendingUp className="w-4 h-4 text-gray-500" />
                <p className="text-xs text-gray-500">{metrics.creatorsApproved + metrics.creatorsCompleted} creators</p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-5 border-2 border-blue-200">
              <p className="text-sm text-gray-600 mb-2">Valor Cliente</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(metrics.totalClientValue)}</p>
              <div className="flex items-center gap-1 mt-2">
                <Users className="w-4 h-4 text-gray-500" />
                <p className="text-xs text-gray-500">Total cobrado</p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-5 border-2 border-green-200">
              <p className="text-sm text-gray-600 mb-2">Margem Total</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(metrics.margin)}</p>
              <div className="flex items-center gap-1 mt-2">
                <ArrowUp className="w-4 h-4 text-green-500" />
                <p className="text-xs text-green-600">
                  {metrics.totalClientValue > 0 ? ((metrics.margin / metrics.totalClientValue) * 100).toFixed(1) : 0}% margem
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-5 border-2 border-orange-200">
              <p className="text-sm text-gray-600 mb-2">ROI Estimado</p>
              <p className="text-2xl font-bold text-orange-600">{metrics.roi.toFixed(2)}x</p>
              <div className="flex items-center gap-1 mt-2">
                <Target className="w-4 h-4 text-gray-500" />
                <p className="text-xs text-gray-500">{formatCurrency(metrics.totalRevenue)} receita</p>
              </div>
            </div>
          </div>

          {/* Profitability Insights */}
          <div className="mt-6 bg-white rounded-xl p-5 border-2 border-green-200">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Insights de Rentabilidade</h4>
            <div className="space-y-3">
              {metrics.margin > 0 ? (
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <ArrowUp className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-900">Margem positiva de {formatCurrency(metrics.margin)}</p>
                    <p className="text-xs text-green-700 mt-1">
                      Excelente! Você está lucrando {((metrics.margin / metrics.totalClientValue) * 100).toFixed(1)}% sobre o valor total das campanhas.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-orange-900">Atenção à margem</p>
                    <p className="text-xs text-orange-700 mt-1">
                      Revise seus custos para maximizar a rentabilidade das campanhas.
                    </p>
                  </div>
                </div>
              )}

              {metrics.roi >= 3 ? (
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <Award className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-900">ROI excepcional de {metrics.roi.toFixed(1)}x</p>
                    <p className="text-xs text-blue-700 mt-1">
                      Campanhas gerando retorno significativo sobre o investimento!
                    </p>
                  </div>
                </div>
              ) : metrics.roi >= 1.5 ? (
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-900">ROI saudável de {metrics.roi.toFixed(1)}x</p>
                    <p className="text-xs text-green-700 mt-1">
                      Campanhas performando bem. Continue otimizando para melhorar ainda mais.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-orange-900">ROI de {metrics.roi.toFixed(1)}x - Espaço para melhoria</p>
                    <p className="text-xs text-orange-700 mt-1">
                      Considere ajustar estratégias para aumentar o retorno sobre investimento.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Creators Status Pie Chart */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Status dos Criadores</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={creatorsStatusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {creatorsStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Content Status Pie Chart */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Status do Conteúdo</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={contentStatusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {contentStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Top Performers Bar Chart */}
        {topPerformers.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top 5 Performers por Engajamento</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={topPerformers}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="engajamento" fill="#8b5cf6" name="Engajamento" />
                <Bar dataKey="taxa" fill="#10b981" name="Taxa (%)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Campaign Performance Bar Chart */}
        {campaignData.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Desempenho por Campanha</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={campaignData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="impressoes" fill="#3b82f6" name="Impressões" />
                <Bar dataKey="alcance" fill="#10b981" name="Alcance" />
                <Bar dataKey="engajamento" fill="#f59e0b" name="Engajamento" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Performance Insights */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-purple-100 rounded-xl">
            <TrendingUp className="w-7 h-7 text-purple-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">Insights de Performance</h3>
            <p className="text-sm text-gray-600">Análise estratégica dos resultados</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {metrics.avgEngagementRate >= 5 ? (
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-start gap-3">
                <Award className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-green-900">Engajamento excepcional!</p>
                  <p className="text-xs text-green-700 mt-1">
                    Taxa média de {metrics.avgEngagementRate.toFixed(2)}% está acima da média do mercado.
                  </p>
                </div>
              </div>
            </div>
          ) : metrics.avgEngagementRate >= 3 ? (
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-blue-900">Bom engajamento</p>
                  <p className="text-xs text-blue-700 mt-1">
                    Taxa média de {metrics.avgEngagementRate.toFixed(2)}% está dentro da média esperada.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-orange-900">Oportunidade de melhoria</p>
                  <p className="text-xs text-orange-700 mt-1">
                    Taxa de {metrics.avgEngagementRate.toFixed(2)}%. Considere otimizar conteúdo e timing.
                  </p>
                </div>
              </div>
            </div>
          )}

          {metrics.creatorsInApproval > 0 && (
            <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-yellow-900">Ação necessária</p>
                  <p className="text-xs text-yellow-700 mt-1">
                    {metrics.creatorsInApproval} creator{metrics.creatorsInApproval > 1 ? 's' : ''} aguardando aprovação.
                  </p>
                </div>
              </div>
            </div>
          )}

          {metrics.postsPending > 0 && (
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-start gap-3">
                <Eye className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-blue-900">Conteúdos pendentes</p>
                  <p className="text-xs text-blue-700 mt-1">
                    {metrics.postsPending} conteúdo{metrics.postsPending > 1 ? 's' : ''} aguardando publicação.
                  </p>
                </div>
              </div>
            </div>
          )}

          {metrics.totalReach > metrics.totalImpressions * 0.8 && (
            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-start gap-3">
                <Users className="w-5 h-5 text-purple-600 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-purple-900">Alcance eficiente</p>
                  <p className="text-xs text-purple-700 mt-1">
                    Alto alcance único em relação às impressões totais.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}