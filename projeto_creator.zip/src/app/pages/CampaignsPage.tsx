import { useState } from 'react';
import { Eye, Edit } from 'lucide-react';
import { usePermissions } from '@/app/hooks/usePermissions';
import { useApp } from '@/app/contexts/AppContext';
import { AddCampaignModal } from '@/app/components/campaigns/AddCampaignModal';
import { Campaign } from '@/app/contexts/AppContext';
import { toast } from 'sonner';

export function CampaignsPage() {
  const { isAdmin } = usePermissions();
  const { setCurrentPage, campaigns: allCampaigns, currentClient, setCurrentCampaign } = useApp();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [campaignToEdit, setCampaignToEdit] = useState<Campaign | undefined>(undefined);
  
  // Filter campaigns by current client
  const campaigns = currentClient 
    ? allCampaigns.filter(c => c.clientId === currentClient.id)
    : allCampaigns;

  const handleCreateCampaign = () => {
    setCampaignToEdit(undefined);
    setIsAddModalOpen(true);
  };

  const handleEditCampaign = (campaign: Campaign) => {
    setCampaignToEdit(campaign);
    setIsAddModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsAddModalOpen(false);
    setCampaignToEdit(undefined);
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
    }).format(num);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const statusConfig = {
    active: {
      className: 'bg-green-50 text-green-700 border border-green-200',
      label: 'Ativa',
    },
    draft: {
      className: 'bg-gray-50 text-gray-700 border border-gray-200',
      label: 'Rascunho',
    },
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Campanhas</h1>
          <p className="text-sm text-gray-600 mt-1">Gerencie suas campanhas ativas</p>
        </div>
        <button 
          onClick={handleCreateCampaign}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Nova Campanha
        </button>
      </div>

      {/* Campaigns Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {campaigns.map((campaign) => (
          <div key={campaign.id} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{campaign.name}</h3>
                <p className="text-sm text-gray-500 mt-1">{campaign.client}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusConfig[campaign.status].className}`}>
                {statusConfig[campaign.status].label}
              </span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Período:</span>
                <span className="font-medium text-gray-900">
                  {formatDate(campaign.startDate)} - {campaign.endDate ? formatDate(campaign.endDate) : 'Em aberto'}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Creators:</span>
                <span className="font-medium text-gray-900">{campaign.creators || 0}</span>
              </div>
              {isAdmin && campaign.budget && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Budget:</span>
                  <span className="font-medium text-gray-900">{formatCurrency(campaign.budget)}</span>
                </div>
              )}
            </div>

            <div className="mt-4 flex gap-2">
              {isAdmin && (
                <button 
                  onClick={() => handleEditCampaign(campaign)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
                >
                  <Edit className="w-4 h-4" />
                  Editar
                </button>
              )}
              <button 
                onClick={() => {
                  setCurrentCampaign(campaign);
                  setCurrentPage('campaign-insights');
                }}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
              >
                <Eye className="w-4 h-4" />
                Ver Performance
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Campaign Modal */}
      <AddCampaignModal
        isOpen={isAddModalOpen}
        onClose={handleCloseModal}
        campaignToEdit={campaignToEdit}
      />
    </div>
  );
}