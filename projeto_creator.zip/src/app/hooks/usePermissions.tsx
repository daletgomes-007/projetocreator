import { ReactNode } from 'react';
import { useApp } from '@/app/contexts/AppContext';

interface PermissionGuardProps {
  children: ReactNode;
  adminOnly?: boolean;
  clientOnly?: boolean;
}

export function PermissionGuard({ children, adminOnly, clientOnly }: PermissionGuardProps) {
  const { user } = useApp();

  if (adminOnly && user.role !== 'admin') {
    return null;
  }

  if (clientOnly && user.role !== 'client') {
    return null;
  }

  return <>{children}</>;
}

export function usePermissions() {
  const { user } = useApp();

  return {
    isAdmin: user.role === 'admin',
    isClient: user.role === 'client',
    canViewFinancials: user.role === 'admin',
    canViewMargins: user.role === 'admin',
    canEditCreators: user.role === 'admin',
    canApproveCreators: true,
  };
}
