import { AppProvider } from '@/app/contexts/AppContext';
import { CreatorsProvider } from '@/app/contexts/CreatorsContext';
import { ContractsProvider } from '@/app/contexts/ContractsContext';
import { PerformanceProvider } from '@/app/contexts/PerformanceContext';
import { NotificationProvider } from '@/app/contexts/NotificationContext';
import { InvoiceProvider } from '@/app/contexts/InvoiceContext';
import { MainLayout } from '@/app/components/layout/MainLayout';
import { Toaster } from 'sonner';

export default function App() {
  return (
    <AppProvider>
      <NotificationProvider>
        <InvoiceProvider>
          <CreatorsProvider>
            <ContractsProvider>
              <PerformanceProvider>
                <MainLayout />
                <Toaster position="top-right" richColors />
              </PerformanceProvider>
            </ContractsProvider>
          </CreatorsProvider>
        </InvoiceProvider>
      </NotificationProvider>
    </AppProvider>
  );
}