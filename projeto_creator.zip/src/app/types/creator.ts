export type CreatorStatus = 
  | 'in_approval' 
  | 'approved' 
  | 'denied' 
  | 'negotiating' 
  | 'completed';

export interface Creator {
  id: string;
  name: string;
  email: string;
  socialNetwork: 'Instagram' | 'TikTok' | 'YouTube' | 'Twitter';
  followers: number;
  averageReach: number;
  engagementRate: number;
  scope: string;
  creatorValue: number;
  clientValue: number;
  status: CreatorStatus;
  internalNotes?: string;
  contractSigned: boolean;
  contentDelivered: boolean;
  clientId: string;
  campaignId?: string;
  boostStartDate?: string;
  boostEndDate?: string;
}

// OdontoCompany Creators
export const odontoCreators: Creator[] = [
  {
    id: 'odonto-1',
    name: 'Dra. Ana Paula Silva',
    email: 'ana.silva@email.com',
    socialNetwork: 'Instagram',
    followers: 125000,
    averageReach: 98000,
    engagementRate: 4.2,
    scope: '3 posts + 2 stories sobre saúde bucal',
    creatorValue: 8000,
    clientValue: 10000,
    status: 'approved',
    internalNotes: 'Dentista influencer, ótimo para campanhas de saúde',
    contractSigned: true,
    contentDelivered: false,
    clientId: '1',
    campaignId: 'camp-odonto-1',
    boostStartDate: '2026-01-25',
    boostEndDate: '2026-02-01',
  },
  {
    id: 'odonto-2',
    name: 'Juliana Moreira',
    email: 'juliana.moreira@email.com',
    socialNetwork: 'Instagram',
    followers: 95000,
    averageReach: 72000,
    engagementRate: 7.2,
    scope: '4 stories + 1 reel',
    creatorValue: 3500,
    clientValue: 4500,
    status: 'in_approval',
    internalNotes: 'Alto engajamento, micro influencer lifestyle',
    contractSigned: false,
    contentDelivered: false,
    clientId: '1',
    campaignId: 'camp-odonto-1',
    boostStartDate: '2026-01-28',
    boostEndDate: '2026-02-10',
  },
  {
    id: 'odonto-3',
    name: 'Carlos Wellness',
    email: 'carlos.wellness@email.com',
    socialNetwork: 'YouTube',
    followers: 230000,
    averageReach: 180000,
    engagementRate: 5.1,
    scope: '2 vídeos sobre cuidados dentários',
    creatorValue: 11000,
    clientValue: 13500,
    status: 'approved',
    internalNotes: 'Canal focado em bem-estar e saúde',
    contractSigned: true,
    contentDelivered: true,
    clientId: '1',
    campaignId: 'camp-odonto-1',
    boostStartDate: '2026-01-15',
    boostEndDate: '2026-01-30',
  },
];

// SamsClub Creators
export const samsCreators: Creator[] = [
  {
    id: 'sams-1',
    name: 'Mariana Costa',
    email: 'mariana.costa@email.com',
    socialNetwork: 'Instagram',
    followers: 280000,
    averageReach: 215000,
    engagementRate: 5.4,
    scope: '2 posts + 3 reels sobre compras',
    creatorValue: 12000,
    clientValue: 15000,
    status: 'approved',
    internalNotes: 'Influencer de economia doméstica',
    contractSigned: true,
    contentDelivered: false,
    clientId: '2',
    campaignId: 'camp-sams-1',
  },
  {
    id: 'sams-2',
    name: 'Pedro Economia',
    email: 'pedro.economia@email.com',
    socialNetwork: 'TikTok',
    followers: 450000,
    averageReach: 380000,
    engagementRate: 8.2,
    scope: '5 vídeos curtos de dicas',
    creatorValue: 15000,
    clientValue: 18500,
    status: 'negotiating',
    internalNotes: 'Especialista em dicas de economia',
    contractSigned: false,
    contentDelivered: false,
    clientId: '2',
    campaignId: 'camp-sams-1',
  },
];

// Positivo Creators
export const positivoCreators: Creator[] = [
  {
    id: 'positivo-1',
    name: 'Rafael Tech',
    email: 'rafael.tech@email.com',
    socialNetwork: 'YouTube',
    followers: 890000,
    averageReach: 650000,
    engagementRate: 6.8,
    scope: '3 reviews de produtos',
    creatorValue: 25000,
    clientValue: 32000,
    status: 'approved',
    internalNotes: 'Maior canal tech do Brasil',
    contractSigned: true,
    contentDelivered: true,
    clientId: '3',
    campaignId: 'camp-positivo-1',
  },
  {
    id: 'positivo-2',
    name: 'Julia Tecnologia',
    email: 'julia.tech@email.com',
    socialNetwork: 'Instagram',
    followers: 320000,
    averageReach: 245000,
    engagementRate: 5.9,
    scope: '4 posts + 6 stories',
    creatorValue: 14000,
    clientValue: 17500,
    status: 'approved',
    internalNotes: 'Focada em educação e tecnologia',
    contractSigned: true,
    contentDelivered: false,
    clientId: '3',
    campaignId: 'camp-positivo-1',
  },
  {
    id: 'positivo-3',
    name: 'TechBrasil',
    email: 'contato@techbrasil.com',
    socialNetwork: 'YouTube',
    followers: 580000,
    averageReach: 420000,
    engagementRate: 7.1,
    scope: '2 vídeos de unboxing',
    creatorValue: 18000,
    clientValue: 22000,
    status: 'in_approval',
    internalNotes: 'Aguardando aprovação do cliente',
    contractSigned: false,
    contentDelivered: false,
    clientId: '3',
    campaignId: 'camp-positivo-2',
  },
];

export const mockCreators: Creator[] = [
  ...odontoCreators,
  ...samsCreators,
  ...positivoCreators,
];