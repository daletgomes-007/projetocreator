export type InvoiceType = 'incoming' | 'outgoing'; // Recebida (cliente) ou Emitida (para creator)
export type InvoiceStatus = 'pending' | 'paid' | 'overdue' | 'cancelled';

export interface Invoice {
  id: string;
  clientId: string;
  clientName: string;
  type: InvoiceType;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  paymentDate?: string;
  amount: number;
  taxAmount?: number;
  totalAmount: number;
  status: InvoiceStatus;
  description: string;
  relatedTo?: string; // ID do creator ou campanha relacionado
  relatedName?: string; // Nome do creator ou campanha
  fileUrl?: string;
  fileName?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export const mockInvoices: Invoice[] = [
  // Notas fiscais da OdontoCompany
  {
    id: 'inv-1',
    clientId: 'client-1',
    clientName: 'OdontoCompany',
    type: 'incoming',
    invoiceNumber: 'NF-2025-001',
    issueDate: '2025-01-15',
    dueDate: '2025-02-15',
    paymentDate: '2025-01-20',
    amount: 50000,
    taxAmount: 5000,
    totalAmount: 55000,
    status: 'paid',
    description: 'Serviços de marketing - Campanha Verão 2025',
    relatedTo: 'campaign-1',
    relatedName: 'Campanha Verão 2025',
    fileUrl: '#',
    fileName: 'NF-2025-001.pdf',
    notes: 'Pagamento recebido via transferência bancária',
    createdAt: '2025-01-15T10:00:00',
    updatedAt: '2025-01-20T14:30:00',
  },
  {
    id: 'inv-2',
    clientId: 'client-1',
    clientName: 'OdontoCompany',
    type: 'outgoing',
    invoiceNumber: 'NF-OUT-2025-001',
    issueDate: '2025-01-16',
    dueDate: '2025-02-16',
    amount: 12000,
    taxAmount: 1200,
    totalAmount: 13200,
    status: 'paid',
    description: 'Pagamento a creator - Ana Silva',
    relatedTo: 'creator-1',
    relatedName: 'Ana Silva',
    fileUrl: '#',
    fileName: 'NF-OUT-2025-001.pdf',
    notes: 'Pagamento efetuado via PIX',
    createdAt: '2025-01-16T11:00:00',
    updatedAt: '2025-01-16T11:00:00',
  },
  {
    id: 'inv-3',
    clientId: 'client-1',
    clientName: 'OdontoCompany',
    type: 'incoming',
    invoiceNumber: 'NF-2025-002',
    issueDate: '2025-02-01',
    dueDate: '2025-03-01',
    amount: 35000,
    taxAmount: 3500,
    totalAmount: 38500,
    status: 'pending',
    description: 'Serviços de marketing - Campanha Black Friday 2024',
    relatedTo: 'campaign-2',
    relatedName: 'Black Friday 2024',
    fileUrl: '#',
    fileName: 'NF-2025-002.pdf',
    createdAt: '2025-02-01T09:00:00',
    updatedAt: '2025-02-01T09:00:00',
  },
  {
    id: 'inv-4',
    clientId: 'client-1',
    clientName: 'OdontoCompany',
    type: 'outgoing',
    invoiceNumber: 'NF-OUT-2025-002',
    issueDate: '2025-01-28',
    dueDate: '2025-02-28',
    amount: 8000,
    taxAmount: 800,
    totalAmount: 8800,
    status: 'pending',
    description: 'Pagamento a creator - Pedro Costa',
    relatedTo: 'creator-2',
    relatedName: 'Pedro Costa',
    fileUrl: '#',
    fileName: 'NF-OUT-2025-002.pdf',
    createdAt: '2025-01-28T10:00:00',
    updatedAt: '2025-01-28T10:00:00',
  },
  // Notas fiscais da Smart Fit
  {
    id: 'inv-5',
    clientId: 'client-2',
    clientName: 'Smart Fit',
    type: 'incoming',
    invoiceNumber: 'NF-2025-003',
    issueDate: '2025-01-10',
    dueDate: '2025-02-10',
    paymentDate: '2025-01-15',
    amount: 45000,
    taxAmount: 4500,
    totalAmount: 49500,
    status: 'paid',
    description: 'Serviços de marketing - Campanha Treino de Verão',
    relatedTo: 'campaign-3',
    relatedName: 'Treino de Verão',
    fileUrl: '#',
    fileName: 'NF-2025-003.pdf',
    notes: 'Pagamento antecipado',
    createdAt: '2025-01-10T08:00:00',
    updatedAt: '2025-01-15T10:00:00',
  },
  {
    id: 'inv-6',
    clientId: 'client-2',
    clientName: 'Smart Fit',
    type: 'outgoing',
    invoiceNumber: 'NF-OUT-2025-003',
    issueDate: '2025-01-20',
    dueDate: '2025-02-20',
    amount: 15000,
    taxAmount: 1500,
    totalAmount: 16500,
    status: 'pending',
    description: 'Pagamento a creator - Laura Costa',
    relatedTo: 'creator-3',
    relatedName: 'Laura Costa',
    fileUrl: '#',
    fileName: 'NF-OUT-2025-003.pdf',
    createdAt: '2025-01-20T14:00:00',
    updatedAt: '2025-01-20T14:00:00',
  },
  // Notas fiscais da Havaianas
  {
    id: 'inv-7',
    clientId: 'client-3',
    clientName: 'Havaianas',
    type: 'incoming',
    invoiceNumber: 'NF-2025-004',
    issueDate: '2025-01-05',
    dueDate: '2025-01-20',
    amount: 60000,
    taxAmount: 6000,
    totalAmount: 66000,
    status: 'overdue',
    description: 'Serviços de marketing - Campanha Praia 2025',
    relatedTo: 'campaign-4',
    relatedName: 'Praia 2025',
    fileUrl: '#',
    fileName: 'NF-2025-004.pdf',
    notes: 'Vencida - entrar em contato com o cliente',
    createdAt: '2025-01-05T09:00:00',
    updatedAt: '2025-01-21T09:00:00',
  },
  {
    id: 'inv-8',
    clientId: 'client-3',
    clientName: 'Havaianas',
    type: 'outgoing',
    invoiceNumber: 'NF-OUT-2025-004',
    issueDate: '2025-02-02',
    dueDate: '2025-03-02',
    amount: 18000,
    taxAmount: 1800,
    totalAmount: 19800,
    status: 'pending',
    description: 'Pagamento a creator - Ricardo Lima',
    relatedTo: 'creator-4',
    relatedName: 'Ricardo Lima',
    fileUrl: '#',
    fileName: 'NF-OUT-2025-004.pdf',
    createdAt: '2025-02-02T11:00:00',
    updatedAt: '2025-02-02T11:00:00',
  },
];
