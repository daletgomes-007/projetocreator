export type ContentType = 'Feed' | 'Reels' | 'Story';
export type PublicationStatus = 'Publicado' | 'Aguardando' | 'Ajuste solicitado';
export type PerformanceLevel = 'high' | 'medium' | 'low';

export interface CreatorPerformance {
  id: string;
  creatorId: string;
  clientId: string;
  campaignId: string;
  creatorName: string;
  instagramHandle: string;
  creatorPhoto: string;
  postUrl: string;
  contentType: ContentType;
  publicationStatus: PublicationStatus;
  publicationDate?: string;
  
  // Métricas do Instagram
  impressions: number;
  reach: number;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  
  // Engajamento
  totalEngagement: number;
  engagementRate: number;
  performanceLevel: PerformanceLevel;
  
  // Financeiro
  creatorCost: number;
  attributedRevenue: number;
  estimatedROI: number;
  margin: number;
}

export const mockCreatorPerformance: CreatorPerformance[] = [
  // OdontoCompany - Campanha Verão Sorriso 2026 (camp-odonto-1)
  {
    id: 'perf-odonto-1-1',
    creatorId: 'odonto-1',
    clientId: '1',
    campaignId: 'camp-odonto-1',
    creatorName: 'Dra. Ana Paula Silva',
    instagramHandle: '@dra.anapaulasilva',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Reels',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-25',
    impressions: 458000,
    reach: 342000,
    likes: 28500,
    comments: 1240,
    shares: 3200,
    saves: 8900,
    totalEngagement: 41840,
    engagementRate: 12.23,
    performanceLevel: 'high',
    creatorCost: 8000,
    attributedRevenue: 25000,
    estimatedROI: 212,
    margin: 17000,
  },
  {
    id: 'perf-odonto-1-2',
    creatorId: 'odonto-2',
    clientId: '1',
    campaignId: 'camp-odonto-1',
    creatorName: 'Juliana Moreira',
    instagramHandle: '@juliana.moreira',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Story',
    publicationStatus: 'Aguardando',
    publicationDate: undefined,
    impressions: 0,
    reach: 0,
    likes: 0,
    comments: 0,
    shares: 0,
    saves: 0,
    totalEngagement: 0,
    engagementRate: 0,
    performanceLevel: 'low',
    creatorCost: 3500,
    attributedRevenue: 0,
    estimatedROI: 0,
    margin: -3500,
  },
  {
    id: 'perf-odonto-1-3',
    creatorId: 'odonto-3',
    clientId: '1',
    campaignId: 'camp-odonto-1',
    creatorName: 'Carlos Wellness',
    instagramHandle: '@carloswellness',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Feed',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-22',
    impressions: 215000,
    reach: 180000,
    likes: 12400,
    comments: 580,
    shares: 890,
    saves: 3200,
    totalEngagement: 17070,
    engagementRate: 9.48,
    performanceLevel: 'high',
    creatorCost: 11000,
    attributedRevenue: 35000,
    estimatedROI: 218,
    margin: 24000,
  },

  // OdontoCompany - Aparelhos Invisíveis (camp-odonto-2)
  {
    id: 'perf-odonto-2-1',
    creatorId: 'odonto-4',
    clientId: '1',
    campaignId: 'camp-odonto-2',
    creatorName: 'Beatriz Dental Care',
    instagramHandle: '@beatriz.dentalcare',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Reels',
    publicationStatus: 'Publicado',
    publicationDate: '2026-02-05',
    impressions: 380000,
    reach: 290000,
    likes: 22000,
    comments: 890,
    shares: 2100,
    saves: 6800,
    totalEngagement: 31790,
    engagementRate: 10.96,
    performanceLevel: 'high',
    creatorCost: 9500,
    attributedRevenue: 28000,
    estimatedROI: 194,
    margin: 18500,
  },
  {
    id: 'perf-odonto-2-2',
    creatorId: 'odonto-5',
    clientId: '1',
    campaignId: 'camp-odonto-2',
    creatorName: 'Dr. Roberto Silva',
    instagramHandle: '@dr.robertosilva',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Feed',
    publicationStatus: 'Ajuste solicitado',
    publicationDate: '2026-02-08',
    impressions: 125000,
    reach: 98000,
    likes: 5600,
    comments: 240,
    shares: 420,
    saves: 1800,
    totalEngagement: 8060,
    engagementRate: 8.22,
    performanceLevel: 'medium',
    creatorCost: 6200,
    attributedRevenue: 15000,
    estimatedROI: 141,
    margin: 8800,
  },

  // SamsClub - Black Friday 2026 (camp-sams-1)
  {
    id: 'perf-sams-1-1',
    creatorId: 'sams-1',
    clientId: '2',
    campaignId: 'camp-sams-1',
    creatorName: 'Mariana Costa',
    instagramHandle: '@marianacosta',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Reels',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-23',
    impressions: 890000,
    reach: 650000,
    likes: 42000,
    comments: 890,
    shares: 1200,
    saves: 5600,
    totalEngagement: 49690,
    engagementRate: 7.64,
    performanceLevel: 'high',
    creatorCost: 12000,
    attributedRevenue: 48000,
    estimatedROI: 300,
    margin: 36000,
  },
  {
    id: 'perf-sams-1-2',
    creatorId: 'sams-2',
    clientId: '2',
    campaignId: 'camp-sams-1',
    creatorName: 'Pedro Economia',
    instagramHandle: '@pedroeconomia',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Feed',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-27',
    impressions: 520000,
    reach: 420000,
    likes: 28900,
    comments: 1340,
    shares: 2560,
    saves: 7200,
    totalEngagement: 40000,
    engagementRate: 9.52,
    performanceLevel: 'high',
    creatorCost: 15000,
    attributedRevenue: 52000,
    estimatedROI: 246,
    margin: 37000,
  },

  // Positivo - Volta às Aulas 2026 (camp-positivo-1)
  {
    id: 'perf-positivo-1-1',
    creatorId: 'positivo-1',
    clientId: '3',
    campaignId: 'camp-positivo-1',
    creatorName: 'Rafael Tech',
    instagramHandle: '@rafaeltech',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Reels',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-22',
    impressions: 1250000,
    reach: 950000,
    likes: 85000,
    comments: 3200,
    shares: 5400,
    saves: 12000,
    totalEngagement: 105600,
    engagementRate: 11.12,
    performanceLevel: 'high',
    creatorCost: 25000,
    attributedRevenue: 95000,
    estimatedROI: 280,
    margin: 70000,
  },
  {
    id: 'perf-positivo-1-2',
    creatorId: 'positivo-2',
    clientId: '3',
    campaignId: 'camp-positivo-1',
    creatorName: 'Julia Tecnologia',
    instagramHandle: '@juliatech',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Feed',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-18',
    impressions: 450000,
    reach: 320000,
    likes: 28000,
    comments: 1200,
    shares: 1800,
    saves: 5600,
    totalEngagement: 36600,
    engagementRate: 11.44,
    performanceLevel: 'high',
    creatorCost: 14000,
    attributedRevenue: 52000,
    estimatedROI: 271,
    margin: 38000,
  },

  // Positivo - Profissionais Home Office (camp-positivo-2)
  {
    id: 'perf-positivo-2-1',
    creatorId: 'positivo-3',
    clientId: '3',
    campaignId: 'camp-positivo-2',
    creatorName: 'TechBrasil',
    instagramHandle: '@techbrasil',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Reels',
    publicationStatus: 'Publicado',
    publicationDate: '2026-01-24',
    impressions: 980000,
    reach: 720000,
    likes: 62000,
    comments: 2100,
    shares: 3800,
    saves: 9500,
    totalEngagement: 77400,
    engagementRate: 10.75,
    performanceLevel: 'high',
    creatorCost: 18000,
    attributedRevenue: 68000,
    estimatedROI: 277,
    margin: 50000,
  },
  {
    id: 'perf-positivo-2-2',
    creatorId: 'positivo-4',
    clientId: '3',
    campaignId: 'camp-positivo-2',
    creatorName: 'Carolina Produtividade',
    instagramHandle: '@carol.produtividade',
    creatorPhoto: '',
    postUrl: 'https://www.instagram.com/p/DTkuFwhFaaL/?img_index=1',
    contentType: 'Story',
    publicationStatus: 'Aguardando',
    publicationDate: undefined,
    impressions: 0,
    reach: 0,
    likes: 0,
    comments: 0,
    shares: 0,
    saves: 0,
    totalEngagement: 0,
    engagementRate: 0,
    performanceLevel: 'low',
    creatorCost: 8500,
    attributedRevenue: 0,
    estimatedROI: 0,
    margin: -8500,
  },
];

// Calcula médias da campanha
export const getCampaignAverages = (performances: CreatorPerformance[]) => {
  const published = performances.filter(p => p.publicationStatus === 'Publicado');
  if (published.length === 0) return null;

  const sum = published.reduce(
    (acc, p) => ({
      impressions: acc.impressions + p.impressions,
      reach: acc.reach + p.reach,
      engagement: acc.engagement + p.totalEngagement,
      engagementRate: acc.engagementRate + p.engagementRate,
    }),
    { impressions: 0, reach: 0, engagement: 0, engagementRate: 0 }
  );

  return {
    impressions: Math.round(sum.impressions / published.length),
    reach: Math.round(sum.reach / published.length),
    engagement: Math.round(sum.engagement / published.length),
    engagementRate: parseFloat((sum.engagementRate / published.length).toFixed(2)),
  };
};