import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'admin' | 'client';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  clientId?: string;
}

export interface Client {
  id: string;
  name: string;
  logo?: string;
  description?: string;
  industry?: string;
  activeCampaigns?: number;
  totalSpent?: number;
  createdAt: string;
}

export interface ClientUser {
  id: string;
  name: string;
  email: string;
  company: string;
  createdAt: string;
}

export interface Campaign {
  id: string;
  name: string;
  clientId: string;
  client: string;
  status: 'active' | 'completed' | 'draft';
  startDate: string;
  endDate?: string;
  budget?: number;
  description?: string;
  creators?: number;
}

interface AppContextType {
  user: User | null;
  setUser: (user: User) => void;
  currentClient: Client | null;
  setCurrentClient: (client: Client | null) => void;
  currentCampaign: Campaign | null;
  setCurrentCampaign: (campaign: Campaign | null) => void;
  currentPage: string;
  setCurrentPage: (page: string) => void;
  selectedCreatorId: string | null;
  setSelectedCreatorId: (creatorId: string | null) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  isAuthenticated: boolean;
  login: (role: UserRole) => void;
  logout: () => void;
  clientUsers: ClientUser[];
  addClientUser: (client: Omit<ClientUser, 'id' | 'createdAt'>) => void;
  removeClientUser: (id: string) => void;
  clients: Client[];
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  updateClient: (id: string, updates: Partial<Omit<Client, 'id' | 'createdAt'>>) => void;
  removeClient: (id: string) => void;
  campaigns: Campaign[];
  addCampaign: (campaign: Omit<Campaign, 'id'>) => void;
  updateCampaign: (id: string, updates: Partial<Campaign>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock campaigns for each client
const mockCampaigns: Campaign[] = [
  // OdontoCompany campaigns
  {
    id: 'camp-odonto-1',
    name: 'Campanha Verão Sorriso 2026',
    clientId: '1',
    client: 'OdontoCompany',
    status: 'active',
    startDate: '2026-01-15',
    endDate: '2026-03-31',
    budget: 125000,
    description: 'Campanha de verão focada em clareamento dental',
    creators: 8,
  },
  {
    id: 'camp-odonto-2',
    name: 'Aparelhos Invisíveis',
    clientId: '1',
    client: 'OdontoCompany',
    status: 'active',
    startDate: '2026-02-01',
    endDate: '2026-04-30',
    budget: 85000,
    description: 'Divulgação de aparelhos ortodônticos invisíveis',
    creators: 5,
  },
  
  // SamsClub campaign
  {
    id: 'camp-sams-1',
    name: 'Black Friday 2026',
    clientId: '2',
    client: 'SamsClub',
    status: 'active',
    startDate: '2026-01-10',
    endDate: '2026-02-28',
    budget: 89000,
    description: 'Preparação para Black Friday',
    creators: 12,
  },
  
  // Positivo campaigns
  {
    id: 'camp-positivo-1',
    name: 'Volta às Aulas 2026',
    clientId: '3',
    client: 'Positivo',
    status: 'active',
    startDate: '2026-01-05',
    endDate: '2026-02-15',
    budget: 95000,
    description: 'Notebooks e tablets para estudantes',
    creators: 10,
  },
  {
    id: 'camp-positivo-2',
    name: 'Profissionais Home Office',
    clientId: '3',
    client: 'Positivo',
    status: 'active',
    startDate: '2026-01-20',
    endDate: '2026-03-20',
    budget: 61000,
    description: 'Equipamentos para trabalho remoto',
    creators: 6,
  },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [clients, setClients] = useState<Client[]>([
    {
      id: '1',
      name: 'OdontoCompany',
      description: 'Rede de clínicas odontológicas',
      industry: 'Saúde',
      activeCampaigns: 2,
      totalSpent: 125000,
      createdAt: '2025-08-15',
    },
    {
      id: '2',
      name: 'SamsClub',
      description: 'Atacadista e varejo',
      industry: 'Varejo',
      activeCampaigns: 1,
      totalSpent: 89000,
      createdAt: '2025-10-20',
    },
    {
      id: '3',
      name: 'Positivo',
      description: 'Tecnologia e educação',
      industry: 'Tecnologia',
      activeCampaigns: 2,
      totalSpent: 156000,
      createdAt: '2025-09-10',
    },
  ]);

  const [campaigns, setCampaigns] = useState<Campaign[]>(mockCampaigns);

  const [currentClient, setCurrentClient] = useState<Client | null>(clients[0]);

  const [currentCampaign, setCurrentCampaign] = useState<Campaign | null>(
    mockCampaigns.find(c => c.clientId === clients[0].id) || null
  );

  const [currentPage, setCurrentPage] = useState('dashboard');

  const [selectedCreatorId, setSelectedCreatorId] = useState<string | null>(null);

  const [clientUsers, setClientUsers] = useState<ClientUser[]>([
    {
      id: '1',
      name: 'Maria Santos',
      email: 'maria@odontocompany.com',
      company: 'OdontoCompany',
      createdAt: '2026-01-15',
    },
    {
      id: '2',
      name: 'Carlos Oliveira',
      email: 'carlos@samsclub.com',
      company: 'SamsClub',
      createdAt: '2026-01-20',
    },
    {
      id: '3',
      name: 'Ana Costa',
      email: 'ana@positivotecnologia.com.br',
      company: 'Positivo',
      createdAt: '2026-01-18',
    },
  ]);

  const login = (role: UserRole) => {
    if (role === 'admin') {
      setUser({
        id: '1',
        name: 'João Silva',
        email: 'joao@agencia.com',
        role: 'admin',
      });
      setCurrentClient(clients[0]);
    } else {
      setUser({
        id: '2',
        name: 'Maria Santos',
        email: 'maria@odontocompany.com',
        role: 'client',
        clientId: '1',
      });
      setCurrentClient(clients[0]);
    }
    setCurrentPage('dashboard');
  };

  const logout = () => {
    setUser(null);
    setCurrentPage('dashboard');
  };

  const addClientUser = (client: Omit<ClientUser, 'id' | 'createdAt'>) => {
    const newClient: ClientUser = {
      ...client,
      id: Math.random().toString(36).substring(7),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setClientUsers([...clientUsers, newClient]);
  };

  const removeClientUser = (id: string) => {
    setClientUsers(clientUsers.filter((c) => c.id !== id));
  };

  const addClient = (client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...client,
      id: Math.random().toString(36).substring(7),
      createdAt: new Date().toISOString().split('T')[0],
      activeCampaigns: client.activeCampaigns || 0,
      totalSpent: client.totalSpent || 0,
    };
    setClients([...clients, newClient]);
  };

  const updateClient = (id: string, updates: Partial<Omit<Client, 'id' | 'createdAt'>>) => {
    setClients(clients.map(client => client.id === id ? { ...client, ...updates } : client));
  };

  const removeClient = (id: string) => {
    setClients(clients.filter((c) => c.id !== id));
  };

  const addCampaign = (campaign: Omit<Campaign, 'id'>) => {
    const newCampaign: Campaign = {
      ...campaign,
      id: 'camp-' + Math.random().toString(36).substring(7),
    };
    setCampaigns([...campaigns, newCampaign]);
  };

  const updateCampaign = (id: string, updates: Partial<Campaign>) => {
    setCampaigns(campaigns.map(campaign => campaign.id === id ? { ...campaign, ...updates } : campaign));
  };

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        currentClient,
        setCurrentClient,
        currentCampaign,
        setCurrentCampaign,
        currentPage,
        setCurrentPage,
        selectedCreatorId,
        setSelectedCreatorId,
        sidebarOpen,
        setSidebarOpen,
        isAuthenticated: user !== null,
        login,
        logout,
        clientUsers,
        addClientUser,
        removeClientUser,
        clients,
        addClient,
        updateClient,
        removeClient,
        campaigns,
        addCampaign,
        updateCampaign,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
