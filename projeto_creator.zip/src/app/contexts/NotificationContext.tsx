import { createContext, useContext, useState, ReactNode, useCallback } from 'react';

export type NotificationType = 'creator_approved' | 'creator_denied' | 'creator_submitted' | 'campaign_created' | 'contract_generated' | 'performance_updated' | 'info';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  clientId: string;
  clientName: string;
  timestamp: Date;
  read: boolean;
  metadata?: {
    creatorName?: string;
    campaignName?: string;
    creatorId?: string;
    campaignId?: string;
  };
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  clearNotification: (notificationId: string) => void;
  clearAllNotifications: () => void;
  getClientNotifications: (clientId: string) => Notification[];
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// Helper function to get notification icon and color based on type
export const getNotificationStyle = (type: NotificationType) => {
  switch (type) {
    case 'creator_approved':
      return { color: 'green', icon: '✓', bgColor: 'bg-green-50', textColor: 'text-green-600', borderColor: 'border-green-200' };
    case 'creator_denied':
      return { color: 'red', icon: '✗', bgColor: 'bg-red-50', textColor: 'text-red-600', borderColor: 'border-red-200' };
    case 'creator_submitted':
      return { color: 'orange', icon: '⏳', bgColor: 'bg-orange-50', textColor: 'text-orange-600', borderColor: 'border-orange-200' };
    case 'campaign_created':
      return { color: 'blue', icon: '🎯', bgColor: 'bg-blue-50', textColor: 'text-blue-600', borderColor: 'border-blue-200' };
    case 'contract_generated':
      return { color: 'purple', icon: '📄', bgColor: 'bg-purple-50', textColor: 'text-purple-600', borderColor: 'border-purple-200' };
    case 'performance_updated':
      return { color: 'indigo', icon: '📊', bgColor: 'bg-indigo-50', textColor: 'text-indigo-600', borderColor: 'border-indigo-200' };
    default:
      return { color: 'gray', icon: 'ℹ', bgColor: 'bg-gray-50', textColor: 'text-gray-600', borderColor: 'border-gray-200' };
  }
};

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([
    // Initial mock notifications for demonstration
    {
      id: '1',
      type: 'creator_approved',
      title: 'Creator Aprovado',
      message: 'Ana Silva foi aprovada para a campanha Verão 2025',
      clientId: 'client-1',
      clientName: 'OdontoCompany',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      read: false,
      metadata: {
        creatorName: 'Ana Silva',
        campaignName: 'Verão 2025',
      },
    },
    {
      id: '2',
      type: 'creator_submitted',
      title: 'Novo Creator para Aprovação',
      message: 'Pedro Costa foi submetido para aprovação na campanha Black Friday 2024',
      clientId: 'client-1',
      clientName: 'OdontoCompany',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
      read: false,
      metadata: {
        creatorName: 'Pedro Costa',
        campaignName: 'Black Friday 2024',
      },
    },
    {
      id: '3',
      type: 'contract_generated',
      title: 'Contrato Gerado',
      message: 'Contrato gerado para Ana Silva na campanha Verão 2025',
      clientId: 'client-1',
      clientName: 'OdontoCompany',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      read: false,
      metadata: {
        creatorName: 'Ana Silva',
        campaignName: 'Verão 2025',
      },
    },
    {
      id: '4',
      type: 'performance_updated',
      title: 'Performance Atualizada',
      message: 'Métricas atualizadas para a campanha Verão 2025',
      clientId: 'client-1',
      clientName: 'OdontoCompany',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
      read: true,
      metadata: {
        campaignName: 'Verão 2025',
      },
    },
    {
      id: '5',
      type: 'creator_denied',
      title: 'Creator Reprovado',
      message: 'Carlos Mendes foi reprovado para a campanha Black Friday 2024',
      clientId: 'client-1',
      clientName: 'OdontoCompany',
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
      read: true,
      metadata: {
        creatorName: 'Carlos Mendes',
        campaignName: 'Black Friday 2024',
      },
    },
    // Notificações para Smart Fit
    {
      id: '6',
      type: 'creator_approved',
      title: 'Creator Aprovado',
      message: 'Laura Costa foi aprovada para a campanha Treino de Verão',
      clientId: 'client-2',
      clientName: 'Smart Fit',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      read: false,
      metadata: {
        creatorName: 'Laura Costa',
        campaignName: 'Treino de Verão',
      },
    },
    {
      id: '7',
      type: 'contract_generated',
      title: 'Contrato Gerado',
      message: 'Contrato gerado para Laura Costa na campanha Treino de Verão',
      clientId: 'client-2',
      clientName: 'Smart Fit',
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000), // 8 hours ago
      read: true,
      metadata: {
        creatorName: 'Laura Costa',
        campaignName: 'Treino de Verão',
      },
    },
    // Notificações para Havaianas
    {
      id: '8',
      type: 'creator_submitted',
      title: 'Novo Creator para Aprovação',
      message: 'Ricardo Lima foi submetido para aprovação na campanha Praia 2025',
      clientId: 'client-3',
      clientName: 'Havaianas',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      read: false,
      metadata: {
        creatorName: 'Ricardo Lima',
        campaignName: 'Praia 2025',
      },
    },
    {
      id: '9',
      type: 'performance_updated',
      title: 'Performance Atualizada',
      message: 'Métricas atualizadas para a campanha Praia 2025',
      clientId: 'client-3',
      clientName: 'Havaianas',
      timestamp: new Date(Date.now() - 10 * 60 * 60 * 1000), // 10 hours ago
      read: true,
      metadata: {
        campaignName: 'Praia 2025',
      },
    },
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const addNotification = useCallback((notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      read: false,
    };
    setNotifications(prev => [newNotification, ...prev]);
  }, []);

  const markAsRead = useCallback((notificationId: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    );
  }, []);

  const clearNotification = useCallback((notificationId: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== notificationId));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const getClientNotifications = useCallback((clientId: string) => {
    return notifications.filter(notif => notif.clientId === clientId);
  }, [notifications]);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        clearNotification,
        clearAllNotifications,
        getClientNotifications,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}