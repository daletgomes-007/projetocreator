import { createContext, useContext, useState, ReactNode } from 'react';
import { mockContracts } from '@/app/data/mockData';
import type { Contract } from '@/app/data/mockData';

export type { Contract };

const ContractsContext = createContext<{
  contracts: Contract[];
  addContract: (contract: Omit<Contract, 'id'>) => void;
  updateContract: (id: string, updates: Partial<Contract>) => void;
  uploadContractFile: (id: string, file: File) => Promise<void>;
} | undefined>(undefined);

export function ContractsProvider({ children }: { children: ReactNode }) {
  const [contracts, setContracts] = useState<Contract[]>(mockContracts);

  const addContract = (contract: Omit<Contract, 'id'>) => {
    const newContract: Contract = {
      ...contract,
      id: Date.now().toString(),
    };
    setContracts((prev) => [...prev, newContract]);
  };

  const updateContract = (id: string, updates: Partial<Contract>) => {
    setContracts((prev) =>
      prev.map((contract) =>
        contract.id === id ? { ...contract, ...updates } : contract
      )
    );
  };

  const uploadContractFile = async (id: string, file: File) => {
    // Simular upload de arquivo
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        const fakeUrl = `https://example.com/contracts/${file.name}`;
        updateContract(id, { 
          fileUrl: fakeUrl,
          status: 'sent',
          sentDate: new Date().toISOString().split('T')[0]
        });
        resolve();
      }, 1000);
    });
  };

  return (
    <ContractsContext.Provider
      value={{
        contracts,
        addContract,
        updateContract,
        uploadContractFile,
      }}
    >
      {children}
    </ContractsContext.Provider>
  );
}

export function useContracts() {
  const context = useContext(ContractsContext);
  if (context === undefined) {
    throw new Error('useContracts must be used within a ContractsProvider');
  }
  return context;
}