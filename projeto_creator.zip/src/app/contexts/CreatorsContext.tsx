import { createContext, useContext, useState, ReactNode } from 'react';
import { Creator, mockCreators } from '@/app/types/creator';

interface CreatorsContextType {
  creators: Creator[];
  addCreator: (creator: Omit<Creator, 'id'>) => void;
  updateCreator: (id: string, updates: Partial<Creator>) => void;
  deleteCreator: (id: string) => void;
}

const CreatorsContext = createContext<CreatorsContextType | undefined>(undefined);

export function CreatorsProvider({ children }: { children: ReactNode }) {
  const [creators, setCreators] = useState<Creator[]>(mockCreators);

  const addCreator = (creator: Omit<Creator, 'id'>) => {
    const newCreator: Creator = {
      ...creator,
      id: `creator-${Date.now()}`,
    };
    setCreators((prev) => [...prev, newCreator]);
  };

  const updateCreator = (id: string, updates: Partial<Creator>) => {
    setCreators((prev) =>
      prev.map((creator) =>
        creator.id === id ? { ...creator, ...updates } : creator
      )
    );
  };

  const deleteCreator = (id: string) => {
    setCreators((prev) => prev.filter((creator) => creator.id !== id));
  };

  return (
    <CreatorsContext.Provider
      value={{
        creators,
        addCreator,
        updateCreator,
        deleteCreator,
      }}
    >
      {children}
    </CreatorsContext.Provider>
  );
}

export function useCreators() {
  const context = useContext(CreatorsContext);
  if (context === undefined) {
    throw new Error('useCreators must be used within a CreatorsProvider');
  }
  return context;
}
