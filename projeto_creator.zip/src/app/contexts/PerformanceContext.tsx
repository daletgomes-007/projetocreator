import { createContext, useContext, useState, ReactNode } from 'react';
import {
  CreatorPerformance,
  mockCreatorPerformance,
} from '@/app/types/performance';

interface PerformanceContextType {
  performances: CreatorPerformance[];
  addPerformance: (performance: Omit<CreatorPerformance, 'id'>) => void;
  updatePerformance: (id: string, updates: Partial<CreatorPerformance>) => void;
  getPerformanceByCreator: (creatorId: string) => CreatorPerformance | undefined;
}

const PerformanceContext = createContext<PerformanceContextType | undefined>(undefined);

export function PerformanceProvider({ children }: { children: ReactNode }) {
  const [performances, setPerformances] = useState<CreatorPerformance[]>(mockCreatorPerformance);

  const addPerformance = (performance: Omit<CreatorPerformance, 'id'>) => {
    const newPerformance: CreatorPerformance = {
      ...performance,
      id: `perf-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setPerformances((prev) => [...prev, newPerformance]);
  };

  const updatePerformance = (id: string, updates: Partial<CreatorPerformance>) => {
    setPerformances((prev) =>
      prev.map((perf) => (perf.id === id ? { ...perf, ...updates } : perf))
    );
  };

  const getPerformanceByCreator = (creatorId: string) => {
    return performances.find((p) => p.creatorId === creatorId);
  };

  return (
    <PerformanceContext.Provider
      value={{
        performances,
        addPerformance,
        updatePerformance,
        getPerformanceByCreator,
      }}
    >
      {children}
    </PerformanceContext.Provider>
  );
}

export function usePerformance() {
  const context = useContext(PerformanceContext);
  if (!context) {
    throw new Error('usePerformance must be used within PerformanceProvider');
  }
  return context;
}
